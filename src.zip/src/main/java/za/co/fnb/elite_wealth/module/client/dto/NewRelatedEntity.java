package za.co.fnb.elite_wealth.module.client.dto;

import java.util.List;

public class NewRelatedEntity {
	private String testCase;
	private String testScenario;
	private String entityType;
	private String relation;
	private String title;
	private String surname;
	private String firstName;
	private String dateOfBirth;
	private String entityLegalType;
	private String registeredName;
	private String relationship;
	private String relatedClient;


	public NewRelatedEntity(List<String> related) {
		int  TEST_CASE =0;
		int  TEST_SCENARIO =1;
		int  ENTITY_TYPE =2;
		int  RELATION=3;;
		int  TITLE =4;
		int  SURNAME =5;
		int  FIRST_NAME =6;
		int  DATE_OF_BIRTH=7;
		int  ENTITY_LEGAL_TYPE =8;
		int  REGISTERED_NAME =9;
		int  RELATIONSHIP = 10;
		int  RELATED_CLIENT = 11;
		setTestCase(related.get(TEST_CASE));
		setTestScenario(related.get(TEST_SCENARIO));
		setRelation(related.get(RELATION));
		setTitle(related.get(TITLE));
		setSurname(related.get(SURNAME));
		setFirstName(related.get(FIRST_NAME));
		setDateOfBirth(related.get(DATE_OF_BIRTH));
		setEntityType(related.get(ENTITY_TYPE));
		setEntityLegalType(related.get(ENTITY_LEGAL_TYPE));
		setRegisteredName(related.get(REGISTERED_NAME));
		setRelationship(related.get(RELATIONSHIP));
		setRelatedClient(related.get(RELATED_CLIENT));
	}
	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getTestCase() {
		return testCase;
	}

	public void setTestCase(String testCase) {
		this.testCase = testCase;
	}

	public String getTestScenario() {
		return testScenario;
	}

	public void setTestScenario(String testScenario) {
		this.testScenario = testScenario;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}


	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEntityLegalType() {
		return entityLegalType;
	}

	public void setEntityLegalType(String entityLegalType) {
		this.entityLegalType = entityLegalType;
	}

	public String getRegisteredName() {
		return registeredName;
	}

	public void setRegisteredName(String registeredName) {
		this.registeredName = registeredName;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getRelatedClient() {
		return relatedClient;
	}

	public void setRelatedClient(String relatedClient) {
		this.relatedClient = relatedClient;
	}



}
