package za.co.fnb.elite_wealth.config;


import org.openqa.selenium.WebDriver;

public class DriverUtil {
    protected WebDriver driver;

    public DriverUtil(WebDriver driver)
    {
        super();
    }
}
