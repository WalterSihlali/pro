package za.co.fnb.elite_wealth.module.client.test;

import org.apache.log4j.Logger;
import org.junit.Test;
import za.co.fnb.elite_wealth.module.client.dto.Reports;
import za.co.fnb.elite_wealth.module.client.test.base.ReportBase;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;

public class ReportTest extends ReportBase {

	private static Logger log = Logger.getLogger(ReportTest.class);

	@Test
	public void clientReportTest() {
		try {
			PageInteraction page =new PageInteraction(driver);
			firstSteps(page);
			for (Reports entity : retrieveReportsData(page)) {
				searchForClient(page, entity);
				selectReportMenu(page);
				generateReport(page,entity);
				lastSteps(page);
			}
		} catch (Exception ex) {
			log.info(ex.getMessage());
		}
	}

}
