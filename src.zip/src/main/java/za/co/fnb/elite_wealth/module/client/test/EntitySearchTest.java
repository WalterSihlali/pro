package za.co.fnb.elite_wealth.module.client.test;

import org.apache.log4j.Logger;
import org.junit.Test;
import za.co.fnb.elite_wealth.module.client.dto.EntitySearch;
import za.co.fnb.elite_wealth.module.client.test.base.EntityDetailsBase;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;

public class EntitySearchTest extends EntityDetailsBase {

	private static Logger log = Logger.getLogger(EntitySearchTest.class);

	@Test
	public void entitySearchTest() {
		try {
			PageInteraction page = new PageInteraction(driver);
            firstSteps(page);
			for (EntitySearch client : retrieveEntitySearchData(page)) {
				entitySearch(page, client);
				searchLastSteps(page);
			}

		} catch (Exception ex) {
			log.info(ex.getMessage());
		}
	}

	@Test
	public void advancedEntitySearchTest() {
		try {
			PageInteraction page = new PageInteraction(driver);
			advancedSearchFirstSteps(page);

			for (EntitySearch client : retrieveEntitySearchData(page)) {
				advancedEntitySearch(page,client);
				advancedSearchLastSteps(page);
			}

		} catch (Exception ex) {
			log.info(ex.getMessage());
		}
	}
}
