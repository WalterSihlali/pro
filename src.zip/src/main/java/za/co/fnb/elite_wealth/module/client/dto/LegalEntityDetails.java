package za.co.fnb.elite_wealth.module.client.dto;

import java.util.List;

public class LegalEntityDetails {
    private String testCase;
    private String testScenario;
    private String searchValue;


    // Personal details
    private String personal;
    private String entityType;
    private String numberOfEmployees;
    private String tradeName;
    private String vatNumber;
    private String totalPayRoleCurrency;
    private String totalPayRoleValue;

    // Office details
    private String office;
    private String deActivateEntity;
    private String makeEntityClient;
    private String companyInfo;
    private String officeInfo;
    private String countryOfRes;
    private String status;
    private String navCurrency;
    private String estimatedNAV;
    private String dealSizeCurrency;
    private String dealSizeValue;
    private String expectedClosureDate;
    private String proposalDate;
    private String incomeClass;
    private String annualIncomeCurrency;
    private String annualIncome;
    private String grossIncomeCurrency;
    private String grossIncome;
    private String riskProfile;
    private String publicRoles;

    // Contact details
    private String addPreferredContact;
    private String preferredContact;
    private String meetingPlace;

    private String addEmail;
    private String emailType;
    private String emailAddress;
    private String deleteEmail;

    private String addTelephone;
    private String telephoneType;
    private String countryCode;
    private String areaCode;
    private String phoneNumber;
    private String extension;
    private String deletePhone;

    private String addAddress;
    private String addressType;
    private String addresses;
    private String address1;
    private String address2;
    private String suburb;
    private String city;
    private String postalCode;
    private String country;
    private String deleteAddress;

    // Compliance details
    private String compliance;



    private String updateStatus;
    private String effectiveDate;

    // Setup tags details
    private String setupTags;


    public LegalEntityDetails(List<String> entity){
        int  TEST_CASE =0;
        int  TEST_SCENARIO =1;
        int  SEARCH_VALUE =2;
        int  PERSONAL =3;
        int  ENTITY_TYPE=4;
        int  NUMBER_OF_EMPLOYEES =5;
        int  TRADE_NAME =6;
        int  VAT_NUMBER =7;
        int  TOTAL_PAY_ROLE_CURR =8;
        int  TOTAL_PAY_ROLE_VALUE=9;
        int  OFFICE =10;
        int  DEACTIVATE_ENTITY =11;
        int  MAKE_ENTITY_CLIENT=12;
        int  COMPANY_INFO=13;
        int  OFFICE_INFO=14;
        int  COUNTRY_OF_RES =15;
        int  STATUS =16;
        int  NAV_CURRENCY=17;
        int  ESTIMATED_NAV =18;
        int  DEAL_SIZE_CURRENCY =19;
        int  DEAL_SIZE_VALUE =20;
        int  EXPECTED_CLOSURE_DATE = 21;
        int  PROPOSAL_DATE = 22;
        int  INCOME_CLASS = 23;
        int  GROSS_INCOME_CURRENCY = 24;
        int  GROSS_INCOME = 25;
        int  RISK_PROFILE = 26;
        int  PUBLIC_ROLES = 27;

        int  ADD_PREFERRED_CONTACT = 28;
        int  PREFERRED_CONTACT = 29;
        int  MEETING_PLACE = 30;
        int  ADD_EMAIL = 31;
        int  EMAIL_TYPE = 32;
        int  EMAIL_ADDRESS = 33;
        int  DELETE_EMAIL = 34;

        int  ADD_TELEPHONE = 35;
        int  TELEPHONE_TYPE = 36;
        int  COUNTRY_CODE = 37;
        int  AREA_CODE = 38;
        int  PHONE_NUMBER = 39;
        int  EXTENSION = 40;
        int  DELETE_PHONE = 41;

        int  ADD_ADDRESS = 42;
        int  ADDRESS_TYPE = 43;
        int  ADDRESSES = 44;
        int  ADDRESS_1 = 45;
        int  ADDRESS_2 = 46;
        int  SUBURB = 47;
        int  CITY = 48;
        int  POSTAL_CODE = 49;
        int  COUNTRY = 50;
        int  DELETE_ADDRESS = 51;
        int  COMPLIANCE =52;
        int  UPDATE_STATUS =53;
        int  EFFECTIVE_DATE = 54;
        int	 SETUP_TAGS = 55;

        setTestCase(entity.get(TEST_CASE));
        setTestScenario(entity.get(TEST_SCENARIO));
        setSearchValue(entity.get(SEARCH_VALUE));
        setPersonal(entity.get(PERSONAL));
        setEntityType(entity.get(ENTITY_TYPE));
        setNumberOfEmployees(entity.get(NUMBER_OF_EMPLOYEES));
        setTradeName(entity.get(TRADE_NAME));
        setVatNumber(entity.get(VAT_NUMBER));
        setTotalPayRoleCurrency(entity.get(TOTAL_PAY_ROLE_CURR));
        setTotalPayRoleValue(entity.get(TOTAL_PAY_ROLE_VALUE));
        setOffice(entity.get(OFFICE));
        setDeActivateEntity(entity.get(DEACTIVATE_ENTITY));
        setMakeEntityClient(entity.get(MAKE_ENTITY_CLIENT));
        setCompanyInfo(entity.get(COMPANY_INFO));
        setOfficeInfo(entity.get(OFFICE_INFO));
        setCountryOfRes(entity.get(COUNTRY_OF_RES));
        setStatus(entity.get(STATUS));
        setNavCurrency(entity.get(NAV_CURRENCY));
        setEstimatedNAV(entity.get(ESTIMATED_NAV));
        setDealSizeCurrency(entity.get(DEAL_SIZE_CURRENCY));
        setDealSizeValue(entity.get(DEAL_SIZE_VALUE));
        setExpectedClosureDate(entity.get(EXPECTED_CLOSURE_DATE));
        setProposalDate(entity.get(PROPOSAL_DATE));
        setIncomeClass(entity.get(INCOME_CLASS));
        setGrossIncomeCurrency(entity.get(GROSS_INCOME_CURRENCY));
        setGrossIncome(entity.get(GROSS_INCOME));
        setRiskProfile(entity.get(RISK_PROFILE));
        setPublicRoles(entity.get(PUBLIC_ROLES));
        setAddPreferredContact(entity.get(ADD_PREFERRED_CONTACT));
        setPreferredContact(entity.get(PREFERRED_CONTACT));
        setMeetingPlace(entity.get(MEETING_PLACE));
        setAddEmail(entity.get(ADD_EMAIL));
        setEmailType(entity.get(EMAIL_TYPE));
        setEmailAddress(entity.get(EMAIL_ADDRESS));
        setDeleteEmail(entity.get(DELETE_EMAIL));
        setAddTelephone(entity.get(ADD_TELEPHONE));
        setTelephoneType(entity.get(TELEPHONE_TYPE));
        setCountryCode(entity.get(COUNTRY_CODE));
        setAreaCode(entity.get(AREA_CODE));
        setPhoneNumber(entity.get(PHONE_NUMBER));
        setExtension(entity.get(EXTENSION));
        setDeletePhone(entity.get(DELETE_PHONE));
        setAddAddress(entity.get(ADD_ADDRESS));
        setAddressType(entity.get(ADDRESS_TYPE));
        setAddresses(entity.get(ADDRESSES));
        setAddress1(entity.get(ADDRESS_1));
        setAddress2(entity.get(ADDRESS_2));
        setSuburb(entity.get(SUBURB));
        setCity(entity.get(CITY));
        setCountry(entity.get(COUNTRY));
        setPostalCode(entity.get(POSTAL_CODE));
        setDeleteAddress(entity.get(DELETE_ADDRESS));

        setCompliance(entity.get(COMPLIANCE));
        setUpdateStatus(entity.get(UPDATE_STATUS));
        setEffectiveDate(entity.get(EFFECTIVE_DATE));
        setSetupTags(entity.get(SETUP_TAGS));
    }


    public String getSetupTags() {
        return setupTags;
    }

    public void setSetupTags(String setupTags) {
        this.setupTags = setupTags;
    }

    public String getTestCase() {
        return testCase;
    }

    public void setTestCase(String testCase) {
        this.testCase = testCase;
    }

    public String getTestScenario() {
        return testScenario;
    }

    public void setTestScenario(String testScenario) {
        this.testScenario = testScenario;
    }

    public String getSearchValue() {
        return searchValue;
    }

    public void setSearchValue(String searchValue) {
        this.searchValue = searchValue;
    }

    public String getPersonal() {
        return personal;
    }

    public void setPersonal(String personal) {
        this.personal = personal;
    }

    public String getEntityType() {
        return entityType;
    }

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public String getNumberOfEmployees() {
        return numberOfEmployees;
    }

    public void setNumberOfEmployees(String numberOfEmployees) {
        this.numberOfEmployees = numberOfEmployees;
    }

    public String getTradeName() {
        return tradeName;
    }

    public void setTradeName(String tradeName) {
        this.tradeName = tradeName;
    }

    public String getVatNumber() {
        return vatNumber;
    }

    public void setVatNumber(String vatNumber) {
        this.vatNumber = vatNumber;
    }

    public String getTotalPayRoleCurrency() {
        return totalPayRoleCurrency;
    }

    public void setTotalPayRoleCurrency(String totalPayRoleCurrency) {
        this.totalPayRoleCurrency = totalPayRoleCurrency;
    }

    public String getTotalPayRoleValue() {
        return totalPayRoleValue;
    }

    public void setTotalPayRoleValue(String totalPayRoleValue) {
        this.totalPayRoleValue = totalPayRoleValue;
    }

    public String getOffice() {
        return office;
    }

    public void setOffice(String office) {
        this.office = office;
    }

    public String getDeActivateEntity() {
        return deActivateEntity;
    }

    public void setDeActivateEntity(String deActivateEntity) {
        this.deActivateEntity = deActivateEntity;
    }

    public String getMakeEntityClient() {
        return makeEntityClient;
    }

    public void setMakeEntityClient(String makeEntityClient) {
        this.makeEntityClient = makeEntityClient;
    }

    public String getCompanyInfo() {
        return companyInfo;
    }

    public void setCompanyInfo(String companyInfo) {
        this.companyInfo = companyInfo;
    }


    public String getOfficeInfo() {
        return officeInfo;
    }

    public void setOfficeInfo(String officeInfo) {
        this.officeInfo = officeInfo;
    }

    public String getCountryOfRes() {
        return countryOfRes;
    }

    public void setCountryOfRes(String countryOfRes) {
        this.countryOfRes = countryOfRes;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNavCurrency() {
        return navCurrency;
    }

    public void setNavCurrency(String navCurrency) {
        this.navCurrency = navCurrency;
    }

    public String getEstimatedNAV() {
        return estimatedNAV;
    }

    public void setEstimatedNAV(String estimatedNAV) {
        this.estimatedNAV = estimatedNAV;
    }

    public String getDealSizeCurrency() {
        return dealSizeCurrency;
    }

    public void setDealSizeCurrency(String dealSizeCurrency) {
        this.dealSizeCurrency = dealSizeCurrency;
    }

    public String getDealSizeValue() {
        return dealSizeValue;
    }

    public void setDealSizeValue(String dealSizeValue) {
        this.dealSizeValue = dealSizeValue;
    }

    public String getExpectedClosureDate() {
        return expectedClosureDate;
    }

    public void setExpectedClosureDate(String expectedClosureDate) {
        this.expectedClosureDate = expectedClosureDate;
    }

    public String getProposalDate() {
        return proposalDate;
    }

    public void setProposalDate(String proposalDate) {
        this.proposalDate = proposalDate;
    }

    public String getIncomeClass() {
        return incomeClass;
    }

    public void setIncomeClass(String incomeClass) {
        this.incomeClass = incomeClass;
    }

    public String getAnnualIncomeCurrency() {
        return annualIncomeCurrency;
    }

    public void setAnnualIncomeCurrency(String annualIncomeCurrency) {
        this.annualIncomeCurrency = annualIncomeCurrency;
    }

    public String getAnnualIncome() {
        return annualIncome;
    }

    public void setAnnualIncome(String annualIncome) {
        this.annualIncome = annualIncome;
    }

    public String getGrossIncomeCurrency() {
        return grossIncomeCurrency;
    }

    public void setGrossIncomeCurrency(String grossIncomeCurrency) {
        this.grossIncomeCurrency = grossIncomeCurrency;
    }

    public String getGrossIncome() {
        return grossIncome;
    }

    public void setGrossIncome(String grossIncome) {
        this.grossIncome = grossIncome;
    }

    public String getRiskProfile() {
        return riskProfile;
    }

    public void setRiskProfile(String riskProfile) {
        this.riskProfile = riskProfile;
    }

    public String getPublicRoles() {
        return publicRoles;
    }

    public void setPublicRoles(String publicRoles) {
        this.publicRoles = publicRoles;
    }

    public String getPreferredContact() {
        return preferredContact;
    }

    public void setPreferredContact(String preferredContact) {
        this.preferredContact = preferredContact;
    }

    public String getMeetingPlace() {
        return meetingPlace;
    }

    public void setMeetingPlace(String meetingPlace) {
        this.meetingPlace = meetingPlace;
    }

    public String getEmailType() {
        return emailType;
    }

    public void setEmailType(String emailType) {
        this.emailType = emailType;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getDeleteEmail() {
        return deleteEmail;
    }

    public void setDeleteEmail(String deleteEmail) {
        this.deleteEmail = deleteEmail;
    }

    public String getTelephoneType() {
        return telephoneType;
    }

    public void setTelephoneType(String telephoneType) {
        this.telephoneType = telephoneType;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public String getDeletePhone() {
        return deletePhone;
    }

    public void setDeletePhone(String deletePhone) {
        this.deletePhone = deletePhone;
    }

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    public String getAddresses() {
        return addresses;
    }

    public void setAddresses(String addresses) {
        this.addresses = addresses;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getSuburb() {
        return suburb;
    }

    public void setSuburb(String suburb) {
        this.suburb = suburb;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getDeleteAddress() {
        return deleteAddress;
    }

    public void setDeleteAddress(String deleteAddress) {
        this.deleteAddress = deleteAddress;
    }

    public String getCompliance() {
        return compliance;
    }

    public void setCompliance(String compliance) {
        this.compliance = compliance;
    }


    public String getAddPreferredContact() {
        return addPreferredContact;
    }

    public void setAddPreferredContact(String addPreferredContact) {
        this.addPreferredContact = addPreferredContact;
    }

    public String getAddTelephone() {
        return addTelephone;
    }

    public void setAddTelephone(String addTelephone) {
        this.addTelephone = addTelephone;
    }

    public String getAddEmail() {
        return addEmail;
    }

    public void setAddEmail(String addEmail) {
        this.addEmail = addEmail;
    }

    public String getAddAddress() {
        return addAddress;
    }

    public void setAddAddress(String addAddress) {
        this.addAddress = addAddress;
    }


    public String getUpdateStatus() {
        return updateStatus;
    }

    public void setUpdateStatus(String updateStatus) {
        this.updateStatus = updateStatus;
    }

    public String getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

}
