package za.co.fnb.elite_wealth.module.client.test;

import org.apache.log4j.Logger;
import org.junit.Test;
import za.co.fnb.elite_wealth.module.client.dto.IndividualAndLegalEntity;
import za.co.fnb.elite_wealth.module.client.test.base.EntityBase;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;

public class LegalAndIndividualEntityCreateTest extends EntityBase {

	private static Logger log = Logger.getLogger(LegalAndIndividualEntityCreateTest.class);

	@Test
	public void newCombinedEntityTest() {
		try {
			PageInteraction page =new PageInteraction(driver);
			firstSteps(page);
			for (IndividualAndLegalEntity client : retrieveLegalRelatedEntityData(page)) {
				addIndividualAndLegalEntity(page, client);
				lastSteps(page);
			}
			page.waitFor(3000);
		} catch (Exception ex) {
			log.info(ex.getMessage());
		}
	}
}
