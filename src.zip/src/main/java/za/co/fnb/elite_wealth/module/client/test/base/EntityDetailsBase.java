package za.co.fnb.elite_wealth.module.client.test.base;

import org.apache.log4j.Logger;
import za.co.fnb.elite_wealth.config.ElementConstants;
import za.co.fnb.elite_wealth.config.SeleniumService;
import za.co.fnb.elite_wealth.config.StringConstants;
import za.co.fnb.elite_wealth.module.client.dto.EntitySearch;
import za.co.fnb.elite_wealth.module.client.dto.IndividualEntityDetails;
import za.co.fnb.elite_wealth.module.client.dto.LegalEntityDetails;
import za.co.fnb.elite_wealth.module.common.CommonActions;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;
import za.co.fnb.elite_wealth.reporting.HtmlReporting;
import za.co.fnb.elite_wealth.reporting.TestStatus;
import za.co.fnb.elite_wealth.util.RetrieveTestData;

import java.util.Arrays;
import java.util.List;

public class EntityDetailsBase extends SeleniumService {
	private HtmlReporting reporting = new HtmlReporting();
	private List<String> testCaseSteps;
	private static final Logger log = Logger.getLogger(EntityDetailsBase.class);
	private CommonActions common = new CommonActions();
	
	protected List<IndividualEntityDetails> retrieveIndividualUpdateEntityData(PageInteraction page) {
		RetrieveTestData retrieveTestData = new RetrieveTestData(page.dataSheetLocation());
		return retrieveTestData.getIndividualUpdateDTO();
	}
	
	protected List<EntitySearch> retrieveEntitySearchData(PageInteraction page) {
		RetrieveTestData retrieveTestData = new RetrieveTestData(page.dataSheetLocation());
		return retrieveTestData.getSearchDTO();
	}
	
	public void firstSteps(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_INFO_TAB);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	public void advancedSearchLastSteps(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_MENU1);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	
	public void advancedSearchFirstSteps(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_INFO_TAB);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	
	public void lastSteps(PageInteraction page) throws Exception {
		common.checkUpdateSaved(page);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_INFO_TAB);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SELECT_ENTITY);
		page.waitFor(2000);
	}
	
	protected void searchLastSteps(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SELECT_ENTITY);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	protected void updateIndividualEntitySearch(PageInteraction page, IndividualEntityDetails entity) {
		String searchValue = entity.getSearchValue();
		String testCase = entity.getTestCase();
		common.assertTrue(page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_TXT));
		page.takeScreenShoot(testCase + common.getDateFormat());
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_TXT);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_TXT, searchValue);
		common.assertTrue(page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_BTN));
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_BTN);
		page.takeScreenShoot(testCase + common.getDateFormat());
		common.selectClientFromList(page);
		log.info("EntityBase search");
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	private void deActivateIndividualEntity(PageInteraction page, IndividualEntityDetails entity) throws InterruptedException {
		String testCase = entity.getTestCase();
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OFFICE_MENU);
		page.waitFor(2000);
		String[] steps = {StringConstants.LOGIN, StringConstants.SEARCH_ENTITY, "Deactivate entity"};
		testCaseSteps = Arrays.asList(steps);
		boolean isElementPresent = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DEACTIVATE_CLIENT);
		if (isElementPresent) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DEACTIVATE_CLIENT);
			validateIndividualEntityDeactivated(page, entity);
			reporting.generateReport(testCase, testCaseSteps, TestStatus.PASS);
			page.takeScreenShoot("deActivateEntity " + common.getDateFormat());
		} else {
			reporting.generateReport(testCase, testCaseSteps, TestStatus.PASS);
			log.info("Element cannot be deactivated");
			page.takeScreenShoot("deActivateEntity " + common.getDateFormat());
		}
	}
	
	private void makeClientPotentialClient(PageInteraction page) {
		String status = page.getSelectedOption(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.NEW_ENTITY_STATUS);
		if (status.equals("Client")) {
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.NEW_ENTITY_STATUS, "Potential client");
			page.selectNonInteractiveItem(ElementConstants.HOME_PAGE_NAME, ElementConstants.OFFICE_SAVE);
		}
	}
	
	private void makeEntityAClient(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OFFICE_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		makeClientPotentialClient(page);
		boolean isPotentialClient = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.MAKE_CLIENT_ENTITY);
		if (isPotentialClient) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.MAKE_CLIENT_ENTITY);
			page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.MAKE_CLIENT_ENTITY_MY_ROLE, "Wealth Manager");
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.MAKE_CLIENT_ENTITY_SAVE);
			page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
			String newStatus = page.getSelectedOption(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.NEW_ENTITY_STATUS);
			String[] steps = {StringConstants.LOGIN, StringConstants.SEARCH_ENTITY, "Make entity client"};
			testCaseSteps = Arrays.asList(steps);
			try {
				common.assertEquals(newStatus, "Client");
				reporting.generateReport("Make Legal Entity Client", testCaseSteps, TestStatus.PASS);
				page.takeScreenShoot("makeEntityAClient" + common.getDateFormat());
			} catch (Exception ex) {
				log.info(ex.getMessage());
			}
		} else {
			reporting.generateReport("Make Legal Entity Client", testCaseSteps, TestStatus.FAIL);
			log.info("EntityBase already client use potential client");
		}
	}
	
	protected void entitySearch(PageInteraction page, EntitySearch search) throws Exception {
		String entitySearch = search.getEntitySearch();
		String testCase = search.getTestCase();
		page.takeScreenShoot("entitySearch " + common.getDateFormat());
		log.info("Client Entity Search");
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_TXT);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_TXT, entitySearch);
		page.takeScreenShoot(testCase + common.getDateFormat());
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_BTN);
		String noResults = page.getStringValue(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_RESULTS);
		
		if (noResults.equals("There is no data available.")) {
			String[] steps = {"Entity not found"};
			testCaseSteps = Arrays.asList(steps);
			reporting.generateReport(testCase, testCaseSteps, TestStatus.FAIL);
			log.info("The client you searched for is not found on the db");
			page.takeScreenShoot(testCase + common.getDateFormat());
			
		} else {
			page.takeScreenShoot(testCase + common.getDateFormat());
			String[] steps = {StringConstants.LOGIN, StringConstants.SEARCH_ENTITY, "Select Entity", "Entity found and Selected"};
			testCaseSteps = Arrays.asList(steps);
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.FIRST_CLIENT);
			page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
			boolean elementPresent = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ON_SUMMARY_PAGE);
			try {
				common.assertTrue(elementPresent);
			} catch (Exception ex) {
				log.info(ex.getMessage());
			}
			reporting.generateReport(testCase, testCaseSteps, TestStatus.PASS);
		}
		page.waitFor(1000);
	}
	
	protected void advancedEntitySearch(PageInteraction page, EntitySearch search) throws Exception {
		String entitySearch = search.getEntitySearch();
		String testCase = search.getTestCase();
		
		if (testCase.equals("Search Entity by Surname")) {
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_SURNAME);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_SURNAME, entitySearch);
		}
		
		if (testCase.equals("Search Entity by First Name")) {
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_NAME);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_NAME, entitySearch);
		}
		
		if (testCase.equals("Search Entity by Reg Name")) {
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_REG_NAME);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_REG_NAME, entitySearch);
		}
		
		if (testCase.equals("Search Entity by ID")) {
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_ID);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_ID, entitySearch);
		}
		
		if (testCase.equals("Search Entity by Client Code")) {
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_CLIENT_ID);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_CLIENT_ID, entitySearch);
		}
		
		page.takeScreenShoot("entitySearch " + common.getDateFormat());
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_BUTTON);
		String noResults = page.getStringValue(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_NO_RESULTS);
		
		if (noResults.equals("There is no data available.")) {
			String[] steps = {"Entity not found"};
			testCaseSteps = Arrays.asList(steps);
			reporting.generateReport(StringConstants.ADVANCED + testCase, testCaseSteps, TestStatus.FAIL);
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_CANCEL);
			log.info("The client you advanced searched for is not found on the db");
			page.takeScreenShoot(StringConstants.ADVANCED + testCase + common.getDateFormat());
			
		} else {
			page.takeScreenShoot(testCase + common.getDateFormat());
			String[] steps = {"Login", "Search entity using advanced search", "Select Entity", "Entity found and Selected"};
			testCaseSteps = Arrays.asList(steps);
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADVANCED_SEARCH_FIRST_CLIENT);
			page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
			reporting.generateReport(StringConstants.ADVANCED + testCase, testCaseSteps, TestStatus.PASS);
		}
		page.waitFor(1000);
	}
	
	private void validateIndividualEntityDeactivated(PageInteraction page, IndividualEntityDetails entity) {
		String searchValue = entity.getSearchValue();
		String alertMessage = page.getAlertText();
		String expectedAlertMessage = "Please confirm that this entity should be deactivated?";
		try {
			common.assertEquals(alertMessage, expectedAlertMessage);
		} catch (Exception ex) {
			log.info(ex.getMessage());
		}
		page.acceptAlert();
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_INCLUDE_DELETED);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_TXT, searchValue);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_BTN);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		log.info("Validate entity deactivated");
		page.takeScreenShoot("validateIndividualEntityDeactivated " + common.getDateFormat());
	}
	
	private void addIndividualOfficeInfo(PageInteraction page, IndividualEntityDetails entity) {
		String testCase = entity.getTestCase();
		String estimatedNAV = entity.getEstimatedNAV();
		String dealSizeValue = entity.getDealSizeValue();
		String incomeClass = entity.getIncomeClass();
		String annualIncome = entity.getAnnualIncome();
		String grossIncome = entity.getGrossIncome();
		String company = entity.getCompanyInfo();
		String office = entity.getOfficeInfo();
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OFFICE_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_COMPANY, company);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_OFFICE, office);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ESTIMATED_NAV);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ESTIMATED_NAV, estimatedNAV);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DEAL_VALUE);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DEAL_VALUE, dealSizeValue);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_CLASS, incomeClass);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ANNUAL_INCOME, annualIncome);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_GROSS_INCOME);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_GROSS_INCOME, grossIncome);
		page.takeScreenShoot(testCase + common.getDateFormat());
		log.info("Add office details");
		page.takeScreenShoot(testCase + common.getDateFormat());
		
	}
	
	private void addComplianceStatus(PageInteraction page, IndividualEntityDetails entity) {
		String testCase = entity.getTestCase();
		String updateStatus = entity.getUpdateStatus();
		String effectiveDateCompliance = entity.getEffectiveDate();
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.COMPLIANCE_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		boolean onCompliancePage = page.isElementPresent(ElementConstants.HOME_PAGE_NAME, ElementConstants.COMPLIANCE_PAGE);
		
		if (onCompliancePage) {
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_KYC_STATUS);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_KYC_STATUS, updateStatus);
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.EFFECTIVE_DATE);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.EFFECTIVE_DATE, effectiveDateCompliance);
			page.takeScreenShoot(testCase + common.getDateFormat());
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_KYC);
			page.takeScreenShoot(testCase + common.getDateFormat());
		} else {
			page.takeScreenShoot(testCase + common.getDateFormat());
			log.info("Fail to reach the compliance page");
		}
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.COMPLIANCE_SAVE);
		page.waitForPageToLoad();
		
	}
	
	private void addIndividualPersonalDetails(PageInteraction page, IndividualEntityDetails entity) {
		String testCase = entity.getTestCase();
		String title = entity.getTitle();
		String suffix = entity.getSuffix();
		String maritalStatus = entity.getMaritalStatus();
		String numberOfDependants = entity.getNumberOfDependants();
		String retirementAge = entity.getRetirementAge();
		String statusUnknown = "Married (status unknown)";
		String anc = "Married ANC";
		String accrual = "Married ANC with accrual";
		String icop = "Married ICOP";
		String customary = "Married in customary law";
		String separated = "Separated";
		String widowed = "Widowed";
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_PERSONAL_DETAILS);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_TITLE, title);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_SUFFIX);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_SUFFIX, suffix);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_MARITAL, maritalStatus);
		page.takeScreenShoot(testCase + common.getDateFormat());
		if (maritalStatus
				.equals(statusUnknown) ||
				maritalStatus.equals(anc) ||
				maritalStatus.equals(accrual) ||
				maritalStatus.equals(icop) ||
				maritalStatus.equals(customary) ||
				maritalStatus.equals(separated) ||
				maritalStatus.equals(widowed)) {
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_MARITAL_DATE);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_MARITAL_DATE, "25/11/2010");
		}
		page.takeScreenShoot(testCase + common.getDateFormat());
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DEPENDANTS);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DEPENDANTS, numberOfDependants);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_RETIREMENT);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_RETIREMENT, retirementAge);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PERSONAL_SAVE);
		page.takeScreenShoot(testCase + common.getDateFormat());
		log.info("Add Contact Details");
	}
	
	private void addPreferredContactDetails(PageInteraction page, IndividualEntityDetails entity) {
		String testCase = entity.getTestCase();
		String preferredContact = entity.getPreferredContact();
		String meetingPlace = entity.getMeetingPlace();
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_PREFERRED_CONTACT, preferredContact);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_MEETING_PLACE, meetingPlace);
		log.info("Update preferred contact");
		page.takeScreenShoot(testCase + common.getDateFormat());
	}
	
	private void addEmailAddress(PageInteraction page, IndividualEntityDetails entity) throws InterruptedException {
		String testCase = entity.getTestCase();
		String emailType = entity.getEmailType();
		String emailAddress = entity.getEmailAddress();
		addPreferredContactDetails(page, entity);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMAIL_TYPE, emailType);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMAIL);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMAIL, emailAddress);
		log.info("Add email");
		page.takeScreenShoot(testCase + common.getDateFormat());
		page.waitFor(1000);
	}
	
	private void deleteEmailAddress(PageInteraction page, IndividualEntityDetails entity) throws InterruptedException {
		String testCase = entity.getTestCase();
		boolean deletePresent = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DELETE_EMAIL);
		page.waitFor(2000);
		if (deletePresent) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DELETE_EMAIL);
		} else {
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMAIL_TYPE, StringConstants.OFFICE);
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMAIL);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMAIL, "client1223@gmail.com");
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CONTACT_SAVE);
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DELETE_EMAIL);
		}
		log.info("Delete email");
		page.takeScreenShoot(testCase + common.getDateFormat());
	}
	
	private void addTelephone(PageInteraction page, IndividualEntityDetails entity) throws InterruptedException {
		String testCase = entity.getTestCase();
		String telephoneType = entity.getTelephoneType();
		String phoneNumber = entity.getPhoneNumber();
		String areaCode = entity.getAreaCode();
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_TELEPHONE_TYPE, telephoneType);
		if (telephoneType.equals("Home") || telephoneType.equals(StringConstants.OFFICE) || telephoneType.equals("Fax") || telephoneType.equals("Skype")) {
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_AREA_CODE);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_AREA_CODE, areaCode);
		}
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_PHONE_NUM);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_PHONE_NUM, phoneNumber);
		log.info("Add telephone details");
		page.takeScreenShoot(testCase + common.getDateFormat());
		page.waitFor(1000);
		
	}
	
	private void addClientReviews(PageInteraction page) {
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_CLIENT_REVIEW);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_CLIENT_REVIEW, "Individual Review");
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_CLIENT_REVIEW_DATE);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_CLIENT_REVIEW_DATE, "12/17");
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_CLIENT_REVIEW_FREQ, "Annually");
		page.takeScreenShoot("addClientReviews" + common.getDateFormat());
		
	}
	
	private void deleteClientReviews(PageInteraction page) {
		boolean elementPresent = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_CLIENT_REVIEW_DELETE);
		if (elementPresent) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_CLIENT_REVIEW_DELETE);
		} else {
			addClientReviews(page);
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_CLIENT_REVIEW_DELETE);
		}
		
	}
	
	private void addPublicRoles(PageInteraction page, IndividualEntityDetails entity) {
		String roles = entity.getPublicRoles();
		if (roles.equals("Auditor")) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_PUBLIC_ROLE_AUDITOR);
		}
	}
	
	private void addTag(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EDIT_TAG_BTN);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_SELECT_TAG);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_APPLY_TAG);
		
	}
	
	private void addAddressDetails(PageInteraction page, IndividualEntityDetails entity) throws InterruptedException {
		String testCase = entity.getTestCase();
		String addressType = entity.getAddressType();
		String address1 = entity.getAddress1();
		String address2 = entity.getAddress2();
		String suburb = entity.getSuburb();
		String city = entity.getCity();
		String postalCode = entity.getPostalCode();
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ADDRESS_TYPE, addressType);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ADDRESS1);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ADDRESS1, address1);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ADDRESS2);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ADDRESS2, address2);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_SUBURB);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_SUBURB, suburb);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_CITY);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_CITY, city);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_POSTAL);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_POSTAL, postalCode);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.MAIL_HERE);
		log.info("addContactDetails");
		page.takeScreenShoot(testCase + common.getDateFormat());
		page.waitFor(1000);
		
	}
	
	private void setUpTag(PageInteraction page, IndividualEntityDetails entity) throws InterruptedException {
		String testCase = entity.getTestCase();
		String tagDescription = entity.getDescription();
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.TAG_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.TAG_DESCRIPTION);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.TAG_DESCRIPTION, tagDescription);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SAVE);
		log.info("Setup tag");
		page.takeScreenShoot(testCase + common.getDateFormat());
		page.waitFor(1000);
	}
	
	private void addTask(PageInteraction page, IndividualEntityDetails entity) {
		String taskDescription = entity.getTaskDescription();
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.WORK_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CREATE_TASK);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.TASK_DESC);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.TASK_DESC, taskDescription);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.FINISH_TASK);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	private void addWorkFlow(PageInteraction page, IndividualEntityDetails entity) {
		String workflowType = entity.getWorkFlowType();
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.WORK_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CREATE_WORKFLOW);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.WORKFLOW_DESC, workflowType);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.FINISH_WORKFLOW);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	private void addNote(PageInteraction page, IndividualEntityDetails entity) {
		String noteDesc = entity.getNotesDescription();
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.NOTE_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.NOTE_DESC, noteDesc);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.NOTE_SAVE);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	private void addInteractions(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INTERACTION_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INTERACTION_TYPE, "");
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INTERACTION_SAVE);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	protected void updateIndividualDetails(PageInteraction page, IndividualEntityDetails entity) throws Exception {
		String testCase = entity.getTestCase();
		String personal = entity.getPersonal();
		String office = entity.getOffice();
		String deactivateEntity = entity.getDeActivateEntity();
		String makeEntityClient = entity.getMakeEntityClient();
		String deleteContacts = entity.getDeleteEmail();
		String addContact = entity.getAddPreferredContact();
		String compliance = entity.getCompliance();
		String work = entity.getWork();
		String createTask = entity.getCreateTask();
		String createWorkflow = entity.getCreateTask();
		String addInteraction = entity.getInteractions();
		String addNote = entity.getNotes();
		String tagSetup = entity.getSetupTags();
		if (deactivateEntity.equals("Yes")) {
			deActivateIndividualEntity(page, entity);
		}
		
		if (makeEntityClient.equals("Yes")) {
			makeEntityAClient(page);
		}
		
		if (personal.equals("Yes")) {
			addIndividualPersonalDetails(page, entity);
		}
		
		if (office.equals("Yes")) {
			addIndividualOfficeInfo(page, entity);
			addTag(page);
			addPublicRoles(page, entity);
			addClientReviews(page);
			deleteClientReviews(page);
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OFFICE_SAVE);
		}
		
		if (addContact.equals("Yes")) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CONTACT_MENU);
			page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
			addEmailAddress(page, entity);
			addTelephone(page, entity);
			addAddressDetails(page, entity);
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CONTACT_SAVE);
			page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
			
		}
		
		if (deleteContacts.equals("Yes")) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CONTACT_MENU);
			page.waitForPageToLoad();
			deleteEmailAddress(page, entity);
			deleteTelephone(page);
			deleteAddress(page);
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CONTACT_SAVE);
			page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		}
		
		if (compliance.equals("Yes")) {
			addComplianceStatus(page, entity);
		}
		
		if (tagSetup.equals("Yes")) {
			setUpTag(page, entity);
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.COMPLIANCE_SAVE);
			
		}
		
		if (work.equals("Yes")) {
			if (createTask.equals("Yes")) {
				addTask(page, entity);
			}
			
			if (createWorkflow.equals("Yes")) {
				addWorkFlow(page, entity);
			}
			
			if (addInteraction.equals("Yes")) {
				addInteractions(page);
			}
			
			if (addNote.equals("Yes")) {
				addNote(page, entity);
			}
		}
		
		if (!testCase.equals("Make Individual Client") && !testCase.equals("Deactivate Entity")) {
			
			boolean saved = common.checkUpdateSaved(page);
			if (saved) {
				testCaseSteps = common.testCaseSteps("Login,Search entity,Update Entity,Entity details updated successfully");
				reporting.generateReport(testCase, testCaseSteps, TestStatus.PASS);
			} else {
				testCaseSteps = common.testCaseSteps("Failed to update individual entity details");
				reporting.generateReport(testCase, testCaseSteps, TestStatus.FAIL);
				log.info("Failed to update individual client details");
			}
		}
	}
	
	protected List<LegalEntityDetails> retrieveLegalUpdateEntityData(PageInteraction page) {
		RetrieveTestData retrieveTestData = new RetrieveTestData(page.dataSheetLocation());
		return retrieveTestData.getLegalUpdateDTO();
	}
	
	protected void legalEntitySearch(PageInteraction page, LegalEntityDetails entity) {
		String testCase = entity.getTestCase();
		String searchValue = entity.getSearchValue();
		page.takeScreenShoot(testCase + common.getDateFormat());
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_TXT);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_TXT, searchValue);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_BTN);
		common.selectClientFromList(page);
		page.takeScreenShoot(testCase + common.getDateFormat());
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		log.info("Search for legal entity");
	}
	
	private void deActivateLegalEntity(PageInteraction page, LegalEntityDetails entity) throws InterruptedException {
		String testCase = entity.getTestCase();
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OFFICE_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		String[] steps = {StringConstants.LOGIN, StringConstants.SEARCH_ENTITY, "Deactivate entity"};
		testCaseSteps = Arrays.asList(steps);
		boolean isElementPresent = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DEACTIVATE_CLIENT);
		if (isElementPresent) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DEACTIVATE_CLIENT);
			validateLegalEntityDeactivated(page, entity);
			reporting.generateReport(testCase, testCaseSteps, TestStatus.PASS);
			log.info("Deactivate legal entity");
			page.takeScreenShoot(testCase + common.getDateFormat());
		} else {
			reporting.generateReport(testCase, testCaseSteps, TestStatus.FAIL);
			page.takeScreenShoot(testCase + common.getDateFormat());
			log.info("Element cannot be deactivated");
		}
	}
	
	private void validateLegalEntityDeactivated(PageInteraction page, LegalEntityDetails entity) throws InterruptedException {
		String searchValue = entity.getSearchValue();
		String alertMessage = page.getAlertText();
		String expectedAlertMessage = "Please confirm that this entity should be deactivated?";
		try {
			common.assertEquals(alertMessage, expectedAlertMessage);
		} catch (Exception ex) {
			log.info(ex.getMessage());
		}
		page.acceptAlert();
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_INCLUDE_DELETED);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_TXT, searchValue);
		page.waitFor(2000);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_BTN);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		log.info("Validate legal entity deactivated");
	}
	
	private void addLegalEntityPersonalDetails(PageInteraction page, LegalEntityDetails entity) throws Exception {
		String testCase = entity.getTestCase();
		String employeeNum = entity.getNumberOfEmployees();
		String entityType = entity.getEntityType();
		String tradeName = entity.getTradeName();
		String value = entity.getTotalPayRoleValue();
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_PERSONAL_DETAILS);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEGAL_ENTITY_TYPE, entityType);
		
		if (!entityType.equals("Trust")) {
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_LEGAL_EMPLOYEE_NUM);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_LEGAL_EMPLOYEE_NUM, employeeNum);
		}
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_LEGAL_TRADE_NAME);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_LEGAL_TRADE_NAME, tradeName);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_LEGAL_VALUE);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_LEGAL_VALUE, value);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_LEGAL_PERSONAL_SAVE);
		common.checkUpdateSaved(page);
		log.info("Add legal personal details");
		page.takeScreenShoot(testCase + common.getDateFormat());
	}
	
	private void addLegalEntityOfficeDetails(PageInteraction page, LegalEntityDetails entity) throws Exception {
		String testCase = entity.getTestCase();
		String estimatedNav = entity.getEstimatedNAV();
		String incomeClass = entity.getIncomeClass();
		String grossIncome = entity.getGrossIncome();
		String company = entity.getCompanyInfo();
		String office = entity.getOfficeInfo();
		
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OFFICE_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_COMPANY, company);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_OFFICE, office);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_LEGAL_NAV_VALUE);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_LEGAL_NAV_VALUE, estimatedNav);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_LEGAL_CLASS, incomeClass);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_GROSS_VALUE);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_GROSS_VALUE, grossIncome);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_LEGAL_OFFICE_SAVE);
		common.checkUpdateSaved(page);
		log.info("Add legal office details");
		page.takeScreenShoot(testCase + common.getDateFormat());
	}
	
	private void addLegalPreferredContactDetails(PageInteraction page, LegalEntityDetails entity) {
		String preferredContact = entity.getPreferredContact();
		String meetingPlace = entity.getMeetingPlace();
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_PREFERRED_CONTACT, preferredContact);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_MEETING_PLACE, meetingPlace);
	}
	
	private void addLegalEmailAddress(PageInteraction page, LegalEntityDetails entity) {
		String testCase = entity.getTestCase();
		String emailType = entity.getEmailType();
		String emailAddress = entity.getEmailAddress();
		addLegalPreferredContactDetails(page, entity);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMAIL_TYPE, emailType);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMAIL);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMAIL, emailAddress);
		page.takeScreenShoot(testCase + common.getDateFormat());
	}
	
	private void deleteLegalEmailAddress(PageInteraction page, LegalEntityDetails entity) {
		String testCase = entity.getTestCase();
		boolean deletePresent = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DELETE_EMAIL);
		if (deletePresent) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DELETE_EMAIL);
		}
		page.takeScreenShoot(testCase + common.getDateFormat());
	}
	
	private void addLegalTelephone(PageInteraction page, LegalEntityDetails entity) {
		String testCase = entity.getTestCase();
		String telephoneType = entity.getTelephoneType();
		String phoneNumber = entity.getPhoneNumber();
		String areaCode = entity.getAreaCode();
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_TELEPHONE_TYPE, telephoneType);
		if (telephoneType.equals("Home") || telephoneType.equals(StringConstants.OFFICE) || telephoneType.equals("Fax") || telephoneType.equals("Skype")) {
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_AREA_CODE);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_AREA_CODE, areaCode);
		}
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_PHONE_NUM);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_PHONE_NUM, phoneNumber);
		log.info("Telephone details added to legal entity");
		page.takeScreenShoot(testCase + common.getDateFormat());
		
	}
	
	private void addLegalAddressDetails(PageInteraction page, LegalEntityDetails entity) {
		String addressType = entity.getAddressType();
		String address1 = entity.getAddress1();
		String address2 = entity.getAddress2();
		String suburb = entity.getSuburb();
		String city = entity.getCity();
		String postalCode = entity.getPostalCode();
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ADDRESS_TYPE, addressType);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ADDRESS1);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ADDRESS1, address1);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ADDRESS2);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ADDRESS2, address2);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_SUBURB);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_SUBURB, suburb);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_CITY);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_CITY, city);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_POSTAL);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_POSTAL, postalCode);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.MAIL_HERE);
		
	}
	
	private void addLegalComplianceStatus(PageInteraction page, LegalEntityDetails entity) {
		String testCase = entity.getTestCase();
		String updateStatus = entity.getUpdateStatus();
		String effectiveDateCompliance = entity.getEffectiveDate();
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.COMPLIANCE_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		boolean onCompliancePage = page.isElementPresent(ElementConstants.HOME_PAGE_NAME, ElementConstants.COMPLIANCE_PAGE);
		if (onCompliancePage) {
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_KYC_STATUS, updateStatus);
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.EFFECTIVE_DATE);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.EFFECTIVE_DATE, effectiveDateCompliance);
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.UPDATE_KYC);
			page.takeScreenShoot(testCase + common.getDateFormat());
		} else {
			page.takeScreenShoot(testCase + common.getDateFormat());
			log.info("Failed to reach the compliance page");
		}
		page.selectNonInteractiveItem(ElementConstants.HOME_PAGE_NAME, ElementConstants.SAVE);
	}
	
	protected void updateLegalEntity(PageInteraction page, LegalEntityDetails entity) throws Exception {
		String testCase = entity.getTestCase();
		String deactivate = entity.getDeActivateEntity();
		String personal = entity.getPersonal();
		String office = entity.getOffice();
		String makeEntityClient = entity.getMakeEntityClient();
		String compliance = entity.getCompliance();
		String deleteContact = entity.getDeleteEmail();
		String addContact = entity.getAddPreferredContact();
		
		if (personal.equals("Yes")) {
			addLegalEntityPersonalDetails(page, entity);
		}
		
		if (deactivate.equals("Yes")) {
			deActivateLegalEntity(page, entity);
		}
		
		if (makeEntityClient.equals("Yes")) {
			makeEntityAClient(page);
		}
		
		if (office.equals("Yes")) {
			addLegalEntityOfficeDetails(page, entity);
		}
		
		if (addContact.equals("Yes")) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CONTACT_MENU);
			page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
			addLegalEmailAddress(page, entity);
			addLegalTelephone(page, entity);
			addLegalAddressDetails(page, entity);
			page.selectNonInteractiveItem(ElementConstants.HOME_PAGE_NAME, ElementConstants.CONTACT_SAVE);
			page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
			common.checkUpdateSaved(page);
			
		}
		
		if (deleteContact.equals("Yes")) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CONTACT_MENU);
			page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
			deleteLegalEmailAddress(page, entity);
			deleteTelephone(page);
			deleteAddress(page);
			page.selectNonInteractiveItem(ElementConstants.HOME_PAGE_NAME, ElementConstants.CONTACT_SAVE);
			page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
			
		}
		
		if (compliance.equals("Yes")) {
			addLegalComplianceStatus(page, entity);
		}
		
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.COMPLIANCE_SAVE);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		boolean saved = common.checkUpdateSaved(page);
		
		if (saved) {
			testCaseSteps = common.testCaseSteps("Login,Search entity,Update Legal Entity,Legal Entity details updated successfully");
			reporting.generateReport(testCase, testCaseSteps, TestStatus.PASS);
		} else {
			testCaseSteps = common.testCaseSteps("Failed to update legal entity details successfully");
			reporting.generateReport(testCase, testCaseSteps, TestStatus.FAIL);
			log.info("Failed to update legal client details");
		}
		
	}
	
	private void addTelephoneForDelete(PageInteraction page) throws Exception {
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_TELEPHONE_TYPE, "Home");
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_PHONE_NUM);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_PHONE_NUM, "731254647");
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CONTACT_SAVE);
		common.checkUpdateSaved(page);
		log.info("Client telephone info for delete added");
		
	}
	
	private void addAddressForDelete(PageInteraction page) throws Exception {
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ADDRESS_TYPE, "Home");
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ADDRESS1);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ADDRESS1, "09 Fredmen Drive");
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ADDRESS2);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ADDRESS2, "05 Merchant Place");
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_SUBURB);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_SUBURB, "Sundown");
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_CITY);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_CITY, "Sandton");
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_POSTAL);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_POSTAL, "2195");
		page.takeScreenShoot("addContactDetails" + common.getDateFormat());
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CONTACT_SAVE);
		common.checkUpdateSaved(page);
		log.info("Client address info for delete added");
	}
	
	private void deleteTelephone(PageInteraction page) throws Exception {
		String deleted = "\n" + "Telephone details deleted" + "\n".toUpperCase();
		String notDeleted = "NO Telephone details added yet" + "\n";
		page.waitFor(2000);
		boolean canBeDeleted = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DELETE_TELEPHONE1);
		if (canBeDeleted) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DELETE_TELEPHONE);
			page.takeScreenShoot(deleted + common.getDateFormat());
			log.info(deleted);
		} else {
			log.info(notDeleted);
			page.waitFor(2000);
			addTelephoneForDelete(page);
			log.info("Added , Start the delete process");
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DELETE_TELEPHONE);
			page.takeScreenShoot(deleted + common.getDateFormat());
			log.info(deleted);
		}
		page.waitFor(2000);
	}
	
	private void deleteAddress(PageInteraction page) throws Exception {
		String deleted = "\n" + "Telephone details deleted" + "\n".toUpperCase();
		String notDeleted = "NO Telephone details added yet" + "\n";
		page.waitFor(2000);
		boolean canBeDeleted = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DELETE_ADDRESS);
		if (canBeDeleted) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DELETE_ADDRESS);
			page.takeScreenShoot(deleted + common.getDateFormat());
			log.info(deleted);
		} else {
			log.info(notDeleted);
			page.waitFor(2000);
			addAddressForDelete(page);
			log.info("Added , Start the delete process");
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DELETE_ADDRESS);
			page.takeScreenShoot(deleted + common.getDateFormat());
			log.info(deleted);
		}
		page.waitFor(2000);
	}
	
}
