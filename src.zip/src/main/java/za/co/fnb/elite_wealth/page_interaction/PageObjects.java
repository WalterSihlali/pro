package za.co.fnb.elite_wealth.page_interaction;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import za.co.fnb.elite_wealth.config.EnvironmentConstant;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class PageObjects {

	private static Document doc = null;
	private Node xmlElement = null;
	private Map<String, String> mapElement = new HashMap();
	private String doubleSlash ="//";
	private static Logger log = org.apache.log4j.Logger.getLogger(PageObjects.class);
	public String getXmlElementNode() {
		return xmlElementNode;
	}

	public void setXmlElementNode(String xmlElementNode) {
		this.xmlElementNode = xmlElementNode;
	}

	private String xmlElementNode = "element";


	protected static String pageObject = EnvironmentConstant.PAGE_OBJECT_DIR + "PageObjects.xml";
	private static final String FileName = pageObject;
	String xmlPageNode = "page";

	public Node getXmlElement() {
		return xmlElement;
	}

	public Map<String, String> getMapElement() {
		return mapElement;
	}

	public void getDOM(String xmlFileName) throws Exception {
		File fXmlFile = new File(xmlFileName);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		doc = dBuilder.parse(fXmlFile);
		doc.getDocumentElement().normalize();
	}

	public NodeList getAllElementsInModule(String strModuleName, String xmlPageNode) {

		NodeList nodeModules = null;
		try {
			XPathFactory factory = XPathFactory.newInstance();
			XPath xpath = factory.newXPath();

			String strXpath = doubleSlash + xmlPageNode + "[@name='" + strModuleName + "']//*";
			XPathExpression expr = xpath.compile(strXpath);
			Object result = expr.evaluate(doc, XPathConstants.NODESET);
			nodeModules = (NodeList) result;
		} catch (Exception e) {
			log.info(e.getStackTrace());

		}
		return nodeModules;
	}

	//Return xml element xpath
	public void getXmlElement(String strElementName, String xmlElementNode) {
		String strXpath;
		try {
			XPathFactory factory = XPathFactory.newInstance();
			XPath xpath = factory.newXPath();

			if (strElementName.contains(".")) {
				String strPage = strElementName.split("\\.")[0];
				String strElement = strElementName.split("\\.")[1];
				strXpath = doubleSlash + xmlElement + "[@name='" + strPage + "']/element[@name='" + strElement + "']";
			} else {
				strXpath = doubleSlash + xmlElementNode + "[@name='" + strElementName + "']";
			}
			XPathExpression expr = xpath.compile(strXpath);
			Object result = expr.evaluate(doc, XPathConstants.NODE);
			xmlElement = (Node) result;
		} catch (Exception e) {
			log.info(e.getStackTrace());
		}
	}

	public void getElementProperties() {
		try {
			if (xmlElement != null) {
				mapElement.put("name", xmlElement.getAttributes().getNamedItem("name").getNodeValue());
				if (xmlElement.getAttributes().getNamedItem("mandatory") != null) {
					mapElement.put("mandatory", xmlElement.getAttributes().getNamedItem("mandatory").getNodeValue());
				}
				mapElement.put("by", xmlElement.getAttributes().getNamedItem("by").getNodeValue());
				mapElement.put("identifier", xmlElement.getAttributes().getNamedItem("identifier").getNodeValue());
			}
		} catch (Exception e) {
			log.info(e.getStackTrace());
		}
	}

	public String getIdentifier(String xmlPageName, String strElementName) {
		try {
			getDOM(FileName);
		} catch (Exception e) {
			log.info(e.getStackTrace());
		}
		elementsOnModule(xmlPageName, strElementName);
		String strIdentifier = null;
		if (!mapElement.isEmpty()) {
			strIdentifier = mapElement.get("identifier");
			mapElement.clear();
		}
		return strIdentifier;
	}

	private void elementsOnModule(String xmlPageName, String strElementName) {
		getAllElementsInModule(xmlPageNode, xmlPageName);
		getAllElementsInModule(xmlPageName, xmlPageNode);
		getXmlElement(strElementName, xmlElementNode);
		getElementProperties();
	}

	public enum Identifier {
		css(1), xpath(2), name(3), linkText(4),
		id(5), partialLinkText(6), tagName(7), className(8);

		private int value;

		private Identifier(int value) {
			this.value = value;
		}
	}

	public By getByElement(String xmlPageName, String strElementName) {
		By by = null;
		try {
			getDOM(FileName);
			elementsOnModule(xmlPageName, strElementName);
			if (!mapElement.isEmpty()) {
				String strBy = mapElement.get("by");

				Identifier id = Identifier.valueOf(strBy);
				switch (id) {
					case css:
						by = By.cssSelector(getIdentifier(xmlPageName, strElementName));
						break;
					case xpath:
						by = By.xpath(getIdentifier(xmlPageName, strElementName));
						break;
					case name:
						by = By.name(getIdentifier(xmlPageName, strElementName));
						break;
					case linkText:
						by = By.linkText(getIdentifier(xmlPageName, strElementName));
						break;
					case id:
						by = By.id(getIdentifier(xmlPageName, strElementName));
						break;
					case partialLinkText:
						by = By.partialLinkText(getIdentifier(xmlPageName, strElementName));
						break;
					case tagName:
						by = By.tagName(getIdentifier(xmlPageName, strElementName));
						break;
					case className:
						by = By.className(getIdentifier(xmlPageName, strElementName));
						break;
					default:
						break;
				}
				mapElement.clear();
			}
		} catch (Exception e) {
			log.info(e.getStackTrace());
		}
		return by;
	}

	public String getMandatoryIndicator(String xmlPageName, String strElementName) {
		try {
			getDOM(FileName);
		} catch (Exception e) {
			log.info(e.getStackTrace());
		}
		elementsOnModule(xmlPageName, strElementName);
		String strIndicator = null;
		if (!mapElement.isEmpty()) {
			strIndicator = mapElement.get("mandatory");
		}
		mapElement.clear();
		return strIndicator;
	}
}
