package za.co.fnb.elite_wealth.environments.generic;

public interface GenericEnv  {
}
