package za.co.fnb.elite_wealth.module.client.test;

import org.apache.log4j.Logger;
import org.junit.Test;
import za.co.fnb.elite_wealth.module.client.dto.LegalEntityDetails;
import za.co.fnb.elite_wealth.module.client.test.base.EntityDetailsBase;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;

public class LegalEntityUpdateTest extends EntityDetailsBase {

    private static Logger log = Logger.getLogger(LegalEntityUpdateTest.class);

    @Test
    public void legalEntityUpdateTest(){
        try {
            PageInteraction page =new PageInteraction(driver);
            firstSteps(page);
            for (LegalEntityDetails entity : retrieveLegalUpdateEntityData(page)) {
                legalEntitySearch(page, entity);
                updateLegalEntity(page,entity);
                lastSteps(page);
            }
        } catch (Exception ex) {
            log.info(ex.getMessage());
        }
    }
}
