package za.co.fnb.elite_wealth.module.client.test.base;

import org.apache.log4j.Logger;
import za.co.fnb.elite_wealth.config.ElementConstants;
import za.co.fnb.elite_wealth.config.SeleniumService;
import za.co.fnb.elite_wealth.module.client.dto.NewRelatedEntity;
import za.co.fnb.elite_wealth.module.common.CommonActions;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;
import za.co.fnb.elite_wealth.reporting.HtmlReporting;
import za.co.fnb.elite_wealth.reporting.TestStatus;
import za.co.fnb.elite_wealth.util.RetrieveTestData;

import java.util.List;

public class RelatedEntityBase extends SeleniumService {
	private HtmlReporting reporting = new HtmlReporting();
	private List<String> testCaseSteps;
	public static final Logger log = Logger.getLogger(RelatedEntityBase.class);
	private CommonActions common = new CommonActions();
	
	protected List<NewRelatedEntity> retrieveRelatedEntityData(PageInteraction page) {
		RetrieveTestData retrieveTestData = new RetrieveTestData(page.dataSheetLocation());
		return retrieveTestData.getRelatedDTO();
	}
	
	public void firstSteps(PageInteraction page) {
		boolean element = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_INFO_TAB);
		if (element) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_INFO_TAB);
		}
	}
	
	public void lastSteps(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SELECT_ENTITY);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	protected void addNewRelatedEntity(PageInteraction page, NewRelatedEntity entity) throws InterruptedException {
		String entityType = entity.getEntityType();
		if (entityType.equals("Individual")) {
			addNewIndividualRelatedEntity(page, entity);
			log.info("Add individual related entity");
		}
		
		if (entityType.equals("Legal entity")) {
			addNewLegalRelatedEntity(page, entity);
			log.info("Add legal related entity");
		}
		
	}
	
	private void addNewIndividualRelatedEntity(PageInteraction page, NewRelatedEntity entity) throws InterruptedException {
		String entityType = entity.getEntityType();
		String relation = entity.getRelation();
		String title = entity.getTitle();
		String surname = entity.getSurname();
		String firstName = entity.getFirstName();
		String relationship = entity.getRelationship();
		String relatedClient = entity.getRelatedClient();
		
		boolean relatedButton = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_ENTITY_BTN);
		if (relatedButton) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_ENTITY_BTN);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ENTITY_TYPE, entityType);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_IND_RELATION, relation);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_TITLE, title);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_SURNAME, surname);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_FIRST_NAME, firstName);
			
			if (relation.equals("Related entity")) {
				page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_IND_RELATIONSHIP, relationship);
				page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_IND_CLIENT, relatedClient);
				page.sendKeyEnter();
				page.waitFor(5000);
				boolean dataReturned = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_FIRST_ITEM);
				if (dataReturned) {
					page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_FIRST_ITEM);
					page.takeScreenShoot("addIndividualRelatedEntity" + common.getDateFormat());
				} else {
					log.info("No related clients data from database");
					page.takeScreenShoot("addIndividualRelatedEntityError" + common.getDateFormat());
				}
			}
		}
		saveIndividualRelatedEntity(page, entity);
	}
	
	private void addNewLegalRelatedEntity(PageInteraction page, NewRelatedEntity entity) throws InterruptedException {
		String entityType = entity.getEntityType();
		String entityLegaType = entity.getEntityLegalType();
		String relation = entity.getRelation();
		String regName = entity.getRegisteredName();
		String relationship = entity.getRelationship();
		String relatedClient = entity.getRelatedClient();
		boolean relatedButton = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_ENTITY_BTN);
		
		if (relatedButton) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_ENTITY_BTN);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_LEGAL_ENTITY_TYPE, entityType);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_LAGAL_RELATION, relation);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_LEGAL_TYPE, entityLegaType);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_REG_NAME, regName);
			
			if (relation.equals("Related entity")) {
				page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_LEGAL_RELATIONSHIP, relationship);
				page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_LEGAL_CLIENT, relatedClient);
				page.sendKeyEnter();
				page.waitFor(5000);
				boolean dataReturned = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_FIRST_ITEM);
				
				if (dataReturned) {
					page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_FIRST_ITEM);
					page.takeScreenShoot("addLegalRelatedEntity" + common.getDateFormat());
					
				} else {
					log.info("No related clients data from database");
					page.takeScreenShoot("addLegalRelatedEntityError" + common.getDateFormat());
				}
			}
			
		}
		saveLegalRelatedEntity(page, entity);
	}
	
	
	private void saveLegalRelatedEntity(PageInteraction page, NewRelatedEntity entity) throws InterruptedException {
		String testCase = entity.getTestCase();
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_SAVE);
		boolean alertPresent = page.isAlertPresent();
		if (alertPresent) {
			page.acceptAlert();
			page.waitFor(2000);
			testCaseSteps = common.testCaseSteps("Login,Search entity,Add Legal Related Entity,Related Entity added successfully");
			reporting.generateReport(testCase, testCaseSteps, TestStatus.PASS);
		} else {
			testCaseSteps = common.testCaseSteps("Failed to to add legal related entity");
			reporting.generateReport(testCase, testCaseSteps, TestStatus.FAIL);
			log.info("Failed to to add legal related entity");
		}
	}
	
	private void saveIndividualRelatedEntity(PageInteraction page, NewRelatedEntity entity) throws InterruptedException {
		String testCase = entity.getTestCase();
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_SAVE);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		boolean alertPresent = page.isAlertPresent();
		if (alertPresent) {
			page.acceptAlert();
			page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
			page.waitFor(2000);
			testCaseSteps = common.testCaseSteps("Login,Search entity," + testCase);
			reporting.generateReport(testCase, testCaseSteps, TestStatus.PASS);
			
		} else {
			testCaseSteps = common.testCaseSteps("Failed to to add individual related entity");
			reporting.generateReport(testCase, testCaseSteps, TestStatus.FAIL);
			log.info("Failed to to add individual related entity");
		}
	}
}
