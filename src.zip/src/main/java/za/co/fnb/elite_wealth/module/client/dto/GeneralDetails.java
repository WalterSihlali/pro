package za.co.fnb.elite_wealth.module.client.dto;

import java.util.List;

public class GeneralDetails {
	private String testCase;
	private String testScenario;
	private String searchValue;
	private String includeAccounDetails;
	private String accountHolder;
	private String primaryAccount;
	private String bankAccount;
	private String bankAccountType;
	private String bankAccountNumber;
	private String bankBranch;
	private String deleteAccounDetails;

	private String includeTaxDetails;
	private String taxNumber;
	private String taxCounty;
	private String taxPayerRegistered;
	private String provisionalTaxpayer;
	private String taxRate;
	private String deleteTaxDetails;

	private String includeWillDetails;
	private String willExecutor;
	private String executorType;
	private String firstName;
	private String otherSurname;
	private String localWill;
	private String offshoreWill;
	private String livingWill;
	private String estatePlanning;
	private String lastUpdate;
	private String deleteWillDetails;

	private String includeAuditDetails;
	private String auditors;
	private String deleteAuditDetails;

	private String includeMedicalAidDetails;
	private String medicalAid;
	private String medicalAidNumber;
	private String medicalPlan;
	private String deleteMedicalAidDetails;

	private String includeEmploymentDetails;
	private String employer;
	private String department;
	private String marketSegment;
	private String occupation;
	private String employmentStatus;
	private String startDate;
	private String endDate;
	private String salaryReviewDate;
	private String deleteEmploymentDetails;

	private String includeQualificationDetails;
	private String qualification;
	private String institution;
	private String dateQualified;
	private String deleteQualification;

	private String includeInterests;
	private String details;
	private String deleteInterests;

	public GeneralDetails(List<String> entity){
		int  TEST_CASE =0;
		int  TEST_SCENARIO =1;
		int  SEARCH_VALUE =2;

		int  INCLUDE_ACCOUNT_DETAILS =3;
		int  ACC_HOLDER =4;
		int  PRIMARY_ACC=5;
		int  BANK_ACC=6;
		int  BANK_ACC_TYPE=7;
		int  BANK_ACC_NUMBER=8;
		int  BANK_BRANCH=9;
		int  DELETE_BANK_ACC=10;

		int  INCLUDE_TAX_DETAILS =11;
		int  TAX_NUMBER =12;
		int  TAX_COUNTRY=13;
		int  TAX_PAY_REG =14;
		int  PROVISIONAL_TAX=15;
		int  TAX_RATE =16;
		int  DELETE_TAX_DETAILS =17;

		int  INCLUDE_WILL_DETAILS =18;
		int  WILL_EXECUTOR =19;
		int  EXECUTOR_TYPE = 20;
		int  FIRST_NAME = 21;
		int  OTHER_SURNAME = 22;
		int  LOCAL_WILL = 23;
		int  OFFSHORE_WILL = 24;
		int  LIVING_WILL = 25;
		int  ESTATE_PLANNING = 26;
		int  LAST_UPDATE = 27;
		int  DELETE_WILL_DETAILS =28;

		int  INCLUDE_AUDIT_DETAILS = 29;
		int  AUDITORS = 30;
		int  DELETE_AUDIT_DETAILS = 31;

		int  INCLUDE_MEDICAL_DETAILS = 32;
		int  MEDICAL_AID = 33;
		int  MEDICAL_NUM = 34;
		int  MEDICAL_PLAN = 35;
		int  DELETE_MEDICAL_DETAILS = 36;

		int  INCLUDE_EMPLOYMENT_DETAILS = 37;
		int  EMPLOYER = 38;
		int  DEPARTMENT = 39;
		int  MARKET_SEGMENT = 40;
		int  OCCUPATION = 41;
		int  EMPLOYMENT_STATUS = 42;
		int  START_DATE = 43;
		int  END_DATE = 44;
		int  SALARY_REVIEW_DATE = 45;
		int  DELETE_EMPLOYMENT_DETAILS = 46;

		int  INCLUDE_QUALIFICATION_DETAILS =47;
		int  QUALIFICATION =48;
		int  INSTITUTION=49;
		int  DATE_QUALIFIED=50;
		int  DELETE_QUALIFICATION_DETAILS =51;

		int  INCLUDE_INTERESTS =52;
		int  DETAILS=53;
		int  DELETE_INTERESTS =54;


		setTestCase(entity.get(TEST_CASE));
		setTestScenario(entity.get(TEST_SCENARIO));
		setSearchValue(entity.get(SEARCH_VALUE));

		setIncludeAccounDetails(entity.get(INCLUDE_ACCOUNT_DETAILS));
		setAccountHolder(entity.get(ACC_HOLDER));
		setPrimaryAccount(entity.get(PRIMARY_ACC));
		setBankAccount(entity.get(BANK_ACC));
		setBankAccountType(entity.get(BANK_ACC_TYPE));
		setBankAccountNumber(entity.get(BANK_ACC_NUMBER));
		setBankBranch(entity.get(BANK_BRANCH));
		setDeleteAccounDetails(entity.get(DELETE_BANK_ACC));

		setIncludeTaxDetails(entity.get(INCLUDE_TAX_DETAILS));
		setTaxNumber(entity.get(TAX_NUMBER));
		setTaxCounty(entity.get(TAX_COUNTRY));
		setTaxPayerRegistered(entity.get(TAX_PAY_REG));
		setProvisionalTaxpayer(entity.get(PROVISIONAL_TAX));
		setTaxRate(entity.get(TAX_RATE));
		setDeleteTaxDetails(entity.get(DELETE_TAX_DETAILS));

		setIncludeWillDetails(entity.get(INCLUDE_WILL_DETAILS));
		setWillExecutor(entity.get(WILL_EXECUTOR));
		setExecutorType(entity.get(EXECUTOR_TYPE));
		setFirstName(entity.get(FIRST_NAME));
		setOtherSurname(entity.get(OTHER_SURNAME));
		setLocalWill(entity.get(LOCAL_WILL));
		setOffshoreWill(entity.get(OFFSHORE_WILL));
		setLivingWill(entity.get(LIVING_WILL));
		setEstatePlanning(entity.get(ESTATE_PLANNING));
		setLastUpdate(entity.get(LAST_UPDATE));
		setDeleteWillDetails(entity.get(DELETE_WILL_DETAILS));

		setIncludeAuditDetails(entity.get(INCLUDE_AUDIT_DETAILS));
		setAuditors(entity.get(AUDITORS));
		setDeleteAuditDetails(entity.get(DELETE_AUDIT_DETAILS));

		setIncludeMedicalAidDetails(entity.get(INCLUDE_MEDICAL_DETAILS));
		setMedicalAid(entity.get(MEDICAL_AID));
		setMedicalAidNumber(entity.get(MEDICAL_NUM));
		setMedicalPlan(entity.get(MEDICAL_PLAN));
		setDeleteMedicalAidDetails(entity.get(DELETE_MEDICAL_DETAILS));

		setIncludeEmploymentDetails(entity.get(INCLUDE_EMPLOYMENT_DETAILS));
		setEmployer(entity.get(EMPLOYER));
		setDepartment(entity.get(DEPARTMENT));
		setMarketSegment(entity.get(MARKET_SEGMENT));
		setOccupation(entity.get(OCCUPATION));
		setEmploymentStatus(entity.get(EMPLOYMENT_STATUS));
		setStartDate(entity.get(START_DATE));
		setEndDate(entity.get(END_DATE));
		setSalaryReviewDate(entity.get(SALARY_REVIEW_DATE));
		setDeleteEmploymentDetails(entity.get(DELETE_EMPLOYMENT_DETAILS));

		setIncludeQualificationDetails(entity.get(INCLUDE_QUALIFICATION_DETAILS));
		setQualification(entity.get(QUALIFICATION));
		setInstitution(entity.get(INSTITUTION));
		setDateQualified(entity.get(DATE_QUALIFIED));
		setDeleteQualification(entity.get(DELETE_QUALIFICATION_DETAILS));

		setIncludeInterests(entity.get(INCLUDE_INTERESTS));
		setDetails(entity.get(DETAILS));
		setDeleteInterests(entity.get(DELETE_INTERESTS));
	}

	public String getTestCase() {
		return testCase;
	}

	public void setTestCase(String testCase) {
		this.testCase = testCase;
	}

	public String getTestScenario() {
		return testScenario;
	}

	public void setTestScenario(String testScenario) {
		this.testScenario = testScenario;
	}

	public String getSearchValue() {
		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}
	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getIncludeAccounDetails() {
		return includeAccounDetails;
	}

	public void setIncludeAccounDetails(String includeAccounDetails) {
		this.includeAccounDetails = includeAccounDetails;
	}

	public String getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}

	public String getPrimaryAccount() {
		return primaryAccount;
	}

	public void setPrimaryAccount(String primaryAccount) {
		this.primaryAccount = primaryAccount;
	}

	public String getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}

	public String getBankAccountType() {
		return bankAccountType;
	}

	public void setBankAccountType(String bankAccountType) {
		this.bankAccountType = bankAccountType;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public String getBankBranch() {
		return bankBranch;
	}

	public void setBankBranch(String bankBranch) {
		this.bankBranch = bankBranch;
	}

	public String getDeleteAccounDetails() {
		return deleteAccounDetails;
	}

	public void setDeleteAccounDetails(String deleteAccounDetails) {
		this.deleteAccounDetails = deleteAccounDetails;
	}

	public String getIncludeTaxDetails() {
		return includeTaxDetails;
	}

	public void setIncludeTaxDetails(String includeTaxDetails) {
		this.includeTaxDetails = includeTaxDetails;
	}

	public String getTaxNumber() {
		return taxNumber;
	}

	public void setTaxNumber(String taxNumber) {
		this.taxNumber = taxNumber;
	}

	public String getTaxCounty() {
		return taxCounty;
	}

	public void setTaxCounty(String taxCounty) {
		this.taxCounty = taxCounty;
	}

	public String getTaxPayerRegistered() {
		return taxPayerRegistered;
	}

	public void setTaxPayerRegistered(String taxPayerRegistered) {
		this.taxPayerRegistered = taxPayerRegistered;
	}

	public String getProvisionalTaxpayer() {
		return provisionalTaxpayer;
	}

	public void setProvisionalTaxpayer(String provisionalTaxpayer) {
		this.provisionalTaxpayer = provisionalTaxpayer;
	}

	public String getTaxRate() {
		return taxRate;
	}

	public void setTaxRate(String taxRate) {
		this.taxRate = taxRate;
	}

	public String getDeleteTaxDetails() {
		return deleteTaxDetails;
	}

	public void setDeleteTaxDetails(String deleteTaxDetails) {
		this.deleteTaxDetails = deleteTaxDetails;
	}

	public String getIncludeWillDetails() {
		return includeWillDetails;
	}

	public void setIncludeWillDetails(String includeWillDetails) {
		this.includeWillDetails = includeWillDetails;
	}

	public String getWillExecutor() {
		return willExecutor;
	}

	public void setWillExecutor(String willExecutor) {
		this.willExecutor = willExecutor;
	}

	public String getExecutorType() {
		return executorType;
	}

	public void setExecutorType(String executorType) {
		this.executorType = executorType;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getOtherSurname() {
		return otherSurname;
	}

	public void setOtherSurname(String otherSurname) {
		this.otherSurname = otherSurname;
	}

	public String getLocalWill() {
		return localWill;
	}

	public void setLocalWill(String localWill) {
		this.localWill = localWill;
	}

	public String getOffshoreWill() {
		return offshoreWill;
	}

	public void setOffshoreWill(String offshoreWill) {
		this.offshoreWill = offshoreWill;
	}

	public String getLivingWill() {
		return livingWill;
	}

	public void setLivingWill(String livingWill) {
		this.livingWill = livingWill;
	}

	public String getEstatePlanning() {
		return estatePlanning;
	}

	public void setEstatePlanning(String estatePlanning) {
		this.estatePlanning = estatePlanning;
	}

	public String getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(String lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public String getDeleteWillDetails() {
		return deleteWillDetails;
	}

	public void setDeleteWillDetails(String deleteWillDetails) {
		this.deleteWillDetails = deleteWillDetails;
	}

	public String getIncludeAuditDetails() {
		return includeAuditDetails;
	}

	public void setIncludeAuditDetails(String includeAuditDetails) {
		this.includeAuditDetails = includeAuditDetails;
	}

	public String getAuditors() {
		return auditors;
	}

	public void setAuditors(String auditors) {
		this.auditors = auditors;
	}

	public String getDeleteAuditDetails() {
		return deleteAuditDetails;
	}

	public void setDeleteAuditDetails(String deleteAuditDetails) {
		this.deleteAuditDetails = deleteAuditDetails;
	}

	public String getIncludeMedicalAidDetails() {
		return includeMedicalAidDetails;
	}

	public void setIncludeMedicalAidDetails(String includeMedicalAidDetails) {
		this.includeMedicalAidDetails = includeMedicalAidDetails;
	}

	public String getMedicalAid() {
		return medicalAid;
	}

	public void setMedicalAid(String medicalAid) {
		this.medicalAid = medicalAid;
	}

	public String getMedicalAidNumber() {
		return medicalAidNumber;
	}

	public void setMedicalAidNumber(String medicalAidNumber) {
		this.medicalAidNumber = medicalAidNumber;
	}

	public String getMedicalPlan() {
		return medicalPlan;
	}

	public void setMedicalPlan(String medicalPlan) {
		this.medicalPlan = medicalPlan;
	}

	public String getDeleteMedicalAidDetails() {
		return deleteMedicalAidDetails;
	}

	public void setDeleteMedicalAidDetails(String deleteMedicalAidDetails) {
		this.deleteMedicalAidDetails = deleteMedicalAidDetails;
	}

	public String getIncludeEmploymentDetails() {
		return includeEmploymentDetails;
	}

	public void setIncludeEmploymentDetails(String includeEmploymentDetails) {
		this.includeEmploymentDetails = includeEmploymentDetails;
	}

	public String getEmployer() {
		return employer;
	}

	public void setEmployer(String employer) {
		this.employer = employer;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getMarketSegment() {
		return marketSegment;
	}

	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getEmploymentStatus() {
		return employmentStatus;
	}

	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getSalaryReviewDate() {
		return salaryReviewDate;
	}

	public void setSalaryReviewDate(String salaryReviewDate) {
		this.salaryReviewDate = salaryReviewDate;
	}

	public String getDeleteEmploymentDetails() {
		return deleteEmploymentDetails;
	}

	public void setDeleteEmploymentDetails(String deleteEmploymentDetails) {
		this.deleteEmploymentDetails = deleteEmploymentDetails;
	}

	public String getIncludeQualificationDetails() {
		return includeQualificationDetails;
	}

	public void setIncludeQualificationDetails(String includeQualificationDetails) {
		this.includeQualificationDetails = includeQualificationDetails;
	}

	public String getInstitution() {
		return institution;
	}

	public void setInstitution(String institution) {
		this.institution = institution;
	}

	public String getDateQualified() {
		return dateQualified;
	}

	public void setDateQualified(String dateQualified) {
		this.dateQualified = dateQualified;
	}

	public String getDeleteQualification() {
		return deleteQualification;
	}

	public void setDeleteQualification(String deleteQualification) {
		this.deleteQualification = deleteQualification;
	}

	public String getIncludeInterests() {
		return includeInterests;
	}

	public void setIncludeInterests(String includeInterests) {
		this.includeInterests = includeInterests;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getDeleteInterests() {
		return deleteInterests;
	}

	public void setDeleteInterests(String deleteInterests) {
		this.deleteInterests = deleteInterests;
	}

}
