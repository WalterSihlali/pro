package za.co.fnb.elite_wealth.util;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import za.co.fnb.elite_wealth.module.assets_and_liabilities.dto.AssetsAndLiabilities;
import za.co.fnb.elite_wealth.module.assets_and_liabilities.dto.AssetsAndLiabilitiesDetails;
import za.co.fnb.elite_wealth.module.budget.dto.Budget;
import za.co.fnb.elite_wealth.module.common.LoginDetail;
import za.co.fnb.elite_wealth.module.client.dto.*;
import za.co.fnb.elite_wealth.module.financial_calculation.dto.FinancialCalculation;
import za.co.fnb.elite_wealth.module.investment_planning.dto.IPAllocation;
import za.co.fnb.elite_wealth.module.fna.dto.AllFnaDTO;
import za.co.fnb.elite_wealth.module.investment_planning.dto.IPAllocation;
import za.co.fnb.elite_wealth.module.fna.dto.AllFnaDTO;
import za.co.fnb.elite_wealth.module.fna.dto.ScenarioDTO;
import za.co.fnb.elite_wealth.module.investment_planning.dto.IPAllocation;
import za.co.fnb.elite_wealth.module.investment_planning.dto.IPGeneral;
import za.co.fnb.elite_wealth.module.investment_planning.dto.IPInput;
import za.co.fnb.elite_wealth.module.investment_planning.dto.IPResults;
import za.co.fnb.elite_wealth.module.master.dto.MasterAddProduct;
import za.co.fnb.elite_wealth.module.portfolio.dto.Portfolio;
import za.co.fnb.elite_wealth.module.risk_return.RiskReturn;
import za.co.fnb.elite_wealth.module.staff.dto.*;
import za.co.fnb.elite_wealth.module.work_portal.dto.*;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import static za.co.fnb.elite_wealth.util.Util.CONFIG_DATA_ROW_NO;
import static za.co.fnb.elite_wealth.util.Util.EW_CONFIG_BOOK_NO;


public class RetrieveTestData {

    private static String testDataFileToRead;

    //Logger log = Logger.getLogger(RetrieveTestData.class);
    private final String DEFAULT_NULL_CELL =" ";
    private ReadConfig readConfig =null;
    private static XSSFWorkbook wBook =null;
    private  XSSFWorkbook workBook =null;
    private static File inputFile =null;

    BankAndTax staffBankAndTax =null;
    Staff staffDTO =null;
    StaffDetails staffDetails = null;
    Membership membership = null;
    Administration administration =null;
    LoginDetail loginDetail=null;
    Workqueue workQueue =null;
    WorkPortalAdministration workPortalAdministration = null;
    ClientDocuments clientDocuments = null;
    InteractionsAndNotes interactionsAndNotes =null;
    Reminders reminders = null;
    NewIndividualEntity individualDTO = null;
    NewLegalEntity legalDTO = null;
    IndividualAndLegalEntity combinedDTO = null;
    EntitySearch searchDTO= null;
    IndividualEntityDetails individualUpdateDTO= null;
    LegalEntityDetails legalUpdateDTO= null;
    NewRelatedEntity relatedEntityDTO= null;
    Relationships relationshipsDTO= null;
    GeneralDetails generalDetailsDTO= null;
    Portfolio portfolioDTO = null;
    Reports clientReportDTO= null;
    Portfolio portfolio = null;
    IPGeneral ipGeneralDTO= null;
    IPInput ipInputDTO= null;
    IPResults ipResultsDTO= null;
    IPAllocation ipAllocationDTO= null;
    Budget budgetDTO= null;
    AssetsAndLiabilities assetsAndLiabilitiesDTO= null;
    AssetsAndLiabilitiesDetails assetsAndLiabilitiesDetailsDTO= null;
    RiskReturn riskReturnDTO= null;
    WorkFlow workFlowDTO= null;
    FinancialCalculation financialCalculation = null;


    ScenarioDTO scenarioDTO = null;
    AllFnaDTO allFnaDTO = null;
    MasterAddProduct masterAddProductDTO = null;


	private List<Staff> staffSet =new ArrayList<Staff>();
    private List<BankAndTax> staffBankAndTaxSet =new ArrayList<BankAndTax>();
    private List<Membership> membershipSet =new ArrayList<Membership>();
    private List<Administration> adminstrationsSet =new ArrayList<Administration>();
    private List<StaffDetails> StaffDetailsSet =new ArrayList<StaffDetails>();
    private List<Workqueue> workQueueSet = new ArrayList<Workqueue>();
    private List<WorkPortalAdministration> workPortalAdministrationSet = new ArrayList<WorkPortalAdministration>();
    private List<ClientDocuments> clientDocumentSet = new ArrayList<ClientDocuments>();
    private List<InteractionsAndNotes> interactionsAndNoteSet = new ArrayList<InteractionsAndNotes>();
    private List<Reminders> reminderSet = new ArrayList<Reminders>();
    private List<NewIndividualEntity> individualClients  = new ArrayList<NewIndividualEntity>();
    private List<NewLegalEntity> legalClients  = new ArrayList<NewLegalEntity>();
    private List<IndividualAndLegalEntity> relatedClients = new ArrayList<IndividualAndLegalEntity>();
    private List<EntitySearch> search = new ArrayList<EntitySearch>();
    private List<IndividualEntityDetails> individualUpdate = new ArrayList<IndividualEntityDetails>();
    private List<LegalEntityDetails> legalUpdate = new ArrayList<LegalEntityDetails>();
    private List<NewRelatedEntity> relatedEntity = new ArrayList<NewRelatedEntity>();
    private List<Relationships> relationship = new ArrayList<Relationships>();
    private List<GeneralDetails> generalDetails = new ArrayList<GeneralDetails>();
    private List<Reports> clientReports = new ArrayList<Reports>();
    private List<Portfolio> portfolioSet = new ArrayList<Portfolio>();
    private List<IPGeneral> ipGeneral = new ArrayList<IPGeneral>();
    private List<IPInput> ipInput = new ArrayList<IPInput>();
    private List<IPResults> ipResults = new ArrayList<IPResults>();
    private List<IPAllocation> ipAllocation = new ArrayList<IPAllocation>();
    private List<Budget> budgetSet = new ArrayList<Budget>();
    private List<AssetsAndLiabilities> assetsAndLiabilities = new ArrayList<AssetsAndLiabilities>();
    private List<AssetsAndLiabilitiesDetails> assetsAndLiabilitiesDetails = new ArrayList<AssetsAndLiabilitiesDetails>();
    private List<RiskReturn> riskReturns = new ArrayList<RiskReturn>();
    private List<WorkFlow> workFlow = new ArrayList<WorkFlow>();
    private List<FinancialCalculation> financialCalculationSet = new ArrayList<FinancialCalculation>();
    private List<MasterAddProduct> masterAddProduct = new ArrayList();


    private List<ScenarioDTO> scenarioDTOSet = new ArrayList<ScenarioDTO>();
    private List<AllFnaDTO> allFnaDTOSet = new ArrayList<AllFnaDTO>();

    static Logger log = Logger.getLogger(RetrieveTestData.class);
    private String businessUnit;

    public RetrieveTestData(String testDataFileToRead) {
        this.testDataFileToRead = testDataFileToRead;
    }

    public enum BusinessUnits {
        Private_Wealth(9), Service_Suite(9),Fiduciary(15), Financial_Advisory(8), Private_Clients(28), Premier(19), Lending(9);

        private int value;

        private BusinessUnits(int value) {
            this.value = value;
        }
    }


    private XSSFWorkbook getWorkBook(){
        try {
            if(workBook==null){
                workBook =new XSSFWorkbook(new FileInputStream(testDataFileToRead));
            }

        }catch (FileNotFoundException ex){
            //log.error(ex.getMessage());
        }catch(Exception ex){
          //  log.error(ex.getMessage());
        }
        return workBook;
    }
    public LoginDetail getLoginDetail() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(0);
            if(loginDetail ==null){
                localList =(ArrayList)getStringRows(sheet,2,2,Util.LOGIN_COLUMNS).get(0);
                loginDetail =new LoginDetail(localList);

            }
        }  catch (Exception e) {
            e.printStackTrace();
         //   log.error(e.getMessage());
        }
        return loginDetail;
    }


    public List<Staff> getStaffDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(1);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.STAFF_INFO_COLUMN)){
                staffDTO =new Staff(list);
                staffSet.add(staffDTO);

            }
        }  catch (Exception e) {
            e.printStackTrace();
            //   log.error(e.getMessage());
        }
        return staffSet;
    }

    public List<StaffDetails> getStaffDetailsDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(4);
            int from =getReadConfig().getFromRow();
            int to =120;

            for(List list:getStringRows(sheet,from,to,Util.STAFF_DETAILS_ROWS_NO)){
                staffDetails =new StaffDetails(list);
                StaffDetailsSet.add(staffDetails);

            }
        }  catch (Exception e) {
            e.printStackTrace();
            //   log.error(e.getMessage());
        }
        return StaffDetailsSet;
    }

    public List<BankAndTax> getStaffBankAndTaxDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(5);
            int from =getReadConfig().getFromRow();
            int to =100;

            for(List list:getStringRows(sheet,from,to,Util.STAFF_BANK_AND_TAX_ROWS_NO)){
                staffBankAndTax =new BankAndTax(list);
                staffBankAndTaxSet.add(staffBankAndTax);

            }
        }  catch (Exception e) {
            e.printStackTrace();
            //   log.error(e.getMessage());
        }
        return staffBankAndTaxSet;
    }
    public List<Membership> getMembershipDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(6);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();
            for(List list:getStringRows(sheet,from,to,Util.STAFF_MEMBERSHIP_ROWS_NO)){
                membership =new Membership(list);
                membershipSet.add(membership);

            }
        }  catch (Exception e) {
            e.printStackTrace();
            //   log.error(e.getMessage());
        }
        return membershipSet;
    }


    public List<Administration> getStaffAdministrationDTO() {
        try {
            ArrayList<String> localList;
            XSSFWorkbook wBook = getWorkBook();
            XSSFSheet sheet = wBook.getSheetAt(7);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();
            for(List list:getStringRows(sheet,from,to,Util.STAFF_ADMINISTRATION_ROWS_NO)){
                administration =new Administration(list);
                adminstrationsSet.add(administration);

            }
        }  catch (Exception e) {
            e.printStackTrace();
        }
        return adminstrationsSet;
    }

    public List<Workqueue> getWorkQueue() {
        try {
            XSSFWorkbook wBook = getWorkBook();
            XSSFSheet sheet = wBook.getSheetAt(8);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();
            for(List list:getStringRows(sheet,from,to,Util.WORK_PORTAL_ROW_NO)){
                workQueue =new Workqueue(list);
                workQueueSet.add(workQueue);

            }
        }  catch (Exception e) {
            e.printStackTrace();
            //   log.error(e.getMessage());
        }
        return workQueueSet;
    }

    public List<WorkPortalAdministration> getWorPortalAdministration() {
        try {
            XSSFWorkbook wBook = getWorkBook();
            XSSFSheet sheet = wBook.getSheetAt(9);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();
            for(List list:getStringRows(sheet,from,to,Util.WORK_PORTA_ADMINISTRATION_RAW_NO)){
              workPortalAdministration =new WorkPortalAdministration(list);
                workPortalAdministrationSet.add(workPortalAdministration);

            }
        }  catch (Exception e) {
            e.printStackTrace();
        }
        return workPortalAdministrationSet;
    }

    public List<ClientDocuments> getClientDocuments() {
        try {
            XSSFWorkbook wBook = getWorkBook();
            XSSFSheet sheet = wBook.getSheetAt(10);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();
            for(List list:getStringRows(sheet,from,to,Util.WORK_PORTAL_CLIENT_DOCUMENT)){
                clientDocuments =new ClientDocuments(list);
                clientDocumentSet.add(clientDocuments);

            }
        }  catch (Exception e) {
            e.printStackTrace();
            //   log.error(e.getMessage());
        }
        return clientDocumentSet;
    }

    public List<InteractionsAndNotes> getInteractionAndNotes() {
        try {
            XSSFWorkbook wBook = getWorkBook();
            XSSFSheet sheet = wBook.getSheetAt(12);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();
            for(List list:getStringRows(sheet,from,to,Util.WORK_PORTAL_INTERACTION_AND_NOTES)){
                interactionsAndNotes =new InteractionsAndNotes(list);
                interactionsAndNoteSet.add(interactionsAndNotes);

            }
        }  catch (Exception e) {
            e.printStackTrace();
            //   log.error(e.getMessage());
        }
        return interactionsAndNoteSet;
    }
    public List<Reminders> getReminders() {
        try {
            XSSFWorkbook wBook = getWorkBook();
            XSSFSheet sheet = wBook.getSheetAt(11);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();
            for(List list:getStringRows(sheet,from,to,Util.WORK_PORTAL_REMINDERS)){
                reminders =new Reminders(list);
                reminderSet.add(reminders);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }
        return reminderSet;
    }


    public List<NewIndividualEntity> getIndividualEntityDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(13);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.INDIVIDUAL_ENTITY_COLUMNS)){
                individualDTO =new NewIndividualEntity(list);
                individualClients.add(individualDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
            //   log.error(e.getMessage());
        }
        return individualClients;
    }


    public List<NewLegalEntity> getLegalEntityDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(14);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.LEGAL_ENTITY_COLUMNS)){
                legalDTO =new NewLegalEntity(list);
                legalClients.add(legalDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }
        return legalClients;
    }

    public List<IndividualAndLegalEntity> getIndividualAndLegalEntityDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(15);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.COMBINED_ENTITY_COLUMNS)){
                combinedDTO =new IndividualAndLegalEntity(list);
                relatedClients.add(combinedDTO);

            }
        }  catch (Exception e) {
            e.printStackTrace();
        }
        return relatedClients;
    }

    public List<EntitySearch> getSearchDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(16);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.SEARCH_ENTITY)){
                searchDTO = new EntitySearch(list);
                search.add(searchDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }
        return search;
    }

    public List<IndividualEntityDetails> getIndividualUpdateDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(17);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.UPDATE_INDIVIDUAL_ENTITY)){
                individualUpdateDTO = new IndividualEntityDetails(list);
                individualUpdate.add(individualUpdateDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }
        return individualUpdate;
    }

    public List<LegalEntityDetails> getLegalUpdateDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(18);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.UPDATE_LEGAL_ENTITY)){
                legalUpdateDTO = new LegalEntityDetails(list);
                legalUpdate.add(legalUpdateDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }
        return legalUpdate;
    }

    public List<NewRelatedEntity> getRelatedDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(19);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.UPDATE_RELATED_ENTITY)){
                relatedEntityDTO = new NewRelatedEntity(list);
                relatedEntity.add(relatedEntityDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }
        return relatedEntity;
    }

    public List<Relationships> getRelationshipDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(20);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.RELATIONSHIPS)){
                relationshipsDTO = new Relationships(list);
                relationship.add(relationshipsDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }
        return relationship;
    }

    public List<GeneralDetails> getGeneralDetailsDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(21);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.GENERAL_DETAILS)){
                generalDetailsDTO = new GeneralDetails(list);
                generalDetails.add(generalDetailsDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }
        return generalDetails;
    }


    public List<Reports> getClientReportsDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(22);
            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.REPORTS)){
                clientReportDTO = new Reports(list);
                clientReports.add(clientReportDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }
        return clientReports;
    }

    public List<Portfolio> getPortfolioDTO() {
        try {
            XSSFWorkbook wBook = getWorkBook();
            XSSFSheet sheet = wBook.getSheetAt(23);
            int from =getReadConfig().getFromRow();
            int to =100;

            for(List list:getStringRows(sheet,from,to,Util.PORTFOLIO_ROWS_NO)){
                portfolioDTO = new Portfolio(list);
                portfolioSet.add(portfolioDTO);
                }
            }
        catch (Exception e)
            {
                e.printStackTrace();
            }
        return portfolioSet;
    }

    public List<IPGeneral> getIPGeneralDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(24);

            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.IP_GENERAL)){
                ipGeneralDTO = new IPGeneral(list);
                ipGeneral.add(ipGeneralDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }

        return ipGeneral;
    }

    public List<IPInput> getIPInputDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(25);

            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.IP_INPUT)){
                ipInputDTO = new IPInput(list);
                ipInput.add(ipInputDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }

        return ipInput;
    }

    public List<IPResults> getIPResultsDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(26);

            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.IP_RESULTS)){
                ipResultsDTO = new IPResults(list);
                ipResults.add(ipResultsDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }

        return ipResults;
    }

    public List<IPAllocation> getIpAllocationDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(27);

            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.IP_ALLOCATION)){
                ipAllocationDTO = new IPAllocation(list);
                ipAllocation.add(ipAllocationDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }

        return ipAllocation;
    }

    public List<Budget> getBudgetDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(28);

            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.BUDGET)){
                budgetDTO= new Budget(list);
                budgetSet.add(budgetDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }

        return budgetSet;
    }

    public List<AssetsAndLiabilities> getAssetsAndLiabilitiesDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(29);

            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.ASSETS_AND_LIABILITIES)){
                assetsAndLiabilitiesDTO= new AssetsAndLiabilities(list);
                assetsAndLiabilities.add(assetsAndLiabilitiesDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }

        return assetsAndLiabilities;
    }


    public List<AssetsAndLiabilitiesDetails> getAssetsAndLiabilitiesDetailsDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(30);

            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.ASSETS_AND_LIABILITIES_DETAILS)){
                assetsAndLiabilitiesDetailsDTO= new AssetsAndLiabilitiesDetails(list);
                assetsAndLiabilitiesDetails.add(assetsAndLiabilitiesDetailsDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }

        return assetsAndLiabilitiesDetails;
    }

    public List<RiskReturn> getRiskReturnsDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(31);

            int from =getReadConfig().getFromRow();
            int to =350;

            for(List list:getStringRows(sheet,from,to,Util.RISK_RETURNS)){
                riskReturnDTO= new RiskReturn(list);
                riskReturns.add(riskReturnDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }

        return riskReturns;
    }

    public List<WorkFlow> getWorkFlowsDTO() {
        try {
            ArrayList<String> localList;
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            XSSFSheet sheet = wBook.getSheetAt(32);

            int from =getReadConfig().getFromRow();
            int to =getReadConfig().getUpToRow();

            for(List list:getStringRows(sheet,from,to,Util.WORK_FLOW)){
                workFlowDTO= new WorkFlow(list);
                workFlow.add(workFlowDTO);
            }
        }  catch (Exception e) {
            e.printStackTrace();
        }

        return workFlow;
    }


    private List<List<String>> getStringRows( XSSFSheet sheet,int from,int to,int columnNumbers){
        List<String> cells =null;
        List<List<String>> listOfCells =new ArrayList<List<String>>();
        try {
            //Because the for loop is zero indexed. Start looping from one less
            for (int i = from-1; i <= to-1; i++) {
                cells =new ArrayList();
                for (int j = 0; j < columnNumbers; j++) {
                    Cell cell = sheet.getRow(i).getCell(j, Row.RETURN_BLANK_AS_NULL);

                    //In case a cell is null
                    if (cell == null) {
                        cell = sheet.getRow(i).createCell((short) 0);
                        cell.setCellType(Cell.CELL_TYPE_STRING);
                        cell.setCellValue(" ");
                    }
                    switch (cell.getCellType()) {
                        case Cell.CELL_TYPE_BOOLEAN:
                            cells.add(String.valueOf(cell.getBooleanCellValue()));
                            break;
                        case Cell.CELL_TYPE_NUMERIC:
                            String numeric = String.valueOf((long) cell.getNumericCellValue());
                            cells.add(numeric);
                            break;
                        case Cell.CELL_TYPE_STRING:
                            cells.add(cell.getStringCellValue());
                            break;
                        case Cell.CELL_TYPE_BLANK:
                            cells.add(" ");
                            break;
                        case Cell.CELL_TYPE_FORMULA:
                            cells.add(cell.getStringCellValue());
                            break;
                        default:
                            cells.add(" ");
                    }
                }
                if (cells.size() == columnNumbers) {
                    listOfCells.add(cells);
                }
            }

        }catch (Exception ex){
            //log.error(ex.getMessage());
        }
        return listOfCells;
    }


	public List<ScenarioDTO> getScenarioDTO() {
		try {
			XSSFWorkbook wBook = getWorkBook();
			XSSFSheet sheet = wBook.getSheetAt(33);

			int from =getReadConfig().getFromRow();
			int to =58;

			for(List list:getStringRows(sheet,from,to,Util.FNA_SCENARIO_RAWS)){
				scenarioDTO = new ScenarioDTO(list);
				scenarioDTOSet.add(scenarioDTO);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return scenarioDTOSet;
	}

    public List<AllFnaDTO> getAllFnaDTO() {
        try {
            XSSFWorkbook wBook = getWorkBook();
            XSSFSheet sheet = wBook.getSheetAt(34);

            int from =getReadConfig().getFromRow();

            int to =270;

            for(List list:getStringRows(sheet,from,to,Util.FNA_ALL_ROWS)){
                allFnaDTO = new AllFnaDTO(list);
                allFnaDTOSet.add(allFnaDTO);
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        return allFnaDTOSet;
    }


    public List<FinancialCalculation> getFinancialCalculation() {
        try {
            XSSFWorkbook wBook = getWorkBook();
            XSSFSheet sheet = wBook.getSheetAt(35);

            int from =getReadConfig().getFromRow();

            int to =270;

            for(List list:getStringRows(sheet,from,to,Util.FINANCIAL_CALCULATIONS_ROWS)){
                financialCalculation = new FinancialCalculation(list);
                financialCalculationSet.add(financialCalculation);
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        return financialCalculationSet;
    }

    public List<MasterAddProduct> getMasterAddProductDTO() {
        try {
            // Get the workbook object for XLSX file
            XSSFWorkbook wBook = getWorkBook();
            // Get the sheet from the workbook
            if (wBook != null) {
                XSSFSheet sheet = wBook.getSheetAt(1);
                int from = 2;
                int to = 100;
                for (List list : getStringRows(sheet, from, to, Util.RISK_RETURNS)) {
                    masterAddProductDTO = new MasterAddProduct(list);
                    masterAddProduct.add(masterAddProductDTO);
                }
            }

        } catch (NullPointerException e) {
            log.info(e.getStackTrace());
        }
        return masterAddProduct;
    }

    public List<String> getColumns(Integer sheetNumber, int columnNumber, Integer rowUpTo) {
        List<String> values =new ArrayList();
        XSSFWorkbook wBook = getWorkBook();
        XSSFSheet sheet = wBook.getSheetAt(sheetNumber);
        int count = 0;
        readConfig =getReadConfig();
        for (Row r : sheet) {
            count++;
            if (count > 2) {
                Cell c = r.getCell(columnNumber);
                if (c == null) {
                    //c.setCellType(Cell.CELL_TYPE_STRING);
                    //c.setCellValue(" ");
                }
                if (c != null) {
                    System.out.print(c);
                    if (c.getCellType() == Cell.CELL_TYPE_STRING) {
                        if(!c.getStringCellValue().equalsIgnoreCase(" ")) {
                            values.add(c.getStringCellValue());
                        }
                    } else if (c.getCellType() == Cell.CELL_TYPE_NUMERIC) {
                        values.add(String.valueOf(c.getNumericCellValue()));
                    }
                    if (count == readConfig.getUpToRow()) {
                        break;
                    }
                }
            }
        }
        return values;
    }
    public ReadConfig getReadConfig() {
        ArrayList<String> localList;
        try {

            if(readConfig ==null) {

                // Get the workbook object for XLSX file
                XSSFWorkbook wBook = getWorkBook();
                // Get the sheet from the workbook
                XSSFSheet sheet = wBook.getSheetAt(EW_CONFIG_BOOK_NO);
                localList =(ArrayList)getStringRows(sheet,CONFIG_DATA_ROW_NO,CONFIG_DATA_ROW_NO,EW_CONFIG_BOOK_NO).get(0);
                readConfig = new ReadConfig(localList);
            }
        }
        catch (Exception ex){
            ex.printStackTrace();
            //log.error(ex.getMessage());
        }

        return readConfig;

    }






}
