package za.co.fnb.elite_wealth.config;

public enum  BrowserConstants {
    CHROME("Chrome"),
    FIREFOX("Firefox"),
    INTERNET_EXPLORER("Internet Explorer"),
    SAFARI("Safari");

    private String browser;
    private String property;

    private BrowserConstants(String browser) {
        this.browser = browser;
        this.property = property;
    }

    @Override
    public String toString() {

        switch (this) {
            case CHROME:
                return browser;
            case FIREFOX:
                return browser;
            case INTERNET_EXPLORER:
                return browser;
            case SAFARI:
                return browser;
            default:
                return browser;
        }
    }
}
