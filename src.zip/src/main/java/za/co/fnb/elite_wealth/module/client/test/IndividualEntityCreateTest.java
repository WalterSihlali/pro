package za.co.fnb.elite_wealth.module.client.test;

import org.apache.log4j.Logger;
import org.junit.Test;
import za.co.fnb.elite_wealth.module.client.dto.NewIndividualEntity;
import za.co.fnb.elite_wealth.module.client.test.base.EntityBase;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;

public class IndividualEntityCreateTest extends EntityBase {

	private static Logger log = Logger.getLogger(IndividualEntityCreateTest.class);

	@Test
	public void newIndividualEntityTest() {
		try {
			PageInteraction page =new PageInteraction(driver);
			firstSteps(page);
			for (NewIndividualEntity client : retrieveIndividualEntityData(page)) {
				addNewIndividualEntity(page, client);
				lastSteps(page);
			}
		} catch (Exception ex) {
			log.info(ex.getMessage());
		}
	}
}
