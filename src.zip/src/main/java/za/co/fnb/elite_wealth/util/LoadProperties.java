package za.co.fnb.elite_wealth.util;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class LoadProperties {

    Properties properties = new Properties();
    private static Logger log = Logger.getLogger(LoadProperties.class);
    
    public LoadProperties() {
        InputStream inputStream = null;

        try {
            inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("properties/default.properties");
            properties.load(inputStream);

        } catch (IOException e) {
            log.info(e.getStackTrace());
        }
    }
    /**
     * Retrieve key value from the za.co.fnb.elite_wealth.properties file
     *
     * @param key
     * @return value
     */
    public String getValueFromPropFile(String key) {
        return properties.getProperty(key);
    }

}