package za.co.fnb.elite_wealth.config;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.service.DriverService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import za.co.fnb.elite_wealth.module.common.EliteWealthLogin;
import za.co.fnb.elite_wealth.module.common.LoginDetail;
import za.co.fnb.elite_wealth.properties.EnvironmentProperties;
import za.co.fnb.elite_wealth.reporting.RecordVideo;
import za.co.fnb.elite_wealth.util.BrowserUtil;
import za.co.fnb.elite_wealth.util.RetrieveTestData;

import java.io.IOException;

import static za.co.fnb.elite_wealth.page_interaction.PageInteraction.createTestFiles;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:spring/mini-xml-config-context.xml")
public class SeleniumService {
	private static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SeleniumService.class);
	private static BrowserConfig config;
	protected static DriverService service;
	public static WebDriver driver;
	protected static DriverUtil webUtil;
	protected static RetrieveTestData retrieveTestData;
	private static RecordVideo recordVideo;
	private static Logger log = Logger.getLogger(SeleniumService.class);
	private EliteWealthLogin eliteWealthLogin = new EliteWealthLogin();

	private static EnvironmentProperties environmentPropertiesCopy;
	@Autowired
	private EnvironmentProperties environmentProperties;


	//Before executing a class, this method creates a chrome service
	@BeforeClass
	public static void createService() throws IOException {

		ApplicationContext context = new ClassPathXmlApplicationContext("spring/mini-xml-config-context.xml");
		environmentPropertiesCopy = context.getBean(EnvironmentProperties.class);
		createTestFiles();
		if (config == null) {
			config = new BrowserUtil().getInstance().getChromeService();
		}
		if (service == null) {
			service = config.getService();
			service.start();
			log.info("Selenium service started");
		} else if (!service.isRunning()) {
			service.start();
			log.info("Selenium service started");
		}

	}

	@Before
	public void setUp() throws Exception {
		environmentProperties = environmentPropertiesCopy;

		if (driver == null) {
			driver = new RemoteWebDriver(service.getUrl(), config.getCapabilities());
		}
		createWebUtil();
		LoginDetail loginDetail = new RetrieveTestData(getEnvironmentDataSheet()).getLoginDetail();
		boolean isRecord = loginDetail.isRecord();
		logger.info("Recording turned on ? " + isRecord);
		if (isRecord) {
			recordVideo = RecordVideo.getInstance();
			recordVideo.startRecording();
		}
		eliteWealthLogin.login();


	}

	private synchronized DriverUtil createWebUtil() {

		if (driver == null) {
			driver = new ChromeDriver();
			webUtil = new DriverUtil(driver);
		} else if (webUtil == null) {
			webUtil = new DriverUtil(driver);
		}
		return webUtil;
	}

	public static DriverUtil getWebUtil() {
		return webUtil;
	}

	protected static void setWebUtil(DriverUtil webUtil) {
		if (SeleniumService.webUtil == null) {
			SeleniumService.webUtil = webUtil;

		}
	}

	public static DriverService getService() {
		return service;
	}

	protected static void setService(DriverService service) {
		if (SeleniumService.service == null) {
			SeleniumService.service = service;
		}
	}

	public WebDriver restartService() throws WebDriverException {
		if (driver != null) {
			driver = new RemoteWebDriver(service.getUrl(), config.getCapabilities());
		}

		createWebUtil();
		return driver;
	}

	@After
	public void tearDown() {
		if (driver != null) {
			driver.quit();
			driver = null;
		}
	}

	/*
	**Stops the selenium service after test class executes
	* Even when test fails
	*/
	@AfterClass
	public static void stopService() {

		logger.info("Stopping Selenium Service");
		if (service != null) {
			service.stop();
			log.info("Selenium service stopped");

		}
		try {
			if (recordVideo != null) {
				recordVideo.stopRecording();
			}
		} catch (Exception ex) {
			logger.info(ex.getMessage());
		}
	}

	public static EnvironmentProperties getEnvironmentPropertiesCopy() {
		return environmentPropertiesCopy;
	}

	public static String getEnvironmentDataSheet() {
		return environmentPropertiesCopy.getTestDatasheet();
	}
}
