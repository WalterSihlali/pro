package za.co.fnb.elite_wealth.environments.qa_smoke;

import za.co.fnb.elite_wealth.environments.generic.GenericEnv;
import org.springframework.beans.factory.annotation.Value;

public class QASmoke implements GenericEnv {

	private String envName ="qaSmoke";

	@Value("${profile.name}")
	private String profileName;

	public String getEnvName() {
		return envName;
	}
	public void setEnvName(String envName) {
		this.envName = envName;
	}
	public String getProfileName() {
		return profileName;
	}
	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}
	@Override
	public String toString() {

		return "DevEnv [envName=" + envName + ", profileName=" + profileName + "]";
	}
}
