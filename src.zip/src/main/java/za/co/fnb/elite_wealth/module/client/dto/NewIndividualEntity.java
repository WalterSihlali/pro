package za.co.fnb.elite_wealth.module.client.dto;

import java.util.List;

public class NewIndividualEntity {
	private String testCase;
	private String testScenario;
	private String  name;
	private String surname;
	private String status;
	private String company;
	private String office;
	private String incomeClass;
	private String  title;
	private String gender;
	private String  firstNames;
	private String initials;
	private String nickName;
	private String maidenName;
	private String nationality;
	private String countryOfBirth;
	private String placeOfBirth;
	private String countryOfResidence;
	private String saIDNumber;
	private String dateOfBirth;
	private String passportNumber;
	private String homeLanguage;
	private String correspondenceLanguage;
	private String maritalStatus;
	private String maritalDate;
	private String informalSalutation;
	private String formalSalutation;
	private String addresses;
	private String emails;
	private String telephoneAndSkype;
	private String role;
	private String staffMember;
	private String leadProviderType;
	private String other;
	private String staffRole;
	private String referredBy;
	private String referralDate;
	private String notes;
	public NewIndividualEntity(List<String> individual) {
		int  TEST_CASE =0;
		int  TEST_SCENARIO =1;
		int  NAME =2;
		int SURNAME =3;
		int STATUS =4;
		int COMPANY =5;
		int OFFICE =6;
		int INCOME_CLASS=7;
		int TITLE =8;
		int GENDER =9;
		int FIRST_NAMES =10;
		int INITIALS =11;
		int NICK_NAME =12;
		int MAIDEN_NAME =13;
		int NATIONALITY =14;
		int COUNTRY_OF_BIRTH =15;
		int PLACE_OF_BIRTH =16;
		int COUNTRY_OF_RESIDENCE=17;
		int SA_ID_NUMBER=18;
		int DATE_OF_BIRTH =19;
		int PASSPORT_NUMBER =20;
		int HOME_LANGUAGE=21;
		int CORRESPONDENCE_LANGUAGE =22;
		int MARITAL_STATUS =23;
		int MARITAL_DATE = 24;
		int INFORMAL_SALUTATION = 25;
		int FORMAL_SALUTATION = 26;
		int ADDRESSES = 27;
		int EMAIL = 28;
		int TELEPHONE_AND_SKYPE = 29;
		int ROLE = 30;
		int STAFF_MEMBER = 31;
		int LEAD_PROVIDER_TYPE = 32;
		int OTHER = 33;
		int STAFF_ROLE = 34;
		int REFERRED_BY = 35;
		int REFERRAL_DATE = 36;
		int NOTES = 37;
		setTestCase(individual.get(TEST_CASE));
		setTestScenario(individual.get(TEST_SCENARIO));
        setName(individual.get(NAME));
		setSurname(individual.get(SURNAME));
		setStatus(individual.get(STATUS));
		setCompany(individual.get(COMPANY));
		setOffice(individual.get(OFFICE));
		setIncomeClass(individual.get(INCOME_CLASS));
		setTitle(individual.get(TITLE));
		setGender(individual.get(GENDER));
		setFirstNames(individual.get(FIRST_NAMES));
		setInitials(individual.get(INITIALS));
		setNickName(individual.get(NICK_NAME));
		setMaidenName(individual.get(MAIDEN_NAME));
		setNationality(individual.get(NATIONALITY));
		setCountryOfBirth(individual.get(COUNTRY_OF_BIRTH));
		setPlaceOfBirth(individual.get(PLACE_OF_BIRTH));
		setCountryOfResidence(individual.get(COUNTRY_OF_RESIDENCE));
		setSaIDNumber(individual.get(SA_ID_NUMBER));
		setDateOfBirth(individual.get(DATE_OF_BIRTH));
		setPassportNumber(individual.get(PASSPORT_NUMBER));
		setHomeLanguage(individual.get(HOME_LANGUAGE));
		setCorrespondenceLanguage(individual.get(CORRESPONDENCE_LANGUAGE));
		setMaritalStatus(individual.get(MARITAL_STATUS));
		setMaritalDate(individual.get(MARITAL_DATE));
		setInformalSalutation(individual.get(INFORMAL_SALUTATION));
		setFormalSalutation(individual.get(FORMAL_SALUTATION));
		setAddresses(individual.get(ADDRESSES));
		setEmails(individual.get(EMAIL));
		setTelephoneAndSkype(individual.get(TELEPHONE_AND_SKYPE));
		setRole(individual.get(ROLE));
		setStaffMember(individual.get(STAFF_MEMBER));
		setLeadProviderType(individual.get(LEAD_PROVIDER_TYPE));
		setOther(individual.get(OTHER));
		setStaffRole(individual.get(STAFF_ROLE));
		setReferredBy(individual.get(REFERRED_BY));
		setReferralDate(individual.get(REFERRAL_DATE));
        setNotes(individual.get(NOTES));
	}


	public String getTestScenario() {
		return testScenario;
	}

	public void setTestScenario(String testScenario) {
		this.testScenario = testScenario;
	}

	public String getTestCase() {
		return testCase;
	}

	public void setTestCase(String testCase) {
		this.testCase = testCase;
	}

	public String getIncomeClass() {
		return incomeClass;
	}

	public void setIncomeClass(String incomeClass) {
		this.incomeClass = incomeClass;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getFirstNames() {
		return firstNames;
	}

	public void setFirstNames(String firstNames) {
		this.firstNames = firstNames;
	}

	public String getInitials() {
		return initials;
	}

	public void setInitials(String initials) {
		this.initials = initials;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getMaidenName() {
		return maidenName;
	}

	public void setMaidenName(String maidenName) {
		this.maidenName = maidenName;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getCountryOfBirth() {
		return countryOfBirth;
	}

	public void setCountryOfBirth(String countryOfBirth) {
		this.countryOfBirth = countryOfBirth;
	}

	public String getPlaceOfBirth() {
		return placeOfBirth;
	}

	public void setPlaceOfBirth(String placeOfBirth) {
		this.placeOfBirth = placeOfBirth;
	}

	public String getCountryOfResidence() {
		return countryOfResidence;
	}

	public void setCountryOfResidence(String countryOfResidence) {
		this.countryOfResidence = countryOfResidence;
	}

	public String getSaIDNumber() {
		return saIDNumber;
	}

	public void setSaIDNumber(String saIDNumber) {
		this.saIDNumber = saIDNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getHomeLanguage() {
		return homeLanguage;
	}

	public void setHomeLanguage(String homeLanguage) {
		this.homeLanguage = homeLanguage;
	}

	public String getCorrespondenceLanguage() {
		return correspondenceLanguage;
	}

	public void setCorrespondenceLanguage(String correspondenceLanguage) {
		this.correspondenceLanguage = correspondenceLanguage;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getMaritalDate() {
		return maritalDate;
	}

	public void setMaritalDate(String maritalDate) {
		this.maritalDate = maritalDate;
	}

	public String getInformalSalutation() {
		return informalSalutation;
	}

	public void setInformalSalutation(String informalSalutation) {
		this.informalSalutation = informalSalutation;
	}

	public String getFormalSalutation() {
		return formalSalutation;
	}

	public void setFormalSalutation(String formalSalutation) {
		this.formalSalutation = formalSalutation;
	}

	public String getAddresses() {
		return addresses;
	}

	public void setAddresses(String addresses) {
		this.addresses = addresses;
	}

	public String getEmails() {
		return emails;
	}

	public void setEmails(String emails) {
		this.emails = emails;
	}

	public String getTelephoneAndSkype() {
		return telephoneAndSkype;
	}

	public void setTelephoneAndSkype(String telephoneAndSkype) {
		this.telephoneAndSkype = telephoneAndSkype;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getStaffMember() {
		return staffMember;
	}

	public void setStaffMember(String staffMember) {
		this.staffMember = staffMember;
	}

	public String getLeadProviderType() {
		return leadProviderType;
	}

	public void setLeadProviderType(String leadProviderType) {
		this.leadProviderType = leadProviderType;
	}

	public String getOther() {
		return other;
	}

	public void setOther(String other) {
		this.other = other;
	}

	public String getStaffRole() {
		return staffRole;
	}

	public void setStaffRole(String staffRole) {
		this.staffRole = staffRole;
	}

	public String getReferredBy() {
		return referredBy;
	}

	public void setReferredBy(String referredBy) {
		this.referredBy = referredBy;
	}

	public String getReferralDate() {
		return referralDate;
	}

	public void setReferralDate(String referralDate) {
		this.referralDate = referralDate;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

}
