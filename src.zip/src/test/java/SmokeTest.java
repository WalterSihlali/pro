
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import za.co.fnb.elite_wealth.module.client.test.*;
import za.co.fnb.elite_wealth.module.fna.test.TempDisabilityTest;
import za.co.fnb.elite_wealth.module.work_portal.test.WorkFlowTest;

@RunWith(Suite.class)

@Suite.SuiteClasses({
		EntitySearchTest.class ,
		IndividualEntityCreateTest.class,
		LegalEntityCreateTest.class,
		IndividualEntityUpdateTest.class,
		LegalEntityUpdateTest.class,
		RegressionTest.class,
		GeneralDetailsTest.class,
		WorkFlowTest.class,
		TempDisabilityTest.class

})
public class SmokeTest {}


