package za.co.fnb.elite_wealth.module.client.test.base;

import za.co.fnb.elite_wealth.config.ElementConstants;
import za.co.fnb.elite_wealth.config.SeleniumService;
import za.co.fnb.elite_wealth.module.client.dto.Reports;
import za.co.fnb.elite_wealth.module.common.CommonActions;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;
import za.co.fnb.elite_wealth.util.RetrieveTestData;

import java.util.List;

public class ReportBase extends SeleniumService {
	
	private static CommonActions common;
	
	protected List<Reports> retrieveReportsData(PageInteraction page) {
		RetrieveTestData retrieveTestData = new RetrieveTestData(page.dataSheetLocation());
		return retrieveTestData.getClientReportsDTO();
	}
	
	public void firstSteps(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_INFO_TAB);
	}
	
	protected void lastSteps(PageInteraction page) throws Exception {
		common.checkUpdateSaved(page);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SELECT_ENTITY);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		
	}
	
	protected void searchForClient(PageInteraction page, Reports report) {
		String search = report.getSearchValue();
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_TXT, search);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_BTN);
		common.selectClientFromList(page);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	protected void selectReportMenu(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.REPORT_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	
	public void generateReport(PageInteraction page, Reports report) {
		String reportType = report.getReportType();
		String completeFilter = report.getChangeFilter();
		String entityStatus = report.getEntityStatus();
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.REPORT_TYPE, reportType);
		
		if (completeFilter.equals("Yes") && entityStatus.equals("Yes")) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ENTITY_STATUS_EDIT);
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ENTITY_STATUS_CLIENT);
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ENTITY_STATUS_POTENTIAL);
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ENTITY_STATUS_APPLY);
		}
		
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.GENERATE_REPORT);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.takeScreenShoot("Generate " + reportType + " report" + common.getDateFormat());
		
	}
}
