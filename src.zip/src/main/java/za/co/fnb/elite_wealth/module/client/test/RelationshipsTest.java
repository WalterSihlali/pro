package za.co.fnb.elite_wealth.module.client.test;

import org.apache.log4j.Logger;
import org.junit.Test;
import za.co.fnb.elite_wealth.module.client.dto.Relationships;
import za.co.fnb.elite_wealth.module.client.test.base.RelationshipManagementBase;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;

public class RelationshipsTest extends RelationshipManagementBase {

	private static Logger log = Logger.getLogger(RelationshipsTest.class);

	@Test
	public void maintainEntityRelationshipsTest() {
		try {
			PageInteraction page =new PageInteraction(driver);
			firstSteps(page);
			for (Relationships entity : retrieveRelationshipsData(page)) {
				searchForClient(page, entity);
				selectEntityMenu(page, entity);
				maintainEntityRelationships(page, entity);
				lastSteps(page);
			}
		} catch (Exception ex) {
			log.info(ex.getMessage());
		}
	}
}
