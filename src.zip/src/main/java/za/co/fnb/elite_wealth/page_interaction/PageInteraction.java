package za.co.fnb.elite_wealth.page_interaction;

import org.apache.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import za.co.fnb.elite_wealth.config.*;
import za.co.fnb.elite_wealth.util.RetrieveTestData;
import java.io.*;
import java.net.URL;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import static org.apache.maven.shared.utils.io.FileUtils.copyFile;
import static org.openqa.selenium.Keys.TAB;

public class PageInteraction {
	private long millisecond = 10000000;
	public static final Format formatter = new SimpleDateFormat("YYYY-MM-dd_hh-mm-ss");
	private String previousWindow = null;
	private String currentWindow = null;
	private static Logger log = org.apache.log4j.Logger.getLogger(PageInteraction.class);
	private static PageInteraction instance = null;
	private PageObjects pageObjects = new PageObjects();
	private WebDriver driver;
	private static final int TIME_OUT = 20;
	private int stepCounter;

	public PageInteraction(WebDriver driver) {
		this.driver = driver;
	}

	public String getDataSheetLocation() {
		log.info(SeleniumService.getEnvironmentDataSheet());
		return SeleniumService.getEnvironmentDataSheet();

	}
	/*
	 * Retrieve the location of the data sheet
	 * @return
	 */
	public String dataSheetLocation() {
		String location = getDataSheetLocation();
		log.info("Data sheet Location: " + location);
		return location;
	}

	public WebDriver getDriver() {
		return driver;
	}

	private WebElement findElement(By by) throws Exception {
		long timestamp ;
		try {
			timestamp = System.currentTimeMillis();

			if (timestamp > 1000) {
				log.info("Element " + by + " took " + (timestamp % 1000) / 100 + " second/s to be visible");
			}

		} catch (Exception ex) {
			throw new Exception(ex.getMessage());
		}
		return getDriver().findElement(by);
	}
	/*
	*** Maximise browser window
	 */
	public void maximiseWindow() {
		getDriver().manage().window().maximize();
	}

    /*
	* Select the first value from an interactive menu item on a default frame
    * @param identifier main menu
    * @param identifier sub menu
    */

	public void selectNonInteractiveMenuItems(String pageName, String elementName) {

		try {
			getDriver().switchTo().defaultContent();
			findElement(pageObjects.getByElement(pageName, elementName)).click();
			log.info("Selected non interactive menu item: <" + elementName + ">");
		} catch (Exception e) {
			log.info("Unable to select non interactive menu item: <" + elementName + ">");
		}
	}

	/*
	 * Select the first value from an interactive menu item
	 * @param pageName
	 * @param elementName
	 */
	public void selectNonInteractiveItem(String pageName, String elementName) {
		try {
			WebElement element = findElement(pageObjects.getByElement(pageName, elementName));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].setAttribute('style', 'background:yellow; border: 2px solid green;');", element);
			executor.executeScript("arguments[0].click();", element);

			log.info("Selected non interactive menu item: <" + elementName + ">");
		} catch (Exception e) {
			log.info("Unable to select non interactive menu item: <" + elementName + ">");
		}
	}

	/*
	   * Scroll down from a specific elements location
	   * @param pageName
	   * @param elementName
	   */
	public void scrollDown(String pageName, String elementName) throws Exception {
		WebElement element = findElement(pageObjects.getByElement(pageName, elementName));
		waitFor(1500);
		Actions action = new Actions(driver);
		action.click(element).perform();
		action.sendKeys(Keys.PAGE_DOWN).perform();
	}
	
	/* Select an option from a dropdown list
		* @param pageName
		* @param elementName
		* @param optionFromDropDown
	 */
	public void selectOptionFromList(String pageName, String elementName, String optionFromDropDown) throws Exception {
		WebElement element = findElement(pageObjects.getByElement(pageName, elementName));
		try {
			element.click();
		} catch (Exception e) {
			log.info(e.getStackTrace());
		}

	}
	
	public void enterFromSheet(String pageName, String elementName, String dataFromSheet) {
		WebElement element;
		try {
			element = findElement(pageObjects.getByElement(pageName, elementName));
			element.clear();
			element.sendKeys(dataFromSheet);
			log.info("Entering data from a data sheet on Element: <" + elementName + ">");

		} catch (Exception e) {
			log.info("Failed entering data from a data sheet on Element: <" + elementName + ">");
		}
	}

	public boolean isElementPresent1(String pageName, String element) {
		try {
			getDriver().findElement(pageObjects.getByElement(pageName, element));
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
	
	//Return the attribute value of an element
	public String getStringValue(String pageName, String element) throws Exception {
		return findElement(pageObjects.getByElement(pageName, element)).getText();
	}

	//Return the attribute value of an element, this method doesn't wait for an element to be visible
	public String getTextValue(String pageName, String element) {
		return findInvisibleElement(pageObjects.getByElement(pageName, element)).getText();
	}

	public String getAttribute(String pageName, String element, String attribute) {
		return findInvisibleElement(pageObjects.getByElement(pageName, element)).getAttribute(attribute);
	}

	public void clearField(String pageName, String elementName) {
		WebElement element;
		try {
			element = findInvisibleElement(pageObjects.getByElement(pageName, elementName));
			element.clear();
			log.info("Clearing Filed: <" + elementName + ">");

		} catch (Exception e) {
			log.info("Failed to Clear Element: <" + elementName + ">");
		}
	}

	public void enterDataFromExcel(String pageName, String elementName, String dataFromSheet) {
		WebElement element;
		try {
			element = findElement(pageObjects.getByElement(pageName, elementName));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].setAttribute('style', ' border: 2px solid yellow;');", element);
			waitFor(1000);
			executor.executeScript("arguments[0].click();", element);
			element.sendKeys(dataFromSheet);
			log.info("Entering data from a datasheet on Element: <" + elementName + ">");
		} catch (Exception e) {
			log.info("Failed entering data from a datasheet on Element: <" + elementName + ">");
		}
	}

	public String getTextOnLockedFields(String pageName, String elementName) {
		String textOnField = null;
		try {
			textOnField = findElement(pageObjects.getByElement(pageName, elementName)).getText();
		} catch (Exception e) {
			log.info("Failed to rerieve text from : <" + elementName + ">");
		}
		return textOnField;
	}
	
	public boolean isFieldMandatory(String pageName, String elementName) {
		String fieldName;
		boolean isMandatory = false;
		fieldName = (pageObjects.getMandatoryIndicator(pageName, elementName));
		if (fieldName.equalsIgnoreCase("yes")) {
			isMandatory = true;
			log.info("Element <" + elementName + "> is a mandatory field");
		} else if (fieldName.equalsIgnoreCase("no")) {
			log.info("Element <" + elementName + "> is not a mandatory field");
		} else {
			log.info("Not able to verify if field is mandatory");
		}
		return isMandatory;
	}
	
	public void sendKeyEnter() {
		switch (TAB) {
		}
	}

	public boolean isElementPresent(String pageName, String linkText) {
		boolean isVisible;
		try {
			getDriver().findElement(pageObjects.getByElement(pageName, linkText));

			isVisible = true;
		} catch (org.openqa.selenium.NoSuchElementException e) {
			isVisible = false;
		}
		return isVisible;
	}

	public boolean isVisible(String pageName, String linkText) {
		boolean isVisible = false;
		try {
			if (isElementPresent1(pageName, linkText)) {
				isVisible = true;
				isVisible = getDriver().findElement(pageObjects.getByElement(pageName, linkText)).isDisplayed();
			}

		} catch (Exception ex) {
			log.error(ex.getStackTrace());
		}
		return isVisible;
	}

	public void waitForProcessToComplete(String pageName, String element) {
		while (isVisible(pageName, element)) {
			System.out.println("Still processing");
			log.info("Still processing");
		}
	}

	public String getSelectedOption(String pageName, String elementName) {
		String selectedOption;
		try {
			Select selectOption = new Select(findElement(pageObjects.getByElement(pageName, elementName)));
			WebElement option = selectOption.getFirstSelectedOption();
			selectedOption = option.getText();

		} catch (Exception e) {
			log.info("Unable to retrieve selected option on element: " + elementName + " dropdownlist");
			return null;
		}
		return selectedOption;
	}

	public boolean isElementActive(String pageName, String elementName) throws Exception {
		boolean isActive = false;

		WebElement textlink = findElement(pageObjects.getByElement(pageName, elementName));
		if (textlink.isEnabled()) {

			isActive = true;
			log.info(elementName + "is Active");

		} else {
			log.info(elementName + "is Disabled");
		}
		return isActive;
	}
	
	public static void createTestFiles() {
		try {
			File parentDirectory = new File(EnvironmentConstant.MAIN_FOLDER);
            String forwardSlash = "/";

			log.info("\nTest Files Location : " + parentDirectory.getAbsolutePath());

			//Move files from the resources directory to the test info directory
			if (!new File(EnvironmentConstant.DATA_FOLDER + EnvironmentConstant.DEFAULT_TEST_DATA).exists()) {
				moveFile(EnvironmentConstant.DEFAULT_TEST_DATA, EnvironmentConstant.DEFAULT_TEST_DATA, EnvironmentConstant.DATA_FOLDER);
			}

			//Move files from the resources directory to the test info directory
			if (!new File(EnvironmentConstant.DATA_FOLDER + forwardSlash + EnvironmentConstant.INT_REGRESSION).exists()) {
				moveFile(EnvironmentConstant.INT_REGRESSION, EnvironmentConstant.INT_REGRESSION, EnvironmentConstant.DATA_FOLDER);
			}

			//Move files from the resources directory to the test info directory
			if (!new File(EnvironmentConstant.DATA_FOLDER + forwardSlash + EnvironmentConstant.INT_SMOKE).exists()) {
				moveFile(forwardSlash + EnvironmentConstant.INT_SMOKE, EnvironmentConstant.INT_SMOKE, EnvironmentConstant.DATA_FOLDER);
			}

			//Move files from the resources directory to the test info directory
			if (!new File(EnvironmentConstant.DATA_FOLDER + forwardSlash + EnvironmentConstant.QA_REGRESSION).exists()) {
				moveFile(forwardSlash + EnvironmentConstant.QA_REGRESSION, EnvironmentConstant.QA_REGRESSION, EnvironmentConstant.DATA_FOLDER);
			}

			//Move files from the resources directory to the test info directory
			if (!new File(EnvironmentConstant.DATA_FOLDER + forwardSlash + EnvironmentConstant.QA_SMOKE).exists()) {
				moveFile(forwardSlash + EnvironmentConstant.QA_SMOKE, EnvironmentConstant.QA_SMOKE, EnvironmentConstant.DATA_FOLDER);
			}

			//Move files from the resources directory to the test info directory
			if (!new File(EnvironmentConstant.DATA_FOLDER + forwardSlash + EnvironmentConstant.INT_MASTER).exists()) {
				moveFile(forwardSlash + EnvironmentConstant.INT_MASTER, EnvironmentConstant.INT_MASTER, EnvironmentConstant.DATA_FOLDER);
			}

			//Move files from the resources directory to the test info directory
			if (!new File(EnvironmentConstant.DATA_FOLDER + forwardSlash + EnvironmentConstant.QA_MASTER).exists()) {
				moveFile(forwardSlash + EnvironmentConstant.QA_MASTER, EnvironmentConstant.QA_MASTER, EnvironmentConstant.DATA_FOLDER);
			}


			if (!new File(DriverConstans.CHROME_DRIVER).exists()) {
				moveFile(forwardSlash + DriverConstans.CHROME_DRIVER, DriverConstans.CHROME_DRIVER, EnvironmentConstant.DRIVER_DIR);
			}
			if (!new File(EnvironmentConstant.DRIVER_DIR + DriverConstans.IE_DRIVER).exists()) {
				moveFile(forwardSlash + DriverConstans.IE_DRIVER, DriverConstans.IE_DRIVER, EnvironmentConstant.DRIVER_DIR);
			}

			if (!new File(EnvironmentConstant.PAGE_OBJECT_DIR).exists()) {
				moveFile(forwardSlash + EnvironmentConstant.PAGE_OBJECT, EnvironmentConstant.PAGE_OBJECT, EnvironmentConstant.PAGE_OBJECT_DIR);
			}

			if (!new File(EnvironmentConstant.DOCUMENT_LOCATION+ forwardSlash + EnvironmentConstant.DOCUMENT_TO_UPLOAD).exists()) {
				moveFile(forwardSlash + EnvironmentConstant.DOCUMENT_TO_UPLOAD, EnvironmentConstant.DOCUMENT_TO_UPLOAD, EnvironmentConstant.DOCUMENT_LOCATION);
			}

		} catch (Exception ex) {
			log.error(ex.getCause().getMessage());
		}
	}

	public void acceptAlert() {
		Alert alert = driver.switchTo().alert();
		alert.accept();
	}
	
	public String getAlertText() {
		Alert alert = driver.switchTo().alert();
		return alert.getText();
	}

	public boolean isAlertPresent() {
		boolean isPresent = false;
		try {
			driver.switchTo().alert();
			isPresent = true;

		} catch (NoAlertPresentException e) {
			log.info("Alert is not visible");
		}
		return isPresent;
	}
	
	public void switchToNewWindow() {
		// Store the current window handle
		String winHandleBefore = driver.getWindowHandle();
		setPreviousWindow(winHandleBefore);
		// Switch to new window opened
		for (String winHandle : driver.getWindowHandles()) {

			if (!winHandleBefore.equalsIgnoreCase(winHandle)) {
				driver.switchTo().window(winHandle);

				log.info("Switched from " + winHandleBefore + " to " + winHandle);
				log.info("Switched from " + winHandleBefore + " to " + winHandle);
				break;
			}
		}
	}

	public void setPreviousWindow(String previousWindow) {
		this.previousWindow = previousWindow;
	}

	public void getPreviousWindow(String previousWindow) {
		this.previousWindow = previousWindow;
	}
	
	public boolean isCheckBoxSelected(String pageName, String elementName) throws Exception {
		return findElement(pageObjects.getByElement(pageName, elementName)).isSelected();
	}
	
	public boolean isTickBoxSelected(String pageName, String element) throws Exception {
		boolean isChecked;
		try {
			isChecked = findElement(pageObjects.getByElement(pageName, element)).isSelected();
			return isChecked;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
	
	public static void moveFile(String inputPath, String inputFile, String outputPath) {
		URL url = PageInteraction.class.getResource(inputPath);
		InputStream in;
		OutputStream out;
		try {
			//create output directory if it doesn't exist
			File dir = new File(outputPath);
			if (!dir.exists()) {
				dir.mkdirs();
			}
			in = url.openStream();
			out = new FileOutputStream(outputPath+new File(inputFile).getName());

			byte[] buffer = new byte[1024];
			int read;
			while ((read = in.read(buffer)) != -1) {
				out.write(buffer, 0, read);
			}
			in.close();
			out.flush();
			out.close();
		} catch (FileNotFoundException ex) {
			log.info(ex.getStackTrace());
		} catch (Exception e) {
			log.info(e.getStackTrace());
		}
	}

	protected WebElement findInvisibleElement(By by) {
		try {
			long timestamp = System.nanoTime() / millisecond;
			if (timestamp > millisecond) {
				log.info("Element " + by + " took " + timestamp / millisecond + " second/s to be visible");
				log.info("Element " + by + " took " + timestamp / millisecond + " second/s to be visible");
			}
		} catch (TimeoutException ex) {
			throw new TimeoutException(ex.getMessage());
		}
		return getDriver().findElement(by);
	}

	public void waitForPageToLoad() {
		waitForPageLoad();
	}

	public void waitFor(int timeWaiting) throws InterruptedException {
		Thread.sleep(timeWaiting);

	}

	public WebElement findElementByID(String elementID) {
		return getDriver().findElement(By.id(elementID));
	}

	//Screenshot configuration
	public PageInteraction takeScreenShoot(ScreenShotConfiguration screenShotConfiguration) {
		if (getDriver() == null) {
			throw new IllegalArgumentException("Driver is not configured");
		}
		driver = new Augmenter().augment(getDriver());

		File screenShot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			copyFile(screenShot, new File(screenShotConfiguration.getScreenShotFileName()));
		} catch (IOException e) {
			e.getMessage();
		}

		return this;
	}

	public PageInteraction takeScreenShoot(String screenShot) {
		Date date = new Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH/mm/ss");
		String formattedDate = format.format(date);

		String formatted = formattedDate.replaceAll("/", "h");
		String dateAndHours = formatted.substring(0, 16);
		String minutes = formatted.substring(16, 17);
		String seconds = formatted.substring(17, 19);

		log.info("Formatted dateAndHours: " + dateAndHours);
		log.info("Formatted minutes: " + minutes);
		log.info("Formatted seconds: " + seconds);

		String completeFormatedDate = dateAndHours + "minutes" + seconds + "seconds";
		log.info("Formatted timestamp: " + completeFormatedDate);
		ScreenShotConfiguration screenShotConfiguration = new ScreenShotConfiguration(EnvironmentConstant.SCREEN_SHOTS_DIR + screenShot + "." + stepCounter + ".png");
		log.info("Screen shot: " + screenShot + "." + stepCounter + "(" + completeFormatedDate + ").png" + " captured at time stamp: " + formattedDate);
		stepCounter++;
		return takeScreenShoot(screenShotConfiguration);
	}

	protected void waitForPageLoad() {
		Wait<WebDriver> wait = new WebDriverWait(driver, TIME_OUT);
		wait.until(driver1 -> {
			log.info("Current Window State: "
					+ String.valueOf(((JavascriptExecutor) driver1).executeScript("return document.readyState")));
			return String
					.valueOf(((JavascriptExecutor) driver1).executeScript("return document.readyState"))
					.equals("complete");
		});
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public DriverUtil getUtil() {
		return new DriverUtil(getDriver());
	}

	public void close() {
		getDriver().close();
	}
}
