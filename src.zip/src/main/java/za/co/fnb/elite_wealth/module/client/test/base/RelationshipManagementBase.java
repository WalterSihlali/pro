package za.co.fnb.elite_wealth.module.client.test.base;

import org.apache.log4j.Logger;
import za.co.fnb.elite_wealth.config.ElementConstants;
import za.co.fnb.elite_wealth.config.SeleniumService;
import za.co.fnb.elite_wealth.config.StringConstants;
import za.co.fnb.elite_wealth.module.client.dto.Relationships;
import za.co.fnb.elite_wealth.module.common.CommonActions;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;
import za.co.fnb.elite_wealth.reporting.HtmlReporting;
import za.co.fnb.elite_wealth.reporting.TestStatus;
import za.co.fnb.elite_wealth.util.RetrieveTestData;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class RelationshipManagementBase extends SeleniumService {
	
	private HtmlReporting reporting = new HtmlReporting();
	private static Format formatter = new SimpleDateFormat("YYYY-MM-dd_hh-mm-ss");
	private static Logger log = Logger.getLogger(EntityDetailsBase.class);
	private CommonActions common = new CommonActions();
	
	protected List<Relationships> retrieveRelationshipsData(PageInteraction page) {
		RetrieveTestData retrieveTestData = new RetrieveTestData(page.dataSheetLocation());
		return retrieveTestData.getRelationshipDTO();
	}
	
	public void firstSteps(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_INFO_TAB);
	}
	
	public void lastSteps(PageInteraction page) throws Exception {
		common.checkUpdateSaved(page);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SELECT_ENTITY);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	protected void searchForClient(PageInteraction page, Relationships relationship) {
		String search = relationship.getSearchValue();
		page.takeScreenShoot("entitySearch " + formatter.format(new Date()));
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_TXT, search);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_BTN);
		common.selectClientFromList(page);
		page.takeScreenShoot("updateEntitySearch " + formatter.format(new Date()));
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	protected void selectEntityMenu(PageInteraction page, Relationships relationship) {
		String leadInfo = relationship.getLeadProviderInfo();
		if (leadInfo.equals("Yes")) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OFFICE_MENU);
			page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		} else {
			searchForClient(page, relationship);
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATIONSHIPS_MENU);
			page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		}
	}
	
	private void addRelationshipToEntity(PageInteraction page, Relationships relationship) throws InterruptedException {
		String entityRelation = relationship.getEntity();
		String relationships = relationship.getRelationship();
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATIONSHIPS_ENTITY);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATIONSHIPS_ENTITY, entityRelation);
		page.sendKeyEnter();
		page.waitFor(5000);
		boolean dataReturned = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATIONSHIPS_FIRST_ITEM);
		if (dataReturned) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATIONSHIPS_FIRST_ITEM);
		} else {
			log.info(StringConstants.NO_RELATED_CLIENT_FOUND);
		}
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATIONSHIPS_RELATIONSHIP, relationships);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATIONSHIPS_REPORTING);
		page.takeScreenShoot("addRelationshipToEntity" + formatter.format(new Date()));
	}
	
	private void addRelationshipToStaffMember(PageInteraction page, Relationships relationship) {
		String staffRole = relationship.getRelationStaffRole();
		String staffName = relationship.getStaffName();
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATIONSHIPS_STAFF_ROLE, staffRole);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATIONSHIPS_STAFF_NAME, staffName);
	}
	
	
	private void deleteEntityRelationship(PageInteraction page, Relationships relationship) throws InterruptedException {
		addRelationshipToEntity(page, relationship);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DELETE_RELATIONSHIPS_ENTITY);
		page.takeScreenShoot("deleteRelationshipToEntity" + formatter.format(new Date()));
		
	}
	
	private void addRelationshipToLeadProvider(PageInteraction page, Relationships relationship) throws InterruptedException {
		String leadType = relationship.getLeadProviderType();
		String other = relationship.getOther();
		String staffRole = relationship.getStaffRole();
		String referredBy = relationship.getRefferedBy();
		String entityType = relationship.getEntityType();
		
		if (entityType.equals("Individual")) {
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_LEAD_TYPE, leadType);
			
			if (leadType.equals("Other")) {
				page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEAD_PROVIDER_OTHER, other);
			}
			
			if (leadType.equals(StringConstants.STAFF_MEMBER)) {
				page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEAD_PROVIDER_STAFF_ROLE, staffRole);
			}
			
			if (leadType.equals("Entity") || leadType.equals(StringConstants.STAFF_MEMBER)) {
				page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEAD_PROVIDER_REFERRED);
				page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEAD_PROVIDER_REFERRED, referredBy);
				page.sendKeyEnter();
				page.waitFor(5000);
				boolean dataReturned = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEAD_PROVIDER_FIRST_ITEM);
				if (dataReturned) {
					page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEAD_PROVIDER_FIRST_ITEM);
				} else {
					log.info(StringConstants.NO_RELATED_CLIENT_FOUND);
				}
				page.takeScreenShoot("addRelationshipToLeadProvider" + common.getDateFormat());
			}
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OFFICE_SAVE);
		}
		
		if (entityType.equals("Legal")) {
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_LEAD_TYPE, leadType);
			
			if (leadType.equals("Other")) {
				page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEGAL_LEAD_PROVIDER_OTHER, other);
			}
			
			if (leadType.equals(StringConstants.STAFF_MEMBER)) {
				page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEGAL_LEAD_PROVIDER_STAFF_ROLE, staffRole);
			}
			
			if (leadType.equals("Entity") || leadType.equals(StringConstants.STAFF_MEMBER)) {
				page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEAD_PROVIDER_REFERRED);
				page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEAD_PROVIDER_REFERRED, referredBy);
				page.sendKeyEnter();
				page.waitFor(5000);
				boolean dataReturned = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEGAL_LEAD_PROVIDER_FIRST_ITEM);
				
				if (dataReturned) {
					page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEGAL_LEAD_PROVIDER_FIRST_ITEM);
				} else {
					log.info(StringConstants.NO_RELATED_CLIENT_FOUND);
				}
				page.takeScreenShoot("addRelationshipToLeadProvider" + formatter.format(new Date()));
			}
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OFFICE_SAVE);
			
		}
	}
	
	protected void maintainEntityRelationships(PageInteraction page, Relationships relationship) throws Exception {
		String entityRelationship = relationship.getAddEntityRelationships();
		String staffRelationship = relationship.getAddStaffRelationship();
		String deleteEntityRelationship = relationship.getDeleteEntity();
		String leadInfo = relationship.getLeadProviderInfo();
		String testCase = relationship.getTestCase();
		List<String> testCaseSteps;
		
		if (entityRelationship.equals("Yes")) {
			addRelationshipToEntity(page, relationship);
			log.info("Add relationship to entity");
		}
		
		if (staffRelationship.equals("Yes")) {
			addRelationshipToStaffMember(page, relationship);
			log.info("Add relationship to staff member");
		}
		
		if (deleteEntityRelationship.equals("Yes")) {
			deleteEntityRelationship(page, relationship);
			log.info("Delete entity relationship");
		}
		
		if (leadInfo.equals("Yes")) {
			addRelationshipToLeadProvider(page, relationship);
			log.info("Add relationship to lead provider");
		}
		
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATIONSHIPS_SAVE);
		boolean saved = common.checkUpdateSaved(page);
		if (saved) {
			testCaseSteps = common.testCaseSteps("Login,Search entity,Update Entity,Entity relationship updated successfully");
			reporting.generateReport(testCase, testCaseSteps, TestStatus.PASS);
		} else {
			testCaseSteps = common.testCaseSteps("Failed to update entity relationship successfully");
			reporting.generateReport(testCase, testCaseSteps, TestStatus.FAIL);
			log.info("Failed to update client relationships details");
		}
		page.waitFor(1000);
	}
}
