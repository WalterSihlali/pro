package za.co.fnb.elite_wealth.module.client.test;

import org.apache.log4j.Logger;
import org.junit.Test;
import za.co.fnb.elite_wealth.module.client.dto.NewLegalEntity;
import za.co.fnb.elite_wealth.module.client.test.base.EntityBase;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;

public class LegalEntityCreateTest extends EntityBase {

	private static Logger log = Logger.getLogger(LegalEntityCreateTest.class);

	@Test
	public void newLegalEntityTest() {
		try {
			PageInteraction page =new PageInteraction(driver);
			firstSteps(page);
			for (NewLegalEntity client : retrieveLegalEntityData(page)) {
				addNewLegalEntity(page, client);
				legalLastSteps(page);
			}
		} catch (Exception ex) {
			log.info(ex.getMessage());
		}
	}
}
