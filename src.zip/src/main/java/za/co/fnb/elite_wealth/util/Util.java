package za.co.fnb.elite_wealth.util;

public class Util {

	private Util(){}
	// ConfigData Columns
	public static final int LOGIN_BOOK_NO = 0;
	public static final int LOGIN_COLUMNS = 5;
	public static final int EW_CONFIG_BOOK_NO = 3;

	// Staff Info Data Columns
	public static final int STAFF_INFO_COLUMN = 27;
	public static final int CONFIG_DATA_ROW_NO = 3;
	public static final int STAFF_DETAILS_ROWS_NO = 49;
	public static final int STAFF_BANK_AND_TAX_ROWS_NO = 15;
	public static final int STAFF_MEMBERSHIP_ROWS_NO = 6;
	public static final int STAFF_ADMINISTRATION_ROWS_NO = 12;

	// Work Portal Data Columns
	public static final int WORK_PORTAL_ROW_NO = 11;
	public static final int WORK_PORTA_ADMINISTRATION_RAW_NO = 4;
	public static final int WORK_PORTAL_CLIENT_DOCUMENT = 5;
	public static final int WORK_PORTAL_INTERACTION_AND_NOTES = 10;
	public static final int WORK_PORTAL_REMINDERS = 7;

	// Client Info Data Columns
	public static final int INDIVIDUAL_ENTITY_COLUMNS = 39;
	public static final int LEGAL_ENTITY_COLUMNS = 21;
	public static final int COMBINED_ENTITY_COLUMNS = 24;
	public static final int SEARCH_ENTITY = 4;
	public static final int UPDATE_INDIVIDUAL_ENTITY = 71;
	public static final int UPDATE_LEGAL_ENTITY = 56;
	public static final int UPDATE_RELATED_ENTITY = 13;
	public static final int RELATIONSHIPS = 21;
	public static final int GENERAL_DETAILS = 56;
	public static final int REPORTS = 26;

	//Portfolio
	public static final int PORTFOLIO_ROWS_NO =42;

	// Investment Planning Data Columns
	public static final int IP_GENERAL = 4;
	public static final int IP_INPUT = 80;
	//FNA
	public static  final int FNA_SCENARIO_RAWS=18;
	public static final int FNA_ALL_ROWS =14;

	public static final int IP_RESULTS = 28;
	public static final int IP_ALLOCATION = 17;

	// Budget Data Columns
	public static final int BUDGET = 44;

	// Assets and Liabilities Data Columns
	public static final int ASSETS_AND_LIABILITIES = 26;

	// Assets and Liabilities Details Data Columns
	public static final int ASSETS_AND_LIABILITIES_DETAILS = 46;

	// Risk Return Data Columns
	public static final int RISK_RETURNS = 23;

	// Workflow Data Columns
	public static final int WORK_FLOW = 11;
	public  static final int FINANCIAL_CALCULATIONS_ROWS =12;

	// Master Sync Add Product Data Columns
	public static final int MASTER_SYNC = 14;


}
