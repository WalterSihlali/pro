package za.co.fnb.elite_wealth.module;

import org.junit.runner.JUnitCore;
import za.co.fnb.elite_wealth.module.assets_and_liabilities.test.AssetsAndLiabilitiesDetailsTest;
import za.co.fnb.elite_wealth.module.assets_and_liabilities.test.AssetsAndLiabilitiesTest;
import za.co.fnb.elite_wealth.module.budget.test.BudgetTest;
import za.co.fnb.elite_wealth.module.client.test.*;
import za.co.fnb.elite_wealth.module.fna.test.*;
import za.co.fnb.elite_wealth.module.investment_planning.test.InvestmentPlanningAllocationTest;
import za.co.fnb.elite_wealth.module.investment_planning.test.InvestmentPlanningGeneralTest;
import za.co.fnb.elite_wealth.module.investment_planning.test.InvestmentPlanningInputTest;
import za.co.fnb.elite_wealth.module.investment_planning.test.InvestmentPlanningResultsTest;
import za.co.fnb.elite_wealth.module.portfolio.test.*;
import za.co.fnb.elite_wealth.module.portfolio.test.EntitySearchTest;
import za.co.fnb.elite_wealth.module.risk_return.RiskReturnTest;
import za.co.fnb.elite_wealth.module.staff.test.*;
import za.co.fnb.elite_wealth.module.work_portal.test.*;

public class MainApp {
	public static void main(String [] args){
		JUnitCore.runClasses(

				EntitySearchTest.class,
				IndividualEntityCreateTest.class,
				LegalEntityCreateTest.class,
				LegalAndIndividualEntityCreateTest.class,
				LegalEntityUpdateTest.class,
				IndividualEntityUpdateTest.class,
				GeneralDetailsTest.class,
				RelationshipsTest.class,
				RelatedEntityTest.class,
				InvestmentPlanningGeneralTest.class,
				InvestmentPlanningInputTest.class,
				InvestmentPlanningResultsTest.class,
				RiskReturnTest.class,
				WorkFlowTest.class,
				InvestmentPlanningAllocationTest.class,
				AssetsAndLiabilitiesTest.class,
				AssetsAndLiabilitiesDetailsTest.class,
				BudgetTest.class,
				AssetsAndLiabilitiesTest.class,
				AssetsAndLiabilitiesDetailsTest.class,
				BudgetTest.class,
				StaffInfoTest.class,
				StaffDetailsTest.class,
				BankAndTaxTest.class,
				MembershipTest.class,
				AdministrationTest.class,

				ClientDocumentsTest.class,
				DocumentTemplatesTest.class,
				InteractionsAndNotesTest.class,
				RemindersTest.class,
				WorkPortalAdministrationTest.class,
				WorkQueueTest.class,
				BankAndTaxTest.class,

				BatchProcessesTest.class,
				EntitySearchTest.class,
				EntityTest.class,
				MarketExposureTest.class,
				PortfolioRegisterTest.class,
				ToolsAndLookupsTest.class,
				ReportsTest.class,
				PortfolioFeesTest.class,
				FnbFeesTest.class,

				CurrentEstateTest.class,
				FNAssetsAndLiabilitiesTest.class,
				InvestmentsAndAssuranceTest.class,
				NeedsTest.class,
				PermanentDisabilityTest.class,
				ProvisionsTest.class,
				ScenarioTest.class,
				TempDisabilityTest.class,
				ToolsTest.class,
				WealthCreationTest.class
		);
	}
}
