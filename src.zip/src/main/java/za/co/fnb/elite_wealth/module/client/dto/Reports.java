package za.co.fnb.elite_wealth.module.client.dto;

import java.util.List;

public class Reports {
	private String testCase;
	private String testScenario;
	private String searchValue;
	private String reportType;
	private String changeFilter;
	private String predefinedFilter;
	private String company;
	private String companyFilter;
	private String office;
	private String officeFilter;
	private String entityStatus;
	private String entityStatusFilter;
	private String reportClass;
	private String classFilter;
	private String reportTag;
	private String tagFilter;
	private String entityType;
	private String entityTypeFilter;
	private String advisor;
	private String advisorFilter;
	private String otherStaffRole;
	private String otherStaffRoleFilter;
	private String otherStaffMember;
	private String otherStaffMemberFilter;
	private String excludeExClients;

	public Reports(List<String> report) {
		int  TEST_CASE =0;
		int  TEST_SCENARIO =1;
		int  SEARCH_VALUE =2;
		int  REPORT_TYPE =3;
		int  CHANGE_FILTER=4;
		int  PREDIFINED_FILTER=5;
		int  COMPANY =6;
		int  COMPANY_FILTER=7;
		int  OFFICE=8;
		int  OFFICE_FILTER =9;
		int  ENTITY_STATUS =10;
		int  ENTITY_STATUS_FILTER = 11;
		int  REPORT_CLASS=12;
		int  CLASS_FLITER=13;
		int  REPORT_TAG=14;
		int  TAG_FILTER =15;
		int  ENTITY_TYPE = 16;
		int  ENTITY_TYPE_FILTER = 17;
		int  ADVISOR = 18;
		int  ADVISOR_FILTER = 19;
		int  OTHER_STAFF_ROLE=20;
		int  OTHER_STAFF_ROLE_FILTER =21;
		int  OTHER_STAFF_MEMBER = 22;
		int  OTHER_STAFF_MEMBER_FILTER = 23;
		int  EXCLUDE_EX_CLIENTS = 24;
		setTestCase(report.get(TEST_CASE));
		setTestScenario(report.get(TEST_SCENARIO));
		setSearchValue(report.get(SEARCH_VALUE));
		setReportType(report.get(REPORT_TYPE));
		setChangeFilter(report.get(CHANGE_FILTER));
		setPredefinedFilter(report.get(PREDIFINED_FILTER));
		setCompany(report.get(COMPANY));
		setCompanyFilter(report.get(COMPANY_FILTER));
		setOffice(report.get(OFFICE));
		setOfficeFilter(report.get(OFFICE_FILTER));
		setEntityStatus(report.get(ENTITY_STATUS));
		setEntityStatusFilter(report.get(ENTITY_STATUS_FILTER));
		setReportClass(report.get(REPORT_CLASS));
		setClassFilter(report.get(CLASS_FLITER));
		setReportTag(report.get(REPORT_TAG));
		setTagFilter(report.get(TAG_FILTER));
		setEntityType(report.get(ENTITY_TYPE));
		setEntityTypeFilter(report.get(ENTITY_TYPE_FILTER));
		setAdvisor(report.get(ADVISOR));
		setAdvisorFilter(report.get(ADVISOR_FILTER));
		setOtherStaffRole(report.get(OTHER_STAFF_ROLE));
		setOtherStaffRoleFilter(report.get(OTHER_STAFF_ROLE_FILTER));
		setOtherStaffMember(report.get(OTHER_STAFF_MEMBER));
		setOtherStaffMemberFilter(report.get(OTHER_STAFF_MEMBER_FILTER));
		setExcludeExClients(report.get(EXCLUDE_EX_CLIENTS));
	}

	public String getTestCase() {
		return testCase;
	}

	public void setTestCase(String testCase) {
		this.testCase = testCase;
	}

	public String getTestScenario() {
		return testScenario;
	}

	public void setTestScenario(String testScenario) {
		this.testScenario = testScenario;
	}

	public String getSearchValue() {
		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	public String getChangeFilter() {
		return changeFilter;
	}

	public void setChangeFilter(String changeFilter) {
		this.changeFilter = changeFilter;
	}

	public String getPredefinedFilter() {
		return predefinedFilter;
	}

	public void setPredefinedFilter(String predefinedFilter) {
		this.predefinedFilter = predefinedFilter;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getCompanyFilter() {
		return companyFilter;
	}

	public void setCompanyFilter(String companyFilter) {
		this.companyFilter = companyFilter;
	}

	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	public String getOfficeFilter() {
		return officeFilter;
	}

	public void setOfficeFilter(String officeFilter) {
		this.officeFilter = officeFilter;
	}

	public String getEntityStatus() {
		return entityStatus;
	}

	public void setEntityStatus(String entityStatus) {
		this.entityStatus = entityStatus;
	}

	public String getEntityStatusFilter() {
		return entityStatusFilter;
	}

	public void setEntityStatusFilter(String entityStatusFilter) {
		this.entityStatusFilter = entityStatusFilter;
	}

	public String getReportClass() {
		return reportClass;
	}

	public void setReportClass(String reportClass) {
		this.reportClass = reportClass;
	}

	public String getClassFilter() {
		return classFilter;
	}

	public void setClassFilter(String classFilter) {
		this.classFilter = classFilter;
	}

	public String getReportTag() {
		return reportTag;
	}

	public void setReportTag(String reportTag) {
		this.reportTag = reportTag;
	}

	public String getTagFilter() {
		return tagFilter;
	}

	public void setTagFilter(String tagFilter) {
		this.tagFilter = tagFilter;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getEntityTypeFilter() {
		return entityTypeFilter;
	}

	public void setEntityTypeFilter(String entityTypeFilter) {
		this.entityTypeFilter = entityTypeFilter;
	}

	public String getAdvisor() {
		return advisor;
	}

	public void setAdvisor(String advisor) {
		this.advisor = advisor;
	}

	public String getAdvisorFilter() {
		return advisorFilter;
	}

	public void setAdvisorFilter(String advisorFilter) {
		this.advisorFilter = advisorFilter;
	}

	public String getOtherStaffRole() {
		return otherStaffRole;
	}

	public void setOtherStaffRole(String otherStaffRole) {
		this.otherStaffRole = otherStaffRole;
	}

	public String getOtherStaffRoleFilter() {
		return otherStaffRoleFilter;
	}

	public void setOtherStaffRoleFilter(String otherStaffRoleFilter) {
		this.otherStaffRoleFilter = otherStaffRoleFilter;
	}

	public String getOtherStaffMember() {
		return otherStaffMember;
	}

	public void setOtherStaffMember(String otherStaffMember) {
		this.otherStaffMember = otherStaffMember;
	}

	public String getOtherStaffMemberFilter() {
		return otherStaffMemberFilter;
	}

	public void setOtherStaffMemberFilter(String otherStaffMemberFilter) {
		this.otherStaffMemberFilter = otherStaffMemberFilter;
	}

	public String getExcludeExClients() {
		return excludeExClients;
	}

	public void setExcludeExClients(String excludeExClients) {
		this.excludeExClients = excludeExClients;
	}

}
