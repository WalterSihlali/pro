package za.co.fnb.elite_wealth.module.client.dto;

import java.util.List;

public class IndividualEntityDetails {
	private String testCase;
	private String testScenario;
	private String searchValue;

	// Personal details
	private String personal;
	private String title;
	private String suffix;
	private String maritalStatus;
	private String religion;
	private String numberOfDependants;
	private String deceased;
	private String smokerType;
	private String retirementAge;

	// Office details
	private String office;
	private String deActivateEntity;
	private String makeEntityClient;



	private String companyInfo;
	private String officeInfo;
	private String countryOfRes;
	private String status;
	private String navCurrency;
	private String estimatedNAV;
	private String dealSizeCurrency;
	private String dealSizeValue;
	private String expectedClosureDate;
	private String proposalDate;
	private String incomeClass;
	private String annualIncomeCurrency;
	private String annualIncome;
	private String grossIncomeCurrency;
	private String grossIncome;
	private String riskProfile;
	private String publicRoles;

	// Contact details
	private String addPreferredContact;
	private String preferredContact;
	private String meetingPlace;

	private String addEmail;
	private String emailType;
	private String emailAddress;
	private String deleteEmail;

	private String addTelephone;
	private String telephoneType;
	private String countryCode;
	private String areaCode;
	private String phoneNumber;
	private String extension;
	private String deletePhone;

	private String addAddress;
	private String addressType;
	private String addresses;
	private String address1;
	private String address2;
	private String suburb;
	private String city;
	private String postalCode;
	private String country;
	private String deleteAddress;

	// Compliance details
	private String compliance;
	private String updateStatus;
	private String effectiveDate;

	// Work details
	private String work;
	private String createTask;
	private String taskDescription;
	private String createWorkflow;
	private String workFlowType;

	// Transaction details
	private String interactions;
	private String interactionsType;

	// Notes details
	private String notes;
	private String notesDescription;

	// Reports details
	private String reports;
	private String reportType;

	// Setup tags details
	private String setupTags;
	private String description;
	private String deleteTag;

	public IndividualEntityDetails(List<String> entity){
		int  TEST_CASE =0;
		int  TEST_SCENARIO =1;
		int  SEARCH_VALUE =2;
		int  PERSONAL =3;
		int  TITLE=4;
		int  SUFFIX =5;
		int  MARITAL_STATUS =6;
		int  RELIGION =7;
		int  NUMBER_OF_DEPENDANTS =8;
		int  DECEASED =9;
		int  SMOKER_TYPE =11;
		int  RETIREMENT_AGE =11;
		int  OFFICE =12;
		int  DEACTIVATE_ENTITY =13;
		int  MAKE_ENTITY_CLIENT=14;
		int  COMPANY_INFO= 15;
		int  OFFICE_INFO=16;
		int  COUNTRY_OF_RES =17;
		int  STATUS =18;
		int  NAV_CURRENCY=19;
		int  ESTIMATED_NAV =20;
		int  DEAL_SIZE_CURRENCY =21;
		int  DEAL_SIZE_VALUE =22;
		int  EXPECTED_CLOSURE_DATE = 23;
		int  PROPOSAL_DATE = 24;
		int  INCOME_CLASS = 25;
		int  ANNUAL_INCOME_CURRENCY = 26;
		int  ANNUAL_INCOME = 27;
		int  GROSS_INCOME_CURRENCY = 28;
		int  GROSS_INCOME = 29;
		int  RISK_PROFILE = 30;
		int  PUBLIC_ROLES = 31;
		int  ADD_PREFERRED_CONTACT = 32;
		int  PREFERRED_CONTACT = 33;
		int  MEETING_PLACE = 34;
		int  ADD_EMAIL = 35;
		int  EMAIL_TYPE = 36;
		int  EMAIL_ADDRESS = 37;
		int  DELETE_EMAIL = 38;

		int  ADD_TELEPHONE = 39;
		int  TELEPHONE_TYPE = 40;
		int  COUNTRY_CODE = 41;
		int  AREA_CODE = 42;
		int  PHONE_NUMBER = 43;
		int  EXTENSION = 44;
		int  DELETE_PHONE = 45;

		int  ADD_ADDRESS = 46;
		int  ADDRESS_TYPE = 47;
		int  ADDRESSES = 48;
		int  ADDRESS_1 = 49;
		int  ADDRESS_2 = 50;
		int  SUBURB = 51;
		int  CITY = 52;
		int  POSTAL_CODE = 53;
		int  COUNTRY = 54;
		int  DELETE_ADDRESS = 55;
		int  COMPLIANCE =56;
		int  UPDATE_STATUS =57;
		int  EFFECTIVE_DATE = 58;

		int  WORK = 59;
		int  CREATE_TASK = 60;
		int  TASK_DESC = 61;
		int  CREATE_WORKFLOW = 62;
		int  WORKFLOW_TYPE = 63;
		int  INTERACTIONS = 64;
		int  INTERACTIONS_TYPE = 65;
		int  NOTES =66;
		int  NOTES_DESC =67;
		int	 SETUP_TAGS = 68;
		int	 DESCRIPTION = 69;
		int	 DELETE_TAGS = 70;
		setTestCase(entity.get(TEST_CASE));
		setTestScenario(entity.get(TEST_SCENARIO));
		setSearchValue(entity.get(SEARCH_VALUE));
		setPersonal(entity.get(PERSONAL));
		setTitle(entity.get(TITLE));
		setSuffix(entity.get(SUFFIX));
		setMaritalStatus(entity.get(MARITAL_STATUS));
		setReligion(entity.get(RELIGION));
		setNumberOfDependants(entity.get(NUMBER_OF_DEPENDANTS));
		setDeceased(entity.get(DECEASED));
		setSmokerType(entity.get(SMOKER_TYPE));
		setRetirementAge(entity.get(RETIREMENT_AGE));
		setOffice(entity.get(OFFICE));
		setDeActivateEntity(entity.get(DEACTIVATE_ENTITY));
		setMakeEntityClient(entity.get(MAKE_ENTITY_CLIENT));
		setCompanyInfo(entity.get(COMPANY_INFO));
		setOfficeInfo(entity.get(OFFICE_INFO));
		setCountryOfRes(entity.get(COUNTRY_OF_RES));
		setStatus(entity.get(STATUS));
		setNavCurrency(entity.get(NAV_CURRENCY));
		setEstimatedNAV(entity.get(ESTIMATED_NAV));
		setDealSizeCurrency(entity.get(DEAL_SIZE_CURRENCY));
		setDealSizeValue(entity.get(DEAL_SIZE_VALUE));
		setExpectedClosureDate(entity.get(EXPECTED_CLOSURE_DATE));
		setProposalDate(entity.get(PROPOSAL_DATE));
		setIncomeClass(entity.get(INCOME_CLASS));
		setAnnualIncomeCurrency(entity.get(ANNUAL_INCOME_CURRENCY));
		setAnnualIncome(entity.get(ANNUAL_INCOME));
		setGrossIncomeCurrency(entity.get(GROSS_INCOME_CURRENCY));
		setGrossIncome(entity.get(GROSS_INCOME));
		setRiskProfile(entity.get(RISK_PROFILE));
		setPublicRoles(entity.get(PUBLIC_ROLES));
		setAddPreferredContact(entity.get(ADD_PREFERRED_CONTACT ));
		setPreferredContact(entity.get(PREFERRED_CONTACT));
		setMeetingPlace(entity.get(MEETING_PLACE));
		setAddEmail(entity.get(ADD_EMAIL));
		setEmailType(entity.get(EMAIL_TYPE));
		setEmailAddress(entity.get(EMAIL_ADDRESS));
		setDeleteEmail(entity.get(DELETE_EMAIL));
		setAddTelephone(entity.get(ADD_TELEPHONE));
		setTelephoneType(entity.get(TELEPHONE_TYPE));
		setCountryCode(entity.get(COUNTRY_CODE));
		setAreaCode(entity.get(AREA_CODE));
		setPhoneNumber(entity.get(PHONE_NUMBER));
		setExtension(entity.get(EXTENSION));
		setDeletePhone(entity.get(DELETE_PHONE));
		setAddAddress(entity.get(ADD_ADDRESS));
		setAddressType(entity.get(ADDRESS_TYPE));
		setAddresses(entity.get(ADDRESSES));
		setAddress1(entity.get(ADDRESS_1));
		setAddress2(entity.get(ADDRESS_2));
		setSuburb(entity.get(SUBURB));
		setCity(entity.get(CITY));
		setCountry(entity.get(COUNTRY));
		setPostalCode(entity.get(POSTAL_CODE));
		setDeleteAddress(entity.get(DELETE_ADDRESS));
		setCompliance(entity.get(COMPLIANCE));
		setUpdateStatus(entity.get(UPDATE_STATUS));
		setEffectiveDate(entity.get(EFFECTIVE_DATE));
		setWork(entity.get(WORK));
		setCreateTask(entity.get(CREATE_TASK));
		setTaskDescription(entity.get(TASK_DESC));
		setCreateWorkflow(entity.get(CREATE_WORKFLOW));
		setWorkFlowType(entity.get(WORKFLOW_TYPE));
		setInteractions(entity.get(INTERACTIONS));
		setInteractionsType(entity.get(INTERACTIONS_TYPE));
		setNotes(entity.get(NOTES));
		setNotesDescription(entity.get(NOTES_DESC));
		setSetupTags(entity.get(SETUP_TAGS));
		setDescription(entity.get(DESCRIPTION));
		setDeleteTag(entity.get(DELETE_TAGS));
	}


	public String getGrossIncome() {
		return grossIncome;
	}

	public void setGrossIncome(String grossIncome) {
		this.grossIncome = grossIncome;
	}
	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	public String getSetupTags() {
		return setupTags;
	}

	public void setSetupTags(String setupTags) {
		this.setupTags = setupTags;
	}

	public String getReports() {
		return reports;
	}

	public void setReports(String reports) {
		this.reports = reports;
	}


	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}



	public String getInteractions() {
		return interactions;
	}

	public void setInteractions(String interactions) {
		this.interactions = interactions;
	}


	public String getWork() {
		return work;
	}

	public void setWork(String work) {
		this.work = work;
	}

	public String getCreateTask() {
		return createTask;
	}

	public void setCreateTask(String createTask) {
		this.createTask = createTask;
	}


	public String getTaskDescription() {
		return taskDescription;
	}

	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}

	public String getCreateWorkflow() {
		return createWorkflow;
	}

	public void setCreateWorkflow(String createWorkflow) {
		this.createWorkflow = createWorkflow;
	}

	public String getWorkFlowType() {
		return workFlowType;
	}

	public void setWorkFlowType(String workFlowType) {
		this.workFlowType = workFlowType;
	}

	public String getNotesDescription() {
		return notesDescription;
	}

	public void setNotesDescription(String notesDescription) {
		this.notesDescription = notesDescription;
	}

	public String getInteractionsType() {
		return interactionsType;
	}

	public void setInteractionsType(String interactionsType) {
		this.interactionsType = interactionsType;
	}


	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getUpdateStatus() {
		return updateStatus;
	}

	public void setUpdateStatus(String updateStatus) {
		this.updateStatus = updateStatus;
	}

	public String getTestCase() {
		return testCase;
	}

	public void setTestCase(String testCase) {
		this.testCase = testCase;
	}

	public String getTestScenario() {
		return testScenario;
	}

	public void setTestScenario(String testScenario) {
		this.testScenario = testScenario;
	}

	public String getSearchValue() {
		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	public String getPersonal() {
		return personal;
	}

	public void setPersonal(String personal) {
		this.personal = personal;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getNumberOfDependants() {
		return numberOfDependants;
	}

	public void setNumberOfDependants(String numberOfDependants) {
		this.numberOfDependants = numberOfDependants;
	}

	public String getDeceased() {
		return deceased;
	}

	public void setDeceased(String deceased) {
		this.deceased = deceased;
	}

	public String getSmokerType() {
		return smokerType;
	}

	public void setSmokerType(String smokerType) {
		this.smokerType = smokerType;
	}

	public String getRetirementAge() {
		return retirementAge;
	}

	public void setRetirementAge(String retirementAge) {
		this.retirementAge = retirementAge;
	}

	public String getCompanyInfo() {
		return companyInfo;
	}

	public void setCompanyInfo(String companyInfo) {
		this.companyInfo = companyInfo;
	}
	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	public String getDeActivateEntity() {
		return deActivateEntity;
	}

	public void setDeActivateEntity(String deActivateEntity) {
		this.deActivateEntity = deActivateEntity;
	}

	public String getMakeEntityClient() {
		return makeEntityClient;
	}

	public void setMakeEntityClient(String makeEntityClient) {
		this.makeEntityClient = makeEntityClient;
	}

	public String getOfficeInfo() {
		return officeInfo;
	}

	public void setOfficeInfo(String officeInfo) {
		this.officeInfo = officeInfo;
	}

	public String getCountryOfRes() {
		return countryOfRes;
	}

	public void setCountryOfRes(String countryOfRes) {
		this.countryOfRes = countryOfRes;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getNavCurrency() {
		return navCurrency;
	}

	public void setNavCurrency(String navCurrency) {
		this.navCurrency = navCurrency;
	}

	public String getEstimatedNAV() {
		return estimatedNAV;
	}

	public void setEstimatedNAV(String estimatedNAV) {
		this.estimatedNAV = estimatedNAV;
	}

	public String getDealSizeCurrency() {
		return dealSizeCurrency;
	}

	public void setDealSizeCurrency(String dealSizeCurrency) {
		this.dealSizeCurrency = dealSizeCurrency;
	}

	public String getDealSizeValue() {
		return dealSizeValue;
	}

	public void setDealSizeValue(String dealSizeValues) {
		this.dealSizeValue = dealSizeValues;
	}


	public String getExpectedClosureDate() {
		return expectedClosureDate;
	}

	public void setExpectedClosureDate(String expectedClosureDate) {
		this.expectedClosureDate = expectedClosureDate;
	}

	public String getProposalDate() {
		return proposalDate;
	}

	public void setProposalDate(String proposalDate) {
		this.proposalDate = proposalDate;
	}

	public String getIncomeClass() {
		return incomeClass;
	}

	public void setIncomeClass(String incomeClass) {
		this.incomeClass = incomeClass;
	}

	public String getAnnualIncomeCurrency() {
		return annualIncomeCurrency;
	}

	public void setAnnualIncomeCurrency(String annualIncomeCurrency) {
		this.annualIncomeCurrency = annualIncomeCurrency;
	}

	public String getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}

	public String getGrossIncomeCurrency() {
		return grossIncomeCurrency;
	}

	public void setGrossIncomeCurrency(String grossIncomeCurrency) {
		this.grossIncomeCurrency = grossIncomeCurrency;
	}

	public String getRiskProfile() {
		return riskProfile;
	}

	public void setRiskProfile(String riskProfile) {
		this.riskProfile = riskProfile;
	}

	public String getPublicRoles() {
		return publicRoles;
	}

	public void setPublicRoles(String publicRoles) {
		this.publicRoles = publicRoles;
	}

	public String getPreferredContact() {
		return preferredContact;
	}

	public void setPreferredContact(String preferredContact) {
		this.preferredContact = preferredContact;
	}

	public String getMeetingPlace() {
		return meetingPlace;
	}

	public void setMeetingPlace(String meetingPlace) {
		this.meetingPlace = meetingPlace;
	}

	public String getEmailType() {
		return emailType;
	}

	public void setEmailType(String emailType) {
		this.emailType = emailType;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getDeleteEmail() {
		return deleteEmail;
	}

	public void setDeleteEmail(String deleteEmail) {
		this.deleteEmail = deleteEmail;
	}

	public String getTelephoneType() {
		return telephoneType;
	}

	public void setTelephoneType(String telephoneType) {
		this.telephoneType = telephoneType;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getDeletePhone() {
		return deletePhone;
	}

	public void setDeletePhone(String deletePhone) {
		this.deletePhone = deletePhone;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public String getAddresses() {
		return addresses;
	}

	public void setAddresses(String addresses) {
		this.addresses = addresses;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getSuburb() {
		return suburb;
	}

	public void setSuburb(String suburb) {
		this.suburb = suburb;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getDeleteAddress() {
		return deleteAddress;
	}

	public void setDeleteAddress(String deleteAddress) {
		this.deleteAddress = deleteAddress;
	}

	public String getCompliance() {
		return compliance;
	}

	public void setCompliance(String compliance) {
		this.compliance = compliance;
	}


	public String getAddPreferredContact() {
		return addPreferredContact;
	}

	public void setAddPreferredContact(String addPreferredContact) {
		this.addPreferredContact = addPreferredContact;
	}

	public String getAddTelephone() {
		return addTelephone;
	}

	public void setAddTelephone(String addTelephone) {
		this.addTelephone = addTelephone;
	}

	public String getAddEmail() {
		return addEmail;
	}

	public void setAddEmail(String addEmail) {
		this.addEmail = addEmail;
	}

	public String getAddAddress() {
		return addAddress;
	}

	public void setAddAddress(String addAddress) {
		this.addAddress = addAddress;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDeleteTag() {
		return deleteTag;
	}

	public void setDeleteTag(String deleteTag) {
		this.deleteTag = deleteTag;
	}

}
