import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import za.co.fnb.elite_wealth.module.client.test.EntitySearchTest;
import za.co.fnb.elite_wealth.module.client.test.IndividualEntityUpdateTest;
import za.co.fnb.elite_wealth.module.client.test.LegalEntityUpdateTest;
import za.co.fnb.elite_wealth.module.investment_planning.test.InvestmentPlanningGeneralTest;

@RunWith(Suite.class)

@Suite.SuiteClasses({


})
public class RegressionTest {}
