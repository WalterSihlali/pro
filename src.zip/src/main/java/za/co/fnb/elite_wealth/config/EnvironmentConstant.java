package za.co.fnb.elite_wealth.config;


public class EnvironmentConstant {

    private EnvironmentConstant(){


    }
    public static final String MAIN_FOLDER ="generated_files/";
    public static final String DATA_FOLDER =MAIN_FOLDER+"test_data/";
    public static final String DRIVER_DIR = MAIN_FOLDER+"drivers/";
    public static final String QA_REGRESSION = "test_data/QA_Regression.xlsx";
    public static final String QA_SMOKE = "test_data/QA_Smoke.xlsx";
    public static final String INT_REGRESSION = "/test_data/INT_Regression.xlsx";
    public static final String INT_SMOKE = "test_data/INT_Smoke.xlsx";
    public static final String INT_MASTER = "test_data/INT_Master.xlsx";
    public static final String QA_MASTER= "test_data/QA_Master.xlsx";

    public static final String RESOURCES_TEST_DATA_FOLDER = "test_data";
    public static final String DEFAULT_TEST_DATA = "/test_data/EW Test Data.xlsx";
    public static final String PAGE_OBJECT_DIR =MAIN_FOLDER+"page_objects/";
    public static final String PAGE_OBJECT= "PageObjects.xml";
    public static final String REPORT_DIRECTORY =MAIN_FOLDER+"/report/";
    public static final String SCREEN_SHOTS_DIR =MAIN_FOLDER+"/screen_shots/";
    public static final String REPORT_CONFIG_FILE ="src/main/resources/report-config.xml";
    public static final String HTML_REPORT_FILE =REPORT_DIRECTORY+"testResults"+".html";
    public static final String DOCUMENT_LOCATION =MAIN_FOLDER+"docs/";
    public static final String DOCUMENT_TO_UPLOAD ="docs/Doc1.pdf";


}
