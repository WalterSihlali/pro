package za.co.fnb.elite_wealth.module.client.test.base;

import org.apache.log4j.Logger;
import za.co.fnb.elite_wealth.config.ElementConstants;
import za.co.fnb.elite_wealth.config.SeleniumService;
import za.co.fnb.elite_wealth.config.StringConstants;
import za.co.fnb.elite_wealth.module.client.dto.IndividualAndLegalEntity;
import za.co.fnb.elite_wealth.module.client.dto.NewIndividualEntity;
import za.co.fnb.elite_wealth.module.client.dto.NewLegalEntity;
import za.co.fnb.elite_wealth.module.common.CommonActions;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;
import za.co.fnb.elite_wealth.reporting.HtmlReporting;
import za.co.fnb.elite_wealth.reporting.TestStatus;
import za.co.fnb.elite_wealth.util.RetrieveTestData;

import java.util.Arrays;
import java.util.List;

public class EntityBase extends SeleniumService {
	private HtmlReporting reporting = new HtmlReporting();
	private List<String> testCaseSteps;
	private CommonActions common = new CommonActions();
	private static Logger log = Logger.getLogger(EntityBase.class);
	
	protected List<NewIndividualEntity> retrieveIndividualEntityData(PageInteraction page) {
		RetrieveTestData retrieveTestData = new RetrieveTestData(page.dataSheetLocation());
		return retrieveTestData.getIndividualEntityDTO();
	}
	
	protected List<NewLegalEntity> retrieveLegalEntityData(PageInteraction page) {
		RetrieveTestData retrieveTestData = new RetrieveTestData(page.dataSheetLocation());
		return retrieveTestData.getLegalEntityDTO();
	}
	
	protected List<IndividualAndLegalEntity> retrieveLegalRelatedEntityData(PageInteraction page) {
		RetrieveTestData retrieveTestData = new RetrieveTestData(page.dataSheetLocation());
		return retrieveTestData.getIndividualAndLegalEntityDTO();
	}
	
	protected void firstSteps(PageInteraction page) {
		openClientInfo(page);
	}
	
	private void openClientInfo(PageInteraction page) {
		boolean element = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_INFO_TAB);
		if (element) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_INFO_TAB);
			page.takeScreenShoot("openClientInfo " + common.getDateFormat());
			log.info("open Client Info");
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.NEW_CLIENT);
		}
	}
	
	private void validatePositiveClientInfo(PageInteraction page) {
		page.acceptAlert();
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	
	protected void lastSteps(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.NEW_CLIENT2);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	protected void legalLastSteps(PageInteraction page) throws InterruptedException {
		
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
		boolean elementPresent = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.NEW_CLIENT2);
		
		if(elementPresent) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.NEW_CLIENT2);
		} else {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.NEW_CLIENT);
		}
		page.waitFor(2000);
	}
	
	private void validateNegativeClientInfo(PageInteraction page) throws Exception {
		String actualError = page.getStringValue(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ADD_NEW_CLIENT_ERROR);
		String expectedError = StringConstants.WE_CANNOT_CONTINUE;
		try {
			common.assertEquals(actualError, expectedError);
		} catch (Exception ex) {
			log.info(ex.getMessage());
		}
		page.waitFor(2000);
		if (actualError.equals(StringConstants.WE_CANNOT_CONTINUE)) {
			testCaseSteps = common.testCaseSteps("Failed to successfully add New Legal & Individual Entity");
			reporting.generateReport("Negative Test Add Legal", testCaseSteps, TestStatus.PASS);
			log.info("Client created successfully");
		} else {
			testCaseSteps = common.testCaseSteps("Successfully added New Legal & Individual Entity check your data");
			reporting.generateReport("Negative Test Add Legal", testCaseSteps, TestStatus.FAIL);
		}
		page.takeScreenShoot("addNewIndividualClient " + common.getDateFormat());
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_MENU);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.NEW_CLIENT);
		page.waitFor(2000);
	}
	
	protected void addNewIndividualEntity(PageInteraction page, NewIndividualEntity individual) throws Exception {
		String testCase = individual.getTestCase();
		String name = individual.getName();
		String surname = individual.getSurname();
		String status = individual.getStatus();
		String company = individual.getCompany();
		String office = individual.getOffice();
		String incomeClass = individual.getIncomeClass();
		String title = individual.getTitle();
		String gender = individual.getGender();
		String nationality = individual.getNationality();
		String countryOfBirth = individual.getCountryOfBirth();
		String dateOfBirth = individual.getDateOfBirth();
		String countryOfRes = individual.getCountryOfResidence();
		String saID = individual.getSaIDNumber();
		String passportNumber = individual.getPassportNumber();
		String homeLang = individual.getHomeLanguage();
		String correspondenceLang = individual.getCorrespondenceLanguage();
		String maritalStatus = individual.getMaritalStatus();
		String maritalDate = individual.getMaritalDate();
		String staffRole = individual.getStaffRole();
		String role = individual.getRole();
		String staffMember = individual.getStaffMember();
		String leadProviderType = individual.getLeadProviderType();
		String notes = individual.getNotes();
		String addresses = individual.getAddresses();
		String statusUnknown = "Married (status unknown)";
		String anc = "Married ANC";
		String accrual = "Married ANC with accrual";
		String icop = "Married ICOP";
		String customary = "Married in customary law";
		String separated = "Separated";
		String widowed = "Widowed";
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OPT_INDIVIDUAL);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_NAME, name);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_SURNAME, surname);
		page.takeScreenShoot(testCase + common.getDateFormat());
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CONTINUE);
		page.takeScreenShoot(testCase + " " + common.getDateFormat());
		page.waitFor(2000);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_STATUS, status);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.COMPANY, company);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OFFICE, office);
		
		page.selectOptionFromList(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INCOME_CLASS, incomeClass);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.TITLE, title);
		page.selectOptionFromList(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.GENDER, gender);
		page.takeScreenShoot(testCase + common.getDateFormat());
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.NATIONALITY, nationality);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.COUNTRY_OF_BIRTH, countryOfBirth);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.COUNTRY_OF_RES, countryOfRes);
		page.takeScreenShoot(testCase + common.getDateFormat());
		
		if (nationality.equals("South African")) {
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SAID, saID);
		} else {
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.DATE_OF_BIRTH, dateOfBirth);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PASSPORT_NUMBER, passportNumber);
		}
		page.selectOptionFromList(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.HOME_LANG, homeLang);
		page.selectOptionFromList(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CORRESPONDENCE_LANG, correspondenceLang);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.MARITAL_STATUS, maritalStatus);
		if (maritalStatus
				.equals(statusUnknown) ||
				maritalStatus.equals(anc) ||
				maritalStatus.equals(accrual) ||
				maritalStatus.equals(icop) ||
				maritalStatus.equals(customary) ||
				maritalStatus.equals(separated) ||
				maritalStatus.equals(widowed)) {
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.MARITAL_DATE, maritalDate);
		}
		page.takeScreenShoot(testCase + common.getDateFormat());
		
		if (addresses.equals("Yes")) {
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CREATE_ADDRESSES, "Office");
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CREATE_LINE1, "340 Kent");
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CREATE_CITY);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CREATE_CITY, "Randburg");
		}
		
		if (addresses.equals("Yes")) {
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CREATE_EMAILS, "Office");
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CREATE_EMAIL_ADDRESS, "client@gmail.com");
		}
		
		if (role.equals(StringConstants.WEALTH_ADMIN) || role.equals(StringConstants.ADMIN)) {
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.IND_STAFF_ROLE, staffRole);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.IND_STAFF_MEMBER, staffMember);
		}
		page.takeScreenShoot(testCase + common.getDateFormat());
		
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEAD_PROVIDER, leadProviderType);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.NOTES, notes);
		log.info("Populate client info details");
		page.takeScreenShoot(testCase + " " + common.getDateFormat());
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SAVE);
		page.waitFor(2000);
		boolean alertPresent = page.isAlertPresent();
		
		if (alertPresent) {
			String[] steps = {"login,click new client,select individual entity,add individual entity details,save entity details"};
			validatePositiveClientInfo(page);
			testCaseSteps = Arrays.asList(steps);
			reporting.generateReport(testCase, testCaseSteps, TestStatus.PASS);
		} else {
			String[] steps = {"Failed to to add new individual entity"};
			testCaseSteps = Arrays.asList(steps);
			reporting.generateReport(testCase, testCaseSteps, TestStatus.FAIL);
			log.info("Failed to add new individual client");
		}
	}
	
	protected void addNewLegalEntity(PageInteraction page, NewLegalEntity legalEntity) throws Exception {
		String testCase = legalEntity.getTestCase();
		String testScenario = legalEntity.getTestScenario();
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OPT_LEGAL);
		String registeredName = legalEntity.getRegisteredName();
		String status = legalEntity.getStatus();
		String company = legalEntity.getCompany();
		String office = legalEntity.getOffice();
		String incomeClass = legalEntity.getIncomeClass();
		String entityType = legalEntity.getEntityType();
		String registeredNumber = legalEntity.getRegistrationNumber();
		String mastersOffice = legalEntity.getMastersOffice();
		String legalLeadProvider = legalEntity.getLeadProviderType();
		String legalNotes = legalEntity.getNotes();
		String staffRole = legalEntity.getStaffRole();
		String role = legalEntity.getRole();
		String staffMember = legalEntity.getStaffMember();
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.REGISTERED_NAME, registeredName);
		page.takeScreenShoot(testCase + common.getDateFormat());
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CONTINUE);
		log.info("Search for client to check if already exists");
		page.waitFor(2000);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEGAL_STATUS, status);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEGAL_COMPANY, company);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEGAL_OFFICE, office);
		page.selectOptionFromList(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEGAL_INCOME_CLASS, incomeClass);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.ENTITY_TYPE, entityType);
		page.takeScreenShoot(testCase + common.getDateFormat());
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.REGISTERED_NUMBER, registeredNumber);
		page.selectOptionFromList(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.MASTERS_OFFICE, mastersOffice);
		
		if (role.equals(StringConstants.WEALTH_ADMIN) || role.equals(StringConstants.ADMIN)) {
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEGAL_STAFF_ROLE, staffRole);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEGAL_STAFF_MEMBER, staffMember);
		}
		
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEGAL_LEAD_PROVIDER, legalLeadProvider);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEGAL_NOTES, legalNotes);
		log.info("Populated client info details");
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SAVE);
		page.waitFor(2000);
		boolean alertPresent = page.isAlertPresent();
		
		if (testScenario.equals("Positive")) {
			if (alertPresent) {
				validatePositiveClientInfo(page);
				String[] steps = {"login,click new client,select legal entity,add legal entity details,save entity details"};
				testCaseSteps = Arrays.asList(steps);
				reporting.generateReport(testCase, testCaseSteps, TestStatus.PASS);
			} else {
				String[] steps = {"failed to to add new legal entity"};
				testCaseSteps = Arrays.asList(steps);
				reporting.generateReport(testCase, testCaseSteps, TestStatus.FAIL);
				log.info("Failed to add new legal client");
			}
		} else {
			if (!page.isAlertPresent()) {
				validateNegativeClientInfo(page);
			} else {
				log.info("Failed the negative test for as there was an alert. Make sure this is not a positive test data");
				page.takeScreenShoot(testCase + " " + common.getDateFormat());
			}
		}
		page.takeScreenShoot(testCase + " " + common.getDateFormat());
		
	}
	
	protected void addIndividualAndLegalEntity(PageInteraction page, IndividualAndLegalEntity individualAndLegalEntity) throws InterruptedException {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OPT_COMBINED);
		page.waitFor(2000);
		String testCase = individualAndLegalEntity.getTestCase();
		String primaryName = individualAndLegalEntity.getPrimaryName();
		String primarySurname = individualAndLegalEntity.getPrimarySurname();
		String secondaryClient = individualAndLegalEntity.getSecondaryClient();
		String secondaryName = individualAndLegalEntity.getSecondaryName();
		String secondarySurname = individualAndLegalEntity.getSecondarySurname();
		String relationship = individualAndLegalEntity.getRelationship();
		String registeredName = individualAndLegalEntity.getRegisteredName();
		String primaryId = individualAndLegalEntity.getPrimaryID();
		String secondaryId = individualAndLegalEntity.getSecondaryID();
		String primaryMarital = individualAndLegalEntity.getPrimaryMarital();
		String familyLeadProvider = individualAndLegalEntity.getFamilyLeadProvider();
		String relatedEntityType = individualAndLegalEntity.getRelatedEntityType();
		String registrationNumber = individualAndLegalEntity.getRegistrationNumber();
		String staffRole = individualAndLegalEntity.getRole();
		String company = individualAndLegalEntity.getCompany();
		String office = individualAndLegalEntity.getOffice();
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PRIMARY_NAME, primaryName);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PRIMARY_SURNAME, primarySurname);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SECONDARY_CLIENT, secondaryClient);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SECONDARY_NAME, secondaryName);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SECONDARY_SURNAME, secondarySurname);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATIONSHIP, relationship);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.REGISTERED_NAME, registeredName);
		page.takeScreenShoot(testCase + common.getDateFormat());
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CONTINUE);
		log.info("Search for client to check if already exists");
		page.waitFor(2000);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.COMPANY, company);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OFFICE, office);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PRIMARY_SA_ID, primaryId);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SECONDARY_SA_AD, secondaryId);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PRIMARY_MARITAL, primaryMarital);
		
		if (staffRole.equals(StringConstants.WEALTH_ADMIN) || staffRole.equals(StringConstants.ADMIN)) {
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.COMBINED_STAFF_ROLE, "Wealth Manager");
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.COMBINED_STAFF_MEMBER, "Kumar Ahmed");
		}
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.FAMILY_LEAD_PROVIDER, familyLeadProvider);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEGAL_ENTITY_TAB);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.RELATED_LEGAL_TYPE1, relatedEntityType);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LEGAL_REGISTRATION_NUMBER, registrationNumber);
		page.takeScreenShoot(testCase + common.getDateFormat());
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SAVE);
		page.waitFor(1000);
		log.info("Populated client info details");
		boolean alertPresent = page.isAlertPresent();
		
		if (alertPresent) {
			validatePositiveClientInfo(page);
			testCaseSteps = common.testCaseSteps("login,click new client,select individual and legal entity(ies),add individual entity details,click companies and trusts tab,add relevant legal entity details,save entity details");
			reporting.generateReport(testCase, testCaseSteps, TestStatus.PASS);
			log.info("Client created successfully");
			page.takeScreenShoot(testCase + " " + common.getDateFormat());
		} else {
			testCaseSteps = common.testCaseSteps("failed to successfully add new legal & individual entity");
			reporting.generateReport(testCase, testCaseSteps, TestStatus.FAIL);
			log.info("Failed to add new combined client");
			page.takeScreenShoot(testCase + " " + common.getDateFormat());
		}
	}
}
