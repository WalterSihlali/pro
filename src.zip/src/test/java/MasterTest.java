import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import za.co.fnb.elite_wealth.module.master.test.MasterAddProductTest;

@RunWith(Suite.class)

@Suite.SuiteClasses({
		MasterAddProductTest.class
})
public class MasterTest {
}
