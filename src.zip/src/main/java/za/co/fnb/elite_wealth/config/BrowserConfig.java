package za.co.fnb.elite_wealth.config;


import org.apache.log4j.Logger;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.service.DriverService;
import za.co.fnb.elite_wealth.module.common.LoginDetail;
import za.co.fnb.elite_wealth.util.RetrieveTestData;

import java.io.File;

public class BrowserConfig {

    protected static RetrieveTestData retrieveTestData;
    static String browserInstance = getSearchCriteria();
    private static Logger log = Logger.getLogger(BrowserConfig.class);


    protected static WebDriver getDriver() {

        WebDriver driver = null;

        if(browserInstance.equalsIgnoreCase(DriverConstans.CHROME)){
            File file = new File(DriverConstans.CHROME_DRIVER);
            System.setProperty(DriverConstans.CHROME_PROPERTY, file.getAbsolutePath());
            System.out.println("Chrome location : "+file.getAbsolutePath());
            driver = new ChromeDriver();

        }else  if(browserInstance.equalsIgnoreCase(DriverConstans.IE)){
            File file = new File(DriverConstans.IE_DRIVER);
            System.setProperty(DriverConstans.IE_PROPERTY, file.getAbsolutePath());

            driver = new InternetExplorerDriver();
        }
        else  if(browserInstance.equalsIgnoreCase(DriverConstans.FIREFOX)){
            File file = new File(DriverConstans.FIREFOX_DRIVER);
            System.setProperty(DriverConstans.FIREFOX_PROPERTY, file.getAbsolutePath());
            driver = new FirefoxDriver();
        }
        return getDriver();
    }

    public enum Browser {
        Chrome(1), InternetExplorer(2), Firefox(3);

        private int value;
        private Browser(int value) {
            this.value = value;
        }
    }

    private static LoginDetail getLoginDetail(){

        retrieveTestData = new RetrieveTestData(SeleniumService.getEnvironmentPropertiesCopy().getTestDatasheet());
        LoginDetail loginDetail = null;
        if(loginDetail==null){
            loginDetail =retrieveTestData.getLoginDetail();
        }
        return  loginDetail;
    }
    public static String getSearchCriteria() {
        String browser =getLoginDetail().getBrowser();
        Browser searchCriteria = Browser.valueOf(browser);
        try {
            switch (searchCriteria) {
                case Chrome:
                    browser = DriverConstans.CHROME;
                    break;
                case InternetExplorer:
                    browser = DriverConstans.IE;
                    break;
                case Firefox:
                    browser = DriverConstans.FIREFOX;
                    break;
                default:
                    searchCriteria = null;
                    break;
            }
        } catch (Exception e) {
            log.info(e.getStackTrace());
        }
        return browser;
    }

    private static DesiredCapabilities capabilities;

    public BrowserConfig(DriverService service, Capabilities capabilities, ChromeOptions options) {
        super();
    }

    public BrowserConfig(DriverService service, Capabilities capabilities) {
        super();
    }

    public DriverService getService(){
        DriverService service =null;
        try {

            if (browserInstance.equalsIgnoreCase(DriverConstans.CHROME)) {
                service = new ChromeDriverService.Builder().usingDriverExecutable(new File(EnvironmentConstant.DRIVER_DIR + DriverConstans.CHROME_DRIVER)).usingAnyFreePort().build();
            } else if (browserInstance.equalsIgnoreCase(DriverConstans.IE)) {

                service = new InternetExplorerDriverService.Builder().usingDriverExecutable(new File(EnvironmentConstant.DRIVER_DIR + DriverConstans.IE_DRIVER)).usingAnyFreePort().build();
            } else {

                service = null;
            }
        }catch (Exception ex){
            log.info(ex.getStackTrace());
        }
        return service;
    }

    public DesiredCapabilities getCapabilities(){

        if(browserInstance.equalsIgnoreCase(DriverConstans.CHROME)) {
            if (capabilities == null) {
                capabilities = DesiredCapabilities.chrome();
                //the following Chrome options handle the stability and security on newer Chrome drivers
                ChromeOptions options = new ChromeOptions();
                options.addArguments("test-type");
                options.addArguments("disable-popup-blocking");
                options.addArguments("disable-extensions");
                capabilities.setCapability("chrome.binary", "");
                capabilities.setCapability(ChromeOptions.CAPABILITY, options);
            }
        }else if(browserInstance.equalsIgnoreCase(DriverConstans.IE)){
            capabilities = DesiredCapabilities.internetExplorer();
            capabilities.setCapability("ignoreZoomSetting", true);
            capabilities.setCapability("enablePersistentHover", false);

        }else{
            capabilities = DesiredCapabilities.firefox();
            capabilities.setCapability("marionette", true);
            capabilities = DesiredCapabilities.firefox();
        }
        return capabilities;
    }


}
