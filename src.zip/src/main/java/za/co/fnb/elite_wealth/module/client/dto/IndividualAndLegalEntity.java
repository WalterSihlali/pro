package za.co.fnb.elite_wealth.module.client.dto;

import java.util.List;

public class IndividualAndLegalEntity {
	private String testCase;
	private String testScenario;
	private String primaryName;
	private String primarySurname;
	private String secondaryClient;
	private String secondaryName;
	private String secondarySurname;
	private String relationship;
	private String registeredName;
	private String familyAndOther;
	private String primaryID;
	private String secondaryID;
	private String primaryMarital;
	private String secondaryMarital;
	private String familyLeadProvider;
	private String companiesAndTrusts;
	private String relatedEntityType;
	private String registrationNumber;
	private String leadProviderType;
	private String company;
	private String office;
	private String role;


	public IndividualAndLegalEntity(List<String> entity){
		int  TEST_CASE =0;
		int  TEST_SCENARIO =1;
		int  PRIMARY_NAME =2;
		int  PRIMARY_SURNAME =3;
		int  SECONDARY_CLIENT =4;
		int  SECONDARY_NAME =5;
		int  SECONDARY_SURNAME =6;
		int  RELATIONSHIP=7;
		int  REGISTERED_NAME =8;
		int  FAMILY_AND_OTHER =9;
		int  PRIMARY_ID =10;
		int  SECONDARY_ID =11;
		int  PRIMARY_MARITAL =12;
		int  SECONDARY_MARITAL =13;
		int  FAMILY_LEAD_PROVIDER =14;
		int  COMPANIES_AND_TRUST =15;
		int  RELATED_ENTITY_TYPE =16;
		int  REGISTERED_NUMBER=17;
		int  COMPANY =20;
		int  OFFICE= 21;
		int  ROLE= 22;


		setTestCase(entity.get(TEST_CASE));
		setTestScenario(entity.get(TEST_SCENARIO));
		setPrimaryName(entity.get(PRIMARY_NAME));
		setPrimarySurname(entity.get(PRIMARY_SURNAME));
		setSecondaryClient(entity.get(SECONDARY_CLIENT));
		setSecondaryName(entity.get(SECONDARY_NAME));
		setSecondarySurname(entity.get(SECONDARY_SURNAME));
		setRelationship(entity.get(RELATIONSHIP));
		setRegisteredName(entity.get(REGISTERED_NAME));
		setFamilyAndOther(entity.get(FAMILY_AND_OTHER));
		setPrimaryID(entity.get(PRIMARY_ID));
		setSecondaryID(entity.get(SECONDARY_ID));
		setPrimaryMarital(entity.get(PRIMARY_MARITAL));
		setSecondaryMarital(entity.get(SECONDARY_MARITAL));
		setFamilyLeadProvider(entity.get(FAMILY_LEAD_PROVIDER));
		setCompaniesAndTrusts(entity.get(COMPANIES_AND_TRUST));
		setRelatedEntityType(entity.get(RELATED_ENTITY_TYPE));
		setRegistrationNumber(entity.get(REGISTERED_NUMBER));
		setCompany(entity.get(COMPANY));
		setOffice(entity.get(OFFICE));
		setRole(entity.get(ROLE));


	}
	public String getTestScenario() {
		return testScenario;
	}

	public void setTestScenario(String testScenario) {
		this.testScenario = testScenario;
	}

	public String getTestCase() {
		return testCase;
	}

	public void setTestCase(String testCase) {
		this.testCase = testCase;
	}
	public String getSecondaryClient() {
		return secondaryClient;
	}

	public void setSecondaryClient(String secondaryClient) {
		this.secondaryClient = secondaryClient;
	}

	public String getPrimaryName() {
		return primaryName;
	}

	public void setPrimaryName(String primaryName) {
		this.primaryName = primaryName;
	}

	public String getPrimarySurname() {
		return primarySurname;
	}

	public void setPrimarySurname(String primarySurname) {
		this.primarySurname = primarySurname;
	}

	public String getSecondaryName() {
		return secondaryName;
	}

	public void setSecondaryName(String secondaryName) {
		this.secondaryName = secondaryName;
	}

	public String getSecondarySurname() {
		return secondarySurname;
	}

	public void setSecondarySurname(String secondarySurname) {
		this.secondarySurname = secondarySurname;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getRegisteredName() {
		return registeredName;
	}

	public void setRegisteredName(String registeredName) {
		this.registeredName = registeredName;
	}

	public String getFamilyAndOther() {
		return familyAndOther;
	}

	public void setFamilyAndOther(String familyAndOther) {
		this.familyAndOther = familyAndOther;
	}

	public String getPrimaryID() {
		return primaryID;
	}

	public void setPrimaryID(String primaryID) {
		this.primaryID = primaryID;
	}

	public String getSecondaryID() {
		return secondaryID;
	}

	public void setSecondaryID(String secondaryID) {
		this.secondaryID = secondaryID;
	}

	public String getPrimaryMarital() {
		return primaryMarital;
	}

	public void setPrimaryMarital(String primaryMarital) {
		this.primaryMarital = primaryMarital;
	}

	public String getSecondaryMarital() {
		return secondaryMarital;
	}

	public void setSecondaryMarital(String secondaryMarital) {
		this.secondaryMarital = secondaryMarital;
	}

	public String getFamilyLeadProvider() {
		return familyLeadProvider;
	}

	public void setFamilyLeadProvider(String familyLeadProvider) {
		this.familyLeadProvider = familyLeadProvider;
	}

	public String getCompaniesAndTrusts() {
		return companiesAndTrusts;
	}

	public void setCompaniesAndTrusts(String companiesAndTrusts) {
		this.companiesAndTrusts = companiesAndTrusts;
	}

	public String getRelatedEntityType() {
		return relatedEntityType;
	}

	public void setRelatedEntityType(String relatedEntityType) {
		this.relatedEntityType = relatedEntityType;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public String getLeadProviderType() {
		return leadProviderType;
	}

	public void setLeadProviderType(String leadProviderType) {
		this.leadProviderType = leadProviderType;
	}
	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}
