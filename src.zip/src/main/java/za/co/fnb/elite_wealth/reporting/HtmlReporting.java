package za.co.fnb.elite_wealth.reporting;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.apache.log4j.Logger;
import za.co.fnb.elite_wealth.config.EnvironmentConstant;
import za.co.fnb.elite_wealth.module.common.EliteWealthLogin;

import java.io.File;
import java.util.Iterator;
import java.util.List;

public class HtmlReporting {

     private ExtentReports extent;
     private ExtentTest report;
     private String generateFile=EnvironmentConstant.HTML_REPORT_FILE;
     private String configFile =EnvironmentConstant.REPORT_CONFIG_FILE;
     Iterator<String> iterator;
    private static Logger log = Logger.getLogger(HtmlReporting.class);
    
    
    public void generateReport(String testName, List<String> testcaseSteps, TestStatus status){

       iterator = testcaseSteps.iterator();
        String testSteps;
        try {
           extent= new ExtentReports(generateFile, false);

            }catch (Exception ex){
                log.info(ex.getStackTrace());
            }

        extent.loadConfig(new File(configFile));

        //add env on report
        EliteWealthLogin loginInfo = new EliteWealthLogin();
        extent.addSystemInfo("Test Environment : ",loginInfo.getEnvironment());


        if(status==TestStatus.PASS){
            report = extent.startTest("<b style=\"color:#66BB6A;\">"+testName+"</b>");
            while(iterator.hasNext()){
                testSteps  =iterator.next();
                report.log(LogStatus.PASS,"<i>"+testSteps+"</i>");
            }
        }
        if(status==TestStatus.FAIL){
            report = extent.startTest("<b style=\"color:red;\">"+testName+"</b>");
            while(iterator.hasNext()){
                testSteps  =iterator.next();
                report.log(LogStatus.FAIL,testSteps);
            }

			/**
             * Screenshot can be added here
             */
        }
        if(status==TestStatus.WARNING){
            report = extent.startTest("<b>"+testName+"</b>");
            while(iterator.hasNext()){
                testSteps  =iterator.next();
                report.log(LogStatus.WARNING,testSteps);

            }
        }
        if(status==TestStatus.ERROR){
            report = extent.startTest("<b>"+testName+"</b>");
            while(iterator.hasNext()){
                testSteps  =iterator.next();
                report.log(LogStatus.ERROR,testSteps);
            }
        }
        if(status==TestStatus.UNKNOWN){
            report = extent.startTest("<b>"+testName+"</b>");
            while(iterator.hasNext()){
                testSteps  =iterator.next();
                report.log(LogStatus.UNKNOWN,testSteps);
            }
        }
        if(status==TestStatus.SKIP){
            report = extent.startTest("<b>"+testName+"</b>");
            while(iterator.hasNext()){
                testSteps  =iterator.next();
                report.log(LogStatus.SKIP,testSteps);
            }
        }

    /* calling flush writes everything to the log file
    * */
        extent.endTest(report);
        extent.flush();
    }
}
