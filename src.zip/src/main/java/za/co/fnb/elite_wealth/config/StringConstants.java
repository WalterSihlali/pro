package za.co.fnb.elite_wealth.config;

public class StringConstants {

	private StringConstants(){}
	public static final String LOGIN = "Firefox";
	public static final String SEARCH_ENTITY = "Search entity";
	public static final String FAILED_TO_ADD_LIABILITY = "Failed to add liability";
	public static final String FAILED_TO_ADD_ASSET = "Failed to add assets";
	public static final String FAILED_TO_INCLUDE_ASSETS_AND_LIABILITIES = "Failed to include assets and liabilities";
	public static final String FAILED_TO_DELETE_WITHOUT_SAVING = "Failed to delete without saving assets and liabilities";
	public static final String GET_ATTRIBUTE_VALUE = "value";
	public static final String THERE_IS_NO_DATA = "There is no data available.";
	public static final String SELECT_ENTITY = "Select Entity";
	public static final String EDIT_ALL_EXPENSES = "Edit all expenses";
	
	public static final String SELECT_INVESTMENT  = "Select Investment";
	public static final String CALCULATE_REQUIRED_RETURN = "calculate required return";
	public static final String EDIT_EXISTING_ACTIONS = "Edit existing actions";
	public static final String VIEW_TARGET_ASSET_ALLOCATION = "View Target Asset Allocation";
	public static final String IP_FUND_ALLOCATION = "IP:Fund allocation";
	public static final String VIEW_FUND_ALLOCATION = "View Fund Allocation";
	public static final String PRODUCT_FUND_ALLOCATION = "Product and Fund Allocation";
	public static final String ENTITY_FOUND_AND_SELECTED = "Entity found and Selected";
	public static final String VIEW_LA_RESULTS = "View LA Results";
	public static final String VIEW_CASH_FLOW_RESULTS = "View Cash flow Results";
	public static final String VIEW_VOL_INVESTMENT_RESULTS = "View Vol Investment Results";
	public static final String VIEW_INCOME_PROJECTION_RESULT = "View Income Projection Results";
	public static final String VIEW_COMBINED_PROJECTION_RESULT ="View Combined Projection Results";
	public static final String VIEW_DETAILED_INCOME_RESULTS = "View Detailed Income Results";
	
	
	public static final String VIEW_DETAILED_EXPENSES = "View Detailed Expenses";
	public static final String VIEW_DETAILED_TAX = "View Detailed Tax";
	public static final String VIEW_DETAILED_PENSION_FUNDS = "View Detailed Pension Funds";
	public static final String VIEW_DETAILED_PROVIDENT_FUNDS = "View Detailed Provident Funds";
	public static final String VIEW_DETAILED_PRESERVATION_FUNDS = "View Detailed Preservation Funds";
	public static final String VIEW_DETAILED_RAS = "View Detailed RAs";
	public static final String VIEW_DETAILED_COMBINED_FUNDS = "VIEW_DETAILED_COMBINED_FUNDS";
	public static final String PRODUCT_CATALOGUE = "Product Catalogue:";
	
	public static final String VIEW_RISK_RETURN_RESULTS = "View Risk Return Results";
	public static final String VIEW_RAW_INDEX_CALCULATION = "View Raw Index Calculation";
	public static final String VIEW_WEIGHTED_INDICES = "View Weighted Indices";
	public static final String VIEW_INDEX_ALLOCATION_PER_CLASS = "View Index Allocation Per Class";
	public static final String VIEW_ASSET_CLASSES = "View Asset Classes";
	public static final String VIEW_ANNUAL_YEAR_ON_YEAR = "View Annual Year on Year ";
	public static final String VIEW_ONE_MONTH_CHANGE  = "View One Month Change ";
	public static final String VIEW_ROLLING_12_MONTHS_VOLATILITY = "View Rolling 12 Months Volatility ";
	public static final String COMPARE_EXISTING_TO_PROPOSED  = "Compare existing to proposed ";
	public static final String COMPARE_EXISTING_TO_A_BENCHMARK = "Compare existing to a benchmark";
	public static final String COMPARE_PROPOSED_TO_A_BENCHMARK = "Compare proposed to a benchmark";
	public static final String VIEW_ROLLING_ANNUALISED_RETURN = "View Rolling annualised return";
	public static final String VIEW_HIGHEST_ANNUALISED_RETURN = "View Highest annualised return";
	public static final String VIEW_WORST_ANNUALISED_RETURN  = "View Worst annualised return";
	public static final String VIEW_HISTORICAL_LIKELIHOOD_OF_LOSS = "View Historical Likelihood of loss";
	
	public static final String CREATE_WORKFLOW = " Create workflow";
	public static final String WORKFLOW_CREATED_SUCCESSFULLY = " Workflow created successfully";
	public static final String QA_FAIL = "QA Fail";
	public static final String QA_PASS = "QA PASS";
	public static final String ATTACH_DOCUMENTS_VALIDATE_DATA = " Attach Documents & Validate Data";
	public static final String UPDATE_DOCUMENTS_AND_CLIENT_DATA = " Update Documents and Client Data";
	public static final String SUBMIT_TO_SERVICE_PROVIDER_AND_VALIDATE_CLIENT_DATA = " Submit to service provider and validate Client Data";
	public static final String VERIFY_DOCUMENTS_AND_CLIENT_DATA = " Verify Documents and Client Data";
	public static final String SELECT_WORKFLOW = "Select Workflow";
	public static final String RE_VERIFY_DOCUMENTS_AND_CLIENT_DATA = " Re-Verify Documents and Client Data";
	public static final String VERIFY_DEAL= " Verify deal";
	public static final String CORRECT_INFORMATION = "Correct Information";
	public static final String FINAL_CONFIRMATION = " Final Confirmation";
	
	public static final String WE_CANNOT_CONTINUE = "We cannot continue because of errors which are indicated in red. Please fix the data and try again.";
	public static final String ADMIN = "Admin";
	public static final String WEALTH_ADMIN = "Wealth Administrator";
	public static final String ADVANCED = "Advanced ";
	public static final String OFFICE= "Office";
	public static final String NO_RELATED_CLIENT_FOUND = "No related clients data from database";
	
	public static final String STAFF_MEMBER = "Staff member";
	
	
	
	
	
	
	
	
}
