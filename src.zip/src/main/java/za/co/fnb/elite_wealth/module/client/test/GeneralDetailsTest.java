package za.co.fnb.elite_wealth.module.client.test;

import org.apache.log4j.Logger;
import org.junit.Test;
import za.co.fnb.elite_wealth.module.client.dto.GeneralDetails;
import za.co.fnb.elite_wealth.module.client.test.base.GeneralDetailsBase;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;

public class GeneralDetailsTest extends GeneralDetailsBase {

	private static final Logger log = Logger.getLogger(GeneralDetailsTest.class);

	@Test
	public void maintainGeneralDetailsTest(){
		try {
			PageInteraction page =new PageInteraction(driver);
            firstSteps(page);
			for (GeneralDetails entity : retrieveGeneralDetailsData(page)) {
				searchForClient(page,entity);
				selectOtherMenu(page);
				maintainGeneralDetails(page,entity);
				lastSteps(page);
			}
		} catch (Exception ex) {
			log.info(ex.getMessage());
		}
	}
}
