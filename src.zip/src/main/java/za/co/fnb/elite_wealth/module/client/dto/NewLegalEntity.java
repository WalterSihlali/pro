package za.co.fnb.elite_wealth.module.client.dto;

import java.util.List;

public class NewLegalEntity {
	private String testCase;
	private String testScenario;
	private String registeredName;
	private String status;
	private String company;
	private String office;
	private String incomeClass;
	private String entityType;
	private String registrationNumber;
	private String informalSalutation;
	private String formalSalutation;
	private String mastersOffice;
	private String role;
	private String staffMember;
	private String leadProviderType;
	private String other;
	private String staffRole;
	private String referredBy;
	private String referralDate;
	private String notes;

	public NewLegalEntity(List<String> legal){
		int  TEST_CASE =0;
		int  TEST_SCENARIO =1;
		int  REGISTERED_NAME =2;
		int  STATUS =3;
		int  COMPANY =4;
		int  OFFICE =5;
		int  INCOME_CLASS=6;
		int  ENTITY_TYPE =7;
		int  REGISTRATION_NUMBER =8;
		int  INFORMAL_SALUTATION = 9;
		int  FORMAL_SALUTATION = 10;
		int  MASTERS_OFFICE = 11;
		int  ROLE = 12;
		int  STAFF_MEMBER = 13;
		int  LEAD_PROVIDER_TYPE = 14;
		int  OTHER = 15;
		int STAFF_ROLE = 16;
		int REFERRED_BY = 17;
		int REFERRAL_DATE = 18;
		int NOTES = 19;
		setTestCase(legal.get(TEST_CASE));
		setTestScenario(legal.get(TEST_SCENARIO));
		setRegisteredName(legal.get(REGISTERED_NAME));
		setStatus(legal.get(STATUS));
		setCompany(legal.get(COMPANY));
		setOffice(legal.get(OFFICE));
		setIncomeClass(legal.get(INCOME_CLASS));
		setEntityType(legal.get(ENTITY_TYPE));
		setRegistrationNumber(legal.get(REGISTRATION_NUMBER));
		setInformalSalutation(legal.get(INFORMAL_SALUTATION));
		setFormalSalutation(legal.get(FORMAL_SALUTATION));
		setMastersOffice(legal.get(MASTERS_OFFICE));
		setRole(legal.get(ROLE));
		setStaffMember(legal.get(STAFF_MEMBER));
		setLeadProviderType(legal.get(LEAD_PROVIDER_TYPE));
		setOther(legal.get(OTHER));
		setStaffRole(legal.get(STAFF_ROLE));
		setReferredBy(legal.get(REFERRED_BY));
		setReferralDate(legal.get(REFERRAL_DATE));
		setNotes(legal.get(NOTES));
	}

	public String getTestScenario() {
		return testScenario;
	}

	public void setTestScenario(String testScenario) {
		this.testScenario = testScenario;
	}

	public String getTestCase() {
		return testCase;
	}

	public void setTestCase(String testCase) {
		this.testCase = testCase;
	}
	public String getIncomeClass() {
		return incomeClass;
	}

	public void setIncomeClass(String incomeClass) {
		this.incomeClass = incomeClass;
	}

	public String getRegisteredName() {
		return registeredName;
	}

	public void setRegisteredName(String registeredName) {
		this.registeredName = registeredName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public String getInformalSalutation() {
		return informalSalutation;
	}

	public void setInformalSalutation(String informalSalutation) {
		this.informalSalutation = informalSalutation;
	}

	public String getFormalSalutation() {
		return formalSalutation;
	}

	public void setFormalSalutation(String formalSalutation) {
		this.formalSalutation = formalSalutation;
	}

	public String getMastersOffice() {
		return mastersOffice;
	}

	public void setMastersOffice(String mastersOffice) {
		this.mastersOffice = mastersOffice;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getStaffMember() {
		return staffMember;
	}

	public void setStaffMember(String staffMember) {
		this.staffMember = staffMember;
	}

	public String getLeadProviderType() {
		return leadProviderType;
	}

	public void setLeadProviderType(String leadProviderType) {
		this.leadProviderType = leadProviderType;
	}

	public String getOther() {
		return other;
	}

	public void setOther(String other) {
		this.other = other;
	}

	public String getStaffRole() {
		return staffRole;
	}

	public void setStaffRole(String staffRole) {
		this.staffRole = staffRole;
	}

	public String getReferredBy() {
		return referredBy;
	}

	public void setReferredBy(String referredBy) {
		this.referredBy = referredBy;
	}

	public String getReferralDate() {
		return referralDate;
	}

	public void setReferralDate(String referralDate) {
		this.referralDate = referralDate;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

}
