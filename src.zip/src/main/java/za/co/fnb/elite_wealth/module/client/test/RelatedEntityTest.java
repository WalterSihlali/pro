package za.co.fnb.elite_wealth.module.client.test;

import org.apache.log4j.Logger;
import org.junit.Test;
import za.co.fnb.elite_wealth.module.client.dto.NewRelatedEntity;
import za.co.fnb.elite_wealth.module.client.test.base.RelatedEntityBase;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;

public class RelatedEntityTest extends RelatedEntityBase {

	private static Logger log = Logger.getLogger(RelatedEntityTest.class);

	@Test
	public void newRelatedIndividualEntityTest() {
		try {
			PageInteraction page =new PageInteraction(driver);
			firstSteps(page);
			for (NewRelatedEntity client : retrieveRelatedEntityData(page)) {
				addNewRelatedEntity(page, client);
				lastSteps(page);
			}
		} catch (Exception ex) {
			log.info(ex.getMessage());
		}
	}
}
