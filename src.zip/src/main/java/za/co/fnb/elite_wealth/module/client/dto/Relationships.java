package za.co.fnb.elite_wealth.module.client.dto;

import java.util.List;

public class Relationships {

	private String testCase;
	private String testScenario;
	private String searchValue;
	private String addEntityRelationships;
	private String entity;
	private String relationship;
	private String group;
	private String deleteEntity;
	private String addStaffRelationship;
	private String relationStaffRole;
	private String staffName;
	private String deleteStaff;
	private String leadProviderInfo;
	private String leadProviderType;
	private String staffRole;
	private String referredBy;
	private String effectiveDate;
	private String notes;
	private String other;
	private String entityType;

	public Relationships(List<String> entity) {
		int  TEST_CASE =0;
		int  TEST_SCENARIO =1;
		int  SEARCH_VALUE =2;
		int  ADD_ENTITY_RELATIONSHIP =3;
		int  ENTITY=4;
		int  RELATIONSHIP=5;
		int  GROUP =6;
		int  DELETE_ENTITY=7;
		int  ADD_STAFF_RELATIONSHIP=8;
		int  RELATION_STAFF_ROLE =9;
		int  STAFF_NAME =10;
		int  DELETE_STAFF = 11;
		int  LEAD_PROVIDER_INFO=12;
		int  LEAD_PROVIDER_TYPE=13;
		int  STAFF_ROLE=14;
		int  REFERRED_BY =15;
		int  EFFECTIVE_DATE =16;
		int  NOTES = 17;
		int  OTHER = 18;
		int  ENTITY_TYPE = 19;
		setTestCase(entity.get(TEST_CASE));
		setTestScenario(entity.get(TEST_SCENARIO));
		setSearchValue(entity.get(SEARCH_VALUE));
		setAddEntityRelationships(entity.get(ADD_ENTITY_RELATIONSHIP));
		setEntity(entity.get(ENTITY));
		setRelationship(entity.get(RELATIONSHIP));
		setGroup(entity.get(GROUP));
		setDeleteEntity(entity.get(DELETE_ENTITY));
		setAddStaffRelationship(entity.get(ADD_STAFF_RELATIONSHIP));
		setRelationStaffRole(entity.get(RELATION_STAFF_ROLE));
		setStaffName(entity.get(STAFF_NAME));
		setDeleteStaff(entity.get(DELETE_STAFF));
		setLeadProviderInfo(entity.get(LEAD_PROVIDER_INFO));
		setLeadProviderType(entity.get(LEAD_PROVIDER_TYPE));
		setStaffRole(entity.get(STAFF_ROLE));
		setRefferedBy(entity.get(REFERRED_BY));
		setEffectiveDate(entity.get(EFFECTIVE_DATE));
		setNotes(entity.get(NOTES));
		setOther(entity.get(OTHER));
		setEntityType(entity.get(ENTITY_TYPE));
	}

	public String getTestCase() {
		return testCase;
	}

	public void setTestCase(String testCase) {
		this.testCase = testCase;
	}

	public String getTestScenario() {
		return testScenario;
	}

	public void setTestScenario(String testScenario) {
		this.testScenario = testScenario;
	}

	public String getSearchValue() {
		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	public String getAddEntityRelationships() {
		return addEntityRelationships;
	}

	public void setAddEntityRelationships(String addEntityRelationships) {
		this.addEntityRelationships = addEntityRelationships;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getDeleteEntity() {
		return deleteEntity;
	}

	public void setDeleteEntity(String deleteEntity) {
		this.deleteEntity = deleteEntity;
	}
	public String getAddStaffRelationship() {
		return addStaffRelationship;
	}

	public void setAddStaffRelationship(String addStaffrelationship) {
		this.addStaffRelationship = addStaffrelationship;
	}

	public String getRelationStaffRole() {
		return relationStaffRole;
	}

	public void setRelationStaffRole(String relationStaffRole) {
		this.relationStaffRole = relationStaffRole;
	}

	public String getStaffName() {
		return staffName;
	}

	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}

	public String getDeleteStaff() {
		return deleteStaff;
	}

	public void setDeleteStaff(String deleteStaff) {
		this.deleteStaff = deleteStaff;
	}

	public String getLeadProviderType() {
		return leadProviderType;
	}

	public void setLeadProviderType(String leadProviderType) {
		this.leadProviderType = leadProviderType;
	}

	public String getLeadProviderInfo() {
		return leadProviderInfo;
	}

	public void setLeadProviderInfo(String leadProdiderInfo) {
		this.leadProviderInfo = leadProdiderInfo;
	}

	public String getRefferedBy() {
		return referredBy;
	}

	public void setRefferedBy(String refferedBy) {
		this.referredBy = refferedBy;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getOther() {
		return other;
	}

	public void setOther(String other) {
		this.other = other;
	}


	public String getStaffRole() {
		return staffRole;
	}

	public void setStaffRole(String staffRole) {
		this.staffRole = staffRole;
	}


	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}


}
