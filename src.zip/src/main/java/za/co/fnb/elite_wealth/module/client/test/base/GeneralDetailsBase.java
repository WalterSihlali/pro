package za.co.fnb.elite_wealth.module.client.test.base;

import org.apache.log4j.Logger;
import za.co.fnb.elite_wealth.config.ElementConstants;
import za.co.fnb.elite_wealth.config.SeleniumService;
import za.co.fnb.elite_wealth.module.client.dto.GeneralDetails;
import za.co.fnb.elite_wealth.module.common.CommonActions;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;
import za.co.fnb.elite_wealth.reporting.HtmlReporting;
import za.co.fnb.elite_wealth.reporting.TestStatus;
import za.co.fnb.elite_wealth.util.RetrieveTestData;

import java.util.List;

public class GeneralDetailsBase extends SeleniumService {
	private HtmlReporting reporting = new HtmlReporting();
	
	private static final Logger log = Logger.getLogger(EntityDetailsBase.class);
	private CommonActions common = new CommonActions();
	
	protected List<GeneralDetails> retrieveGeneralDetailsData(PageInteraction page) {
		RetrieveTestData retrieveTestData = new RetrieveTestData(page.dataSheetLocation());
		return retrieveTestData.getGeneralDetailsDTO();
	}
	
	public void firstSteps(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CLIENT_INFO_TAB);
	}
	
	public void lastSteps(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SELECT_ENTITY);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	protected void searchForClient(PageInteraction page, GeneralDetails generalDetail) {
		String search = generalDetail.getSearchValue();
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_TXT, search);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.SEARCH_BTN);
		common.selectClientFromList(page);
		page.takeScreenShoot("updateEntitySearch " + common.getDateFormat());
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	protected void selectOtherMenu(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OTHER_MENU);
		page.waitForProcessToComplete(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.PROCESSING);
	}
	
	private void addBankAccountDetails(PageInteraction page, GeneralDetails details) {
		String primaryAcc = details.getPrimaryAccount();
		String bankAcc = details.getBankAccount();
		String accType = details.getBankAccountType();
		String accNumber = details.getBankAccountNumber();
		String accBranch = details.getBankBranch();
		if (primaryAcc.equals("Yes")) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_PRIMARY_ACC);
		}
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_BANK_ACC);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_BANK_ACC, bankAcc);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_BANK_ACC_TYPE);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_BANK_ACC_TYPE, accType);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_BANK_ACC_NUM);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_BANK_ACC_NUM, accNumber);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_BANK_BRANCH);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_BANK_BRANCH, accBranch);
		page.takeScreenShoot("addAccountDetails" + common.getDateFormat());
		
	}
	
	private void deleteBankAccountDetails(PageInteraction page) {
		boolean deletePresent = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DELETE_BANK_ACC);
		if (deletePresent) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DELETE_BANK_ACC);
			page.takeScreenShoot("deleteAccountDetails" + common.getDateFormat());
		}
	}
	
	private void addTaxDetails(PageInteraction page, GeneralDetails details) {
		String taxNum = details.getTaxNumber();
		String taxCountry = details.getTaxCounty();
		String taxPayerRegistered = details.getTaxPayerRegistered();
		String provisionalTaxPayer = details.getProvisionalTaxpayer();
		
		if (taxPayerRegistered.equals("Yes")) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_TAX_PAYER_REG);
		}
		if (provisionalTaxPayer.equals("Yes")) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_PROVISIONAL_TAX);
		}
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_TAX_NUM);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_TAX_NUM, taxNum);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_TAX_COUNTRY, taxCountry);
		page.takeScreenShoot("addTaxDetails" + common.getDateFormat());
	}
	
	private void addAuditDetails(PageInteraction page, GeneralDetails details) {
		String auditors = details.getAuditors();
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_AUDITORS, auditors);
		page.takeScreenShoot("addAuditDetails" + common.getDateFormat());
	}
	
	private void deleteAuditDetails(PageInteraction page) {
		boolean deletePresent = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DELETE_AUDIT);
		if (deletePresent) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DELETE_AUDIT);
			page.takeScreenShoot("deleteAuditDetails" + common.getDateFormat());
		}
	}
	
	private void addMedicalDetails(PageInteraction page, GeneralDetails details) {
		String medicalAid = details.getMedicalAid();
		String medicalAidNumber = details.getMedicalAidNumber();
		String medicalAidPlan = details.getMedicalPlan();
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_MEDICAL_AID);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_MEDICAL_AID, medicalAid);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_MEDICAL_NUM);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_MEDICAL_NUM, medicalAidNumber);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_MEDICAL_PLAN);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_MEDICAL_PLAN, medicalAidPlan);
		page.takeScreenShoot("addMedicalDetails" + common.getDateFormat());
	}
	
	private void deleteMedicalDetails(PageInteraction page) {
		boolean deletePresent = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DELETE_MEDICAL);
		if (deletePresent) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DELETE_MEDICAL);
			page.takeScreenShoot("deleteMedicalDetails" + common.getDateFormat());
		}
	}
	
	private void addEmploymentDetails(PageInteraction page, GeneralDetails details) {
		String employer = details.getEmployer();
		String department = details.getDepartment();
		String market = details.getMarketSegment();
		String occupation = details.getOccupation();
		String status = details.getEmploymentStatus();
		String startDate = details.getStartDate();
		String endDate = details.getEndDate();
		String review = details.getSalaryReviewDate();
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOYER);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOYER, employer);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_DEPARTMENT);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_DEPARTMENT, department);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_MARKET);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_MARKET, market);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_OCCUPATION);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_OCCUPATION, occupation);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_STATUS_);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_STATUS_, status);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_START);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_START, startDate);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_END);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_END, endDate);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_REVIEW);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_REVIEW, review);
		page.takeScreenShoot("addEmploymentDetails" + common.getDateFormat());
	}
	
	private void deleteEmploymentDetails(PageInteraction page) {
		boolean deletePresent = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_DELETE);
		if (deletePresent) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EMPLOY_DELETE);
			page.takeScreenShoot("deleteEmploymentDetails" + common.getDateFormat());
		}
	}
	
	private void addQualificationDetails(PageInteraction page, GeneralDetails details) {
		String qualification = details.getQualification();
		String institution = details.getInstitution();
		String dateQualified = details.getDateQualified();
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_QUALIFICATION);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_QUALIFICATION, qualification);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_INSTITUTION);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_INSTITUTION, institution);
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DATE_QUALIFIED);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DATE_QUALIFIED, dateQualified);
		page.takeScreenShoot("addQualificationDetails" + common.getDateFormat());
	}
	
	private void deleteQualificationDetails(PageInteraction page) {
		boolean deletePresent = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DELETE_QUAL);
		if (deletePresent) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DELETE_QUAL);
			page.takeScreenShoot("deleteQualificationDetails" + common.getDateFormat());
		}
	}
	
	private void addInterestDetails(PageInteraction page, GeneralDetails details) {
		String interestDetails = details.getDetails();
		page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DETAILS);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_DETAILS, interestDetails);
		page.takeScreenShoot("addInterests" + common.getDateFormat());
	}
	
	private void deleteInterestDetails(PageInteraction page) {
		boolean deletePresent = page.isElementPresent1(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_INTEREST_DELETE);
		if (deletePresent) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_INTEREST_DELETE);
			page.takeScreenShoot("deleteInterests" + common.getDateFormat());
		}
	}
	
	private void loadNewAuditor(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LOAD_NEW_AUDITOR);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_AUDITOR);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_AUDITOR);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.AUDITOR_NAME, "New Test ");
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.AUDITOR_SURNAME, "Auditor");
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CREATE_AUDITOR);
	}
	
	private void loadNewExecutor(PageInteraction page) {
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.LOAD_NEW_EXECUTOR);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EXECUTOR);
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_EXECUTOR);
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.EXECUTOR_NAME, "FNB");
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.EXECUTOR_SURNAME, "Executor");
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.CREATE_EXECUTOR);
	}
	
	private void addWillDetails(PageInteraction page, GeneralDetails details) {
		String willExecutor = details.getWillExecutor();
		String willLocal = details.getLocalWill();
		String willOffShore = details.getOffshoreWill();
		String willLiving = details.getLivingWill();
		String estatePlanning = details.getEstatePlanning();
		String lastUpdate = details.getLastUpdate();
		page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.EXECUTOR_NAME, willExecutor);
		
		if (willLocal.equals("Yes")) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_LOCAL_WILL);
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_LOCAL_WILL_DATE);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_LOCAL_WILL_DATE, "01/10/2010");
		}
		
		if (willOffShore.equals("Yes")) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_OFFSHORE_WILL);
			page.clearField(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_OFFSHORE_WILL_DATE);
			page.enterDataFromExcel(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_OFFSHORE_WILL_DATE, "01/10/2010");
		}
		
		if (willLiving.equals("Yes")) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_LIVING_WILL);
		}
		
		if (estatePlanning.equals("Yes")) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_ESTATE_PLANNING);
		}
		
		if (lastUpdate.equals("Yes")) {
			page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.INDIVIDUAL_LAST_UPDATE);
		}
	}
	
	protected void maintainGeneralDetails(PageInteraction page, GeneralDetails details) throws Exception {
		String testCase = details.getTestCase();
		List<String> testCaseSteps;
		if (testCase.equals("Add All  General Entity Details")) {
			addBankAccountDetails(page, details);
			addTaxDetails(page, details);
			addAuditDetails(page, details);
			addMedicalDetails(page, details);
			addEmploymentDetails(page, details);
			addQualificationDetails(page, details);
			addInterestDetails(page, details);
		}
		
		if (testCase.equals("Delete All General Entity Details")) {
			deleteBankAccountDetails(page);
			deleteAuditDetails(page);
			deleteMedicalDetails(page);
			deleteEmploymentDetails(page);
			deleteQualificationDetails(page);
			deleteInterestDetails(page);
		}
		
		if (testCase.equals("Will Details-Add Executor and Auditor")) {
			loadNewExecutor(page);
			addWillDetails(page, details);
			loadNewAuditor(page);
		}
		
		page.selectNonInteractiveItem(ElementConstants.CLIENT_INFO_PAGE, ElementConstants.OTHER_SAVE);
		boolean saved = common.checkUpdateSaved(page);
		
		if (saved) {
			testCaseSteps = common.testCaseSteps("Login,Search entity,Update Entity,Entity general details updated successfully");
			reporting.generateReport(testCase, testCaseSteps, TestStatus.PASS);
		} else {
			testCaseSteps = common.testCaseSteps("Failed to update entity general details successfully");
			reporting.generateReport(testCase, testCaseSteps, TestStatus.FAIL);
			log.info("Failed to update client details");
		}
	}
}
