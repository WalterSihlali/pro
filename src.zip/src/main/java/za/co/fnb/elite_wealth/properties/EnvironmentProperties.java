package za.co.fnb.elite_wealth.properties;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class EnvironmentProperties {

	@Value("${test.url}")
	private String testUrl;
	@Value("${test.datasheet}")
	private String testDatasheet;

	public String getTestUrl() {
		return testUrl;
	}

	public String getTestDatasheet() {
		return testDatasheet;
	}

	@Override
	public String toString() {
		return "EnvironmentProperties [testUrl=" + testUrl +  " [datasheet[ "+testDatasheet+" ]";
	}
}
