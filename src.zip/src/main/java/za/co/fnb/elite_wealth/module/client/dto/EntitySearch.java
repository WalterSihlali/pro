package za.co.fnb.elite_wealth.module.client.dto;

import java.util.List;

public class EntitySearch {
	private String testCase;
	private String testScenario;
	private String entitySearch;

	public EntitySearch(List<String> entity) {
		int  TEST_CASE =0;
		int  TEST_SCENARIO =1;
		int  ENTITY_SEARCH =2;
		setTestCase(entity.get(TEST_CASE));
		setTestScenario(entity.get(TEST_SCENARIO));
		setEntitySearch(entity.get(ENTITY_SEARCH));
	}
	
	public String getTestScenario() {
		return testScenario;
	}

	public void setTestScenario(String testScenario) {
		this.testScenario = testScenario;
	}


	public String getEntitySearch() {
		return entitySearch;
	}

	public void setEntitySearch(String entitySearch) {
		this.entitySearch = entitySearch;
	}

	public String getTestCase() {
		return testCase;
	}

	public void setTestCase(String testCase) {
		this.testCase = testCase;
	}

}
