package za.co.fnb.elite_wealth.module.client.test;

import org.apache.log4j.Logger;
import org.junit.Test;
import za.co.fnb.elite_wealth.module.client.dto.IndividualEntityDetails;
import za.co.fnb.elite_wealth.module.client.test.base.EntityDetailsBase;
import za.co.fnb.elite_wealth.page_interaction.PageInteraction;

public class IndividualEntityUpdateTest extends EntityDetailsBase {

	private static Logger log = Logger.getLogger(IndividualEntityUpdateTest.class);

	@Test
	public void individualEntityUpdateTest() {
		try {
			PageInteraction page =new PageInteraction(driver);
			firstSteps(page);
			for (IndividualEntityDetails entity : retrieveIndividualUpdateEntityData(page)) {
				updateIndividualEntitySearch(page, entity);
				updateIndividualDetails(page, entity);
				lastSteps(page);
			}
			page.waitFor(2000);
		} catch (Exception ex) {
			log.info(ex.getMessage());
		}
	}
}
