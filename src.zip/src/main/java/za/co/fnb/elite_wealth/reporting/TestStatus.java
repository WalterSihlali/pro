package za.co.fnb.elite_wealth.reporting;

public enum TestStatus {
    PASS,
    FAIL,
    FATAL,
    ERROR,
    WARNING,
    INFO,
    SKIP,
    UNKNOWN
}